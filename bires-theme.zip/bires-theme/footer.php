<?php
$phone_1   = bires_option( 'contact_phone_1', '(+380) 44 334 75 04' );
$phone_2   = bires_option( 'contact_phone_2', '(+380) 96 106 20 56' );
$email     = bires_option( 'contact_email', 'info@bires.com.ua' );
$address_1 = bires_option( 'contact_address_1', 'вул. Воздвиженська 14, офіс 9' );
$address_2 = bires_option( 'contact_address_2', 'Київ, 04-071' );
$socials   = [
    'telegram'  => bires_option( 'social_telegram' ),
    'instagram' => bires_option( 'social_instagram' ),
    'facebook'  => bires_option( 'social_facebook' ),
];
$privacy_id = bires_option( 'privacy_page' );
$terms_id   = bires_option( 'terms_page' );
?>
    <footer class="site-footer">
        <div class="container container--wide">
            <div class="site-footer__top">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-footer__brand">
                    <span class="site-footer__logo">BIRES<span class="site-footer__reg">&reg;</span></span>
                    <span class="site-footer__tagline">Law firm since 2013</span>
                </a>
                <?php if ( array_filter( $socials ) ) : ?>
                    <div class="site-footer__socials">
                        <?php if ( $socials['telegram'] ) : ?>
                            <a href="<?php echo esc_url( $socials['telegram'] ); ?>" aria-label="Telegram" class="site-footer__social" rel="noopener">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m21 4-2.7 15.3c-.2 1-1.35 1.4-2.15.8l-4.15-3.15-2 2c-.25.25-.6.35-.9.25l.4-3.9L18 8.5c.4-.35-.05-.5-.55-.2L8.3 13.6l-3.9-1.2c-.85-.25-.85-.85.2-1.25l15.3-5.9c.7-.25 1.3.15 1.1 1.15Z" stroke="white" stroke-width="1.5" stroke-linejoin="round"/></svg>
                            </a>
                        <?php endif; ?>
                        <?php if ( $socials['instagram'] ) : ?>
                            <a href="<?php echo esc_url( $socials['instagram'] ); ?>" aria-label="Instagram" class="site-footer__social" rel="noopener">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5" stroke="white" stroke-width="1.5"/><circle cx="12" cy="12" r="4" stroke="white" stroke-width="1.5"/><circle cx="17.2" cy="6.8" r="1" fill="white"/></svg>
                            </a>
                        <?php endif; ?>
                        <?php if ( $socials['facebook'] ) : ?>
                            <a href="<?php echo esc_url( $socials['facebook'] ); ?>" aria-label="Facebook" class="site-footer__social" rel="noopener">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M14 21v-7h2.4l.4-3H14V9c0-.85.24-1.43 1.46-1.43H17V4.9c-.26-.03-1.15-.1-2.19-.1-2.17 0-3.65 1.32-3.65 3.75V11H9v3h2.16v7H14Z" stroke="white" stroke-width="1.5" stroke-linejoin="round"/></svg>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="site-footer__columns">
                <div class="footer-col">
                    <div class="footer-col__title"><?php esc_html_e( 'Наш офіс', 'bires-theme' ); ?></div>
                    <a href="mailto:<?php echo esc_attr( antispambot( $email ) ); ?>" class="footer-col__link"><?php echo esc_html( antispambot( $email ) ); ?></a>
                    <div class="footer-col__group">
                        <a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $phone_1 ) ); ?>" class="footer-col__link"><?php echo esc_html( $phone_1 ); ?></a>
                        <?php if ( $phone_2 ) : ?>
                            <a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $phone_2 ) ); ?>" class="footer-col__link"><?php echo esc_html( $phone_2 ); ?></a>
                        <?php endif; ?>
                    </div>
                    <address class="footer-col__group">
                        <span class="footer-col__link"><?php echo esc_html( $address_1 ); ?></span>
                        <span class="footer-col__link"><?php echo esc_html( $address_2 ); ?></span>
                    </address>
                </div>
                <?php if ( has_nav_menu( 'footer_services' ) ) : ?>
                    <nav class="footer-col" aria-label="<?php esc_attr_e( 'Практики', 'bires-theme' ); ?>">
                        <div class="footer-col__head">
                            <div class="footer-col__title"><?php esc_html_e( 'Практики', 'bires-theme' ); ?></div>
                            <button type="button" class="footer-col__toggle" aria-expanded="true" aria-controls="footer-footer_services">
                                <span class="screen-reader-text"><?php esc_html_e( 'Практики', 'bires-theme' ); ?></span>
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="m4 10 4-4 4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </button>
                        </div>
                        <?php
                        wp_nav_menu( [
                            'theme_location' => 'footer_services',
                            'container'      => false,
                            'menu_class'     => 'footer-col__list',
                            'menu_id'        => 'footer-footer_services',
                            'depth'          => 1,
                            'fallback_cb'    => false,
                        ] );
                        ?>
                    </nav>
                <?php endif; ?>
                <?php if ( has_nav_menu( 'footer_company' ) ) : ?>
                    <nav class="footer-col" aria-label="<?php esc_attr_e( 'Компанія', 'bires-theme' ); ?>">
                        <div class="footer-col__head">
                            <div class="footer-col__title"><?php esc_html_e( 'Компанія', 'bires-theme' ); ?></div>
                            <button type="button" class="footer-col__toggle" aria-expanded="true" aria-controls="footer-footer_company">
                                <span class="screen-reader-text"><?php esc_html_e( 'Компанія', 'bires-theme' ); ?></span>
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="m4 10 4-4 4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </button>
                        </div>
                        <?php
                        wp_nav_menu( [
                            'theme_location' => 'footer_company',
                            'container'      => false,
                            'menu_class'     => 'footer-col__list',
                            'menu_id'        => 'footer-footer_company',
                            'depth'          => 1,
                            'fallback_cb'    => false,
                        ] );
                        ?>
                    </nav>
                <?php endif; ?>
            </div>
        </div>

        <div class="site-footer__bottom">
            <div class="container container--wide site-footer__bottom-inner">
                <p class="site-footer__copy">&copy; Bires 2013-<?php echo esc_html( date_i18n( 'Y' ) ); ?>. <?php esc_html_e( 'All rights reserved', 'bires-theme' ); ?></p>
                <div class="site-footer__legal">
                    <?php if ( $privacy_id ) : ?>
                        <a href="<?php echo esc_url( get_permalink( $privacy_id ) ); ?>"><?php esc_html_e( 'Privacy Policy', 'bires-theme' ); ?></a>
                    <?php endif; ?>
                    <?php if ( $terms_id ) : ?>
                        <a href="<?php echo esc_url( get_permalink( $terms_id ) ); ?>"><?php esc_html_e( 'Terms of use', 'bires-theme' ); ?></a>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="site-footer__chat" aria-label="<?php esc_attr_e( 'Написати нам', 'bires-theme' ); ?>">
                        <svg width="32" height="32" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M2.5 10c0-4.14 3.36-7.5 7.5-7.5s7.5 3.36 7.5 7.5-3.36 7.5-7.5 7.5c-1.05 0-2.05-.22-2.95-.6L2.5 17.5l1.15-3.45A7.46 7.46 0 0 1 2.5 10Z" fill="white"/></svg>
                    </a>
                </div>
            </div>
        </div>
    </footer>

<?php wp_footer(); ?>
</body>
</html>
