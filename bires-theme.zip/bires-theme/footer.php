<?php
$phone_1   = bires_option( 'contact_phone_1', '(+380) 44 334 75 04' );
$phone_2   = bires_option( 'contact_phone_2', '(+380) 96 106 20 56' );
$email     = bires_option( 'contact_email', 'info@bires.com.ua' );
$address   = bires_office_address();
// Місто — окремим рядком (з комою, текст адреси не змінюється), інакше перший рядок задовгий для колонки футера
if ( $address && preg_match( '/^([^,]+,)\s*(.+)$/u', $address[0], $address_parts ) ) {
    array_splice( $address, 0, 1, [ $address_parts[1], $address_parts[2] ] );
}
$socials   = [
    'telegram'  => bires_option( 'social_telegram' ),
    'instagram' => bires_option( 'social_instagram' ),
    'facebook'  => bires_option( 'social_facebook' ),
];
$privacy_id = bires_option( 'privacy_page' );
$terms_id   = bires_option( 'terms_page' );
?>
<?php // Сторінка адвоката — фінальний екран без футера; скрипти сайту (wp_footer) лишаються ?>
<?php if ( ! is_singular( 'team' ) ) : ?>
    <div class="footer-glow" aria-hidden="true"></div>
    <footer class="site-footer">
        <div class="container container--wide">
            <div class="site-footer__top">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-footer__brand">
                    <span class="site-footer__logo"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/footer-logo.svg' ); ?>" width="115" height="32" alt="BIRES"><span class="site-footer__reg">&reg;</span></span>
                    <span class="site-footer__tagline">Law firm since 2013</span>
                </a>
                <?php if ( array_filter( $socials ) ) : ?>
                    <div class="site-footer__socials">
                        <?php if ( $socials['telegram'] ) : ?>
                            <a href="<?php echo esc_url( $socials['telegram'] ); ?>" aria-label="Telegram" class="site-footer__social" rel="noopener">
                                <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/ic-telegram.svg' ); ?>" width="24" height="24" alt="">
                            </a>
                        <?php endif; ?>
                        <?php if ( $socials['instagram'] ) : ?>
                            <a href="<?php echo esc_url( $socials['instagram'] ); ?>" aria-label="Instagram" class="site-footer__social" rel="noopener">
                                <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/ic-instagram.svg' ); ?>" width="24" height="24" alt="">
                            </a>
                        <?php endif; ?>
                        <?php if ( $socials['facebook'] ) : ?>
                            <a href="<?php echo esc_url( $socials['facebook'] ); ?>" aria-label="Facebook" class="site-footer__social" rel="noopener">
                                <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/ic-facebook.svg' ); ?>" width="24" height="24" alt="">
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="site-footer__columns">
                <div class="footer-col">
                    <div class="footer-col__title"><?php esc_html_e( 'Наш офіс', 'bires-theme' ); ?></div>
                    <a href="mailto:<?php echo esc_attr( antispambot( $email ) ); ?>" class="footer-col__link"><?php echo esc_html( antispambot( $email ) ); ?></a>
                    <div class="footer-col__group">
                        <a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $phone_1 ) ); ?>" class="footer-col__link"><?php echo esc_html( $phone_1 ); ?></a>
                        <?php if ( $phone_2 ) : ?>
                            <a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $phone_2 ) ); ?>" class="footer-col__link"><?php echo esc_html( $phone_2 ); ?></a>
                        <?php endif; ?>
                    </div>
                    <address class="footer-col__group">
                        <?php foreach ( $address as $address_line ) : ?>
                            <span class="footer-col__link"><?php echo esc_html( $address_line ); ?></span>
                        <?php endforeach; ?>
                    </address>
                </div>
                <?php if ( has_nav_menu( 'footer_services' ) ) : ?>
                    <nav class="footer-col" aria-label="<?php esc_attr_e( 'Практики', 'bires-theme' ); ?>">
                        <div class="footer-col__head">
                            <div class="footer-col__title"><?php esc_html_e( 'Практики', 'bires-theme' ); ?></div>
                            <button type="button" class="footer-col__toggle" aria-expanded="false" aria-controls="footer-footer_services">
                                <span class="screen-reader-text"><?php esc_html_e( 'Практики', 'bires-theme' ); ?></span>
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="m4 10 4-4 4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </button>
                        </div>
                        <?php
                        wp_nav_menu( [
                            'theme_location' => 'footer_services',
                            'container'      => false,
                            'menu_class'     => 'footer-col__list',
                            'menu_id'        => 'footer-footer_services',
                            'depth'          => 1,
                            'fallback_cb'    => false,
                        ] );
                        ?>
                    </nav>
                <?php endif; ?>
                <?php if ( has_nav_menu( 'footer_company' ) ) : ?>
                    <nav class="footer-col" aria-label="<?php esc_attr_e( 'Компанія', 'bires-theme' ); ?>">
                        <div class="footer-col__head">
                            <div class="footer-col__title"><?php esc_html_e( 'Компанія', 'bires-theme' ); ?></div>
                            <button type="button" class="footer-col__toggle" aria-expanded="false" aria-controls="footer-footer_company">
                                <span class="screen-reader-text"><?php esc_html_e( 'Компанія', 'bires-theme' ); ?></span>
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="m4 10 4-4 4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            </button>
                        </div>
                        <?php
                        wp_nav_menu( [
                            'theme_location' => 'footer_company',
                            'container'      => false,
                            'menu_class'     => 'footer-col__list',
                            'menu_id'        => 'footer-footer_company',
                            'depth'          => 1,
                            'fallback_cb'    => false,
                        ] );
                        ?>
                    </nav>
                <?php endif; ?>
            </div>
        </div>

        <div class="site-footer__bottom">
            <div class="container container--wide site-footer__bottom-inner">
                <p class="site-footer__copy">&copy; Bires 2013-<?php echo esc_html( date_i18n( 'Y' ) ); ?>. <?php esc_html_e( 'All rights reserved', 'bires-theme' ); ?></p>
                <div class="site-footer__legal">
                    <?php if ( $privacy_id ) : ?>
                        <a href="<?php echo esc_url( get_permalink( $privacy_id ) ); ?>"><?php esc_html_e( 'Privacy Policy', 'bires-theme' ); ?></a>
                    <?php endif; ?>
                    <?php if ( $terms_id ) : ?>
                        <a href="<?php echo esc_url( get_permalink( $terms_id ) ); ?>"><?php esc_html_e( 'Terms of use', 'bires-theme' ); ?></a>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="site-footer__chat" aria-label="<?php esc_attr_e( 'Написати нам', 'bires-theme' ); ?>">
                        <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/ic-chat.svg' ); ?>" width="32" height="32" alt="">
                    </a>
                </div>
            </div>
        </div>
    </footer>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
