<?php
get_header();

while ( have_posts() ) :
    the_post();

    $member_id    = get_the_ID();
    $position     = bires_field( 'team_position' );
    $linkedin     = bires_team_linkedin( $member_id );
    $education    = array_filter( bires_rows( 'team_education' ), function ( $r ) {
        return ! empty( $r['title'] );
    } );
    $bio          = apply_filters( 'the_content', get_the_content() );
    $has_bio      = '' !== trim( wp_strip_all_tags( $bio ) ) || $education || $position || bires_field( 'team_lead' );
    ?>
    <main class="site-main" id="main">
        <section class="person-hero">
            <div class="person-hero__photo">
                <?php the_post_thumbnail( 'large', [ 'alt' => esc_attr( get_the_title() ), 'fetchpriority' => 'high' ] ); ?>
            </div>
            <div class="person-hero__content">
                <nav class="breadcrumbs" aria-label="<?php esc_attr_e( 'Навігаційний ланцюжок', 'bires-theme' ); ?>">
                    <ol>
                        <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Головна', 'bires-theme' ); ?></a></li>
                        <li><a href="<?php echo esc_url( get_post_type_archive_link( 'team' ) ); ?>"><?php esc_html_e( 'Команда', 'bires-theme' ); ?></a></li>
                        <li aria-current="page"><?php the_title(); ?></li>
                    </ol>
                </nav>
                <h1 class="person-hero__name"><?php the_title(); ?></h1>
                <div class="person-hero__buttons">
                    <?php if ( $linkedin ) : ?>
                        <a class="services-btn services-btn--outline-light" href="<?php echo esc_url( $linkedin ); ?>" rel="noopener">
                            <svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M20 2H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2ZM8.3 18.3H5.7V9.7h2.6v8.6ZM7 8.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Zm11.3 9.8h-2.6v-4.2c0-1 0-2.3-1.4-2.3s-1.6 1.1-1.6 2.2v4.3h-2.6V9.7h2.5v1.2c.4-.7 1.2-1.4 2.5-1.4 2.7 0 3.2 1.8 3.2 4.1v4.7Z"/></svg>
                            <?php esc_html_e( 'LinkedIn профіль', 'bires-theme' ); ?>
                        </a>
                    <?php endif; ?>
                    <?php if ( $has_bio ) : ?>
                        <button type="button" class="services-btn services-btn--outline-light person-hero__toggle" aria-expanded="false" aria-controls="person-bio">
                            <?php esc_html_e( 'Детальніше про адвоката', 'bires-theme' ); ?>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m6 9 6 6 6-6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        </button>
                    <?php endif; ?>
                </div>
                <?php if ( $has_bio ) : ?>
                    <div class="person-hero__bio" id="person-bio" hidden>
                        <?php if ( $position ) : ?>
                            <p class="person-hero__position"><?php echo esc_html( $position ); ?></p>
                        <?php endif; ?>
                        <?php if ( bires_field( 'team_lead' ) ) : ?>
                            <p class="person-hero__lead"><?php echo esc_html( bires_field( 'team_lead' ) ); ?></p>
                        <?php endif; ?>
                        <div class="person-hero__bio-text"><?php echo $bio; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- filtered post content ?></div>
                        <?php if ( $education ) : ?>
                            <h2 class="person-hero__subtitle"><?php esc_html_e( 'Освіта', 'bires-theme' ); ?></h2>
                            <ul class="person-hero__education">
                                <?php foreach ( $education as $row ) : ?>
                                    <li><?php echo esc_html( $row['title'] ); ?><?php echo ! empty( $row['years'] ) ? ' <span>' . esc_html( $row['years'] ) . '</span>' : ''; ?></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <?php // Сторінка адвоката закінчується першим екраном: без блоків нижче й без футера (див. footer.php) ?>
    </main>
    <?php
endwhile;

get_footer();
