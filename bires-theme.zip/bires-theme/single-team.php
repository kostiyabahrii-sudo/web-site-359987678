<?php
get_header();

while ( have_posts() ) :
    the_post();

    $member_id    = get_the_ID();
    $position     = bires_field( 'team_position' );
    $linkedin     = bires_team_linkedin( $member_id );
    $education    = array_filter( bires_rows( 'team_education' ), function ( $r ) {
        return ! empty( $r['title'] );
    } );
    $publications = array_filter( bires_rows( 'team_publications' ), function ( $r ) {
        return ! empty( $r['title'] );
    } );
    $services     = array_values( array_filter( (array) bires_field( 'team_related_services' ), function ( $id ) {
        return 'publish' === get_post_status( $id );
    } ) );
    $posts        = get_posts( [
        'suppress_filters' => false,
        'posts_per_page' => 12,
        'meta_query'     => [ [ 'key' => 'post_team_author', 'value' => $member_id ] ],
    ] );
    $bio          = apply_filters( 'the_content', get_the_content() );
    $has_bio      = '' !== trim( wp_strip_all_tags( $bio ) ) || $education || $position || bires_field( 'team_lead' );
    ?>
    <main class="site-main" id="main">
        <section class="person-hero">
            <div class="person-hero__photo">
                <?php the_post_thumbnail( 'large', [ 'alt' => esc_attr( get_the_title() ), 'fetchpriority' => 'high' ] ); ?>
            </div>
            <div class="person-hero__content">
                <nav class="breadcrumbs" aria-label="<?php esc_attr_e( 'Навігаційний ланцюжок', 'bires-theme' ); ?>">
                    <ol>
                        <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Головна', 'bires-theme' ); ?></a></li>
                        <li><a href="<?php echo esc_url( get_post_type_archive_link( 'team' ) ); ?>"><?php esc_html_e( 'Команда', 'bires-theme' ); ?></a></li>
                        <li aria-current="page"><?php the_title(); ?></li>
                    </ol>
                </nav>
                <h1 class="person-hero__name"><?php the_title(); ?></h1>
                <div class="person-hero__buttons">
                    <?php if ( $linkedin ) : ?>
                        <a class="services-btn services-btn--outline-light" href="<?php echo esc_url( $linkedin ); ?>" rel="noopener">
                            <svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M20 2H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2ZM8.3 18.3H5.7V9.7h2.6v8.6ZM7 8.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Zm11.3 9.8h-2.6v-4.2c0-1 0-2.3-1.4-2.3s-1.6 1.1-1.6 2.2v4.3h-2.6V9.7h2.5v1.2c.4-.7 1.2-1.4 2.5-1.4 2.7 0 3.2 1.8 3.2 4.1v4.7Z"/></svg>
                            <?php esc_html_e( 'LinkedIn профіль', 'bires-theme' ); ?>
                        </a>
                    <?php endif; ?>
                    <?php if ( $has_bio ) : ?>
                        <button type="button" class="services-btn services-btn--outline-light person-hero__toggle" aria-expanded="false" aria-controls="person-bio">
                            <?php esc_html_e( 'Детальніше про адвоката', 'bires-theme' ); ?>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m6 9 6 6 6-6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        </button>
                    <?php endif; ?>
                </div>
                <?php if ( $has_bio ) : ?>
                    <div class="person-hero__bio" id="person-bio" hidden>
                        <?php if ( $position ) : ?>
                            <p class="person-hero__position"><?php echo esc_html( $position ); ?></p>
                        <?php endif; ?>
                        <?php if ( bires_field( 'team_lead' ) ) : ?>
                            <p class="person-hero__lead"><?php echo esc_html( bires_field( 'team_lead' ) ); ?></p>
                        <?php endif; ?>
                        <div class="person-hero__bio-text"><?php echo $bio; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- filtered post content ?></div>
                        <?php if ( $education ) : ?>
                            <h2 class="person-hero__subtitle"><?php esc_html_e( 'Освіта', 'bires-theme' ); ?></h2>
                            <ul class="person-hero__education">
                                <?php foreach ( $education as $row ) : ?>
                                    <li><?php echo esc_html( $row['title'] ); ?><?php echo ! empty( $row['years'] ) ? ' <span>' . esc_html( $row['years'] ) . '</span>' : ''; ?></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <?php if ( $services ) : ?>
            <section class="person-services">
                <div class="container container--wide">
                    <div class="section-label"><?php esc_html_e( 'Послуги', 'bires-theme' ); ?></div>
                    <div class="person-services__heading">
                        <div class="person-services__headline">
                            <h2 class="sp-title"><?php esc_html_e( 'Правова експертиза адвоката', 'bires-theme' ); ?></h2>
                            <p class="team-about__text"><?php esc_html_e( 'Основні напрями юридичної практики та правової допомоги.', 'bires-theme' ); ?></p>
                        </div>
                        <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--outline-dark"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
                    </div>
                    <p class="person-services__label"><?php esc_html_e( 'Сфери практики', 'bires-theme' ); ?></p>
                </div>
                <div class="person-services__track">
                    <?php foreach ( $services as $service_id ) : ?>
                        <?php $card_title = bires_field( 'service_card_title', $service_id ); ?>
                        <a class="person-service" href="<?php echo esc_url( get_permalink( $service_id ) ); ?>">
                            <span class="person-service__title"><?php echo esc_html( $card_title ? $card_title : get_the_title( $service_id ) ); ?></span>
                            <span class="service-tile__arrow"><?php echo bires_icon( 'arrow-up-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
                <?php $services_listing = bires_services_listing_id(); ?>
                <div class="person-services__more">
                    <a href="<?php echo esc_url( $services_listing ? get_permalink( $services_listing ) : bires_contact_url() ); ?>" class="services-btn services-btn--outline-dark"><?php esc_html_e( 'Дізнатись більше', 'bires-theme' ); ?></a>
                </div>
            </section>
        <?php endif; ?>

        <?php if ( $posts || $publications ) : ?>
            <section class="related-posts">
                <div class="container container--wide">
                    <div class="section-label"><?php esc_html_e( 'Новини & блог', 'bires-theme' ); ?></div>
                    <div class="related-posts__heading">
                        <h2 class="sp-title"><?php esc_html_e( 'Матеріали автора', 'bires-theme' ); ?></h2>
                    </div>
                    <?php if ( $posts ) : ?>
                        <div class="related-posts__grid<?php echo count( $posts ) > 4 ? ' has-teaser' : ''; ?>">
                            <?php foreach ( $posts as $n => $author_post ) : ?>
                                <?php $cat = get_the_category( $author_post->ID ); ?>
                                <article class="insight-card insight-card--small"<?php echo $n >= 8 ? ' data-more-item hidden' : ''; ?>>
                                    <div class="insight-card__media">
                                        <?php echo get_the_post_thumbnail( $author_post, 'medium_large', [ 'alt' => '', 'loading' => 'lazy' ] ); ?>
                                        <?php if ( $cat ) : ?>
                                            <span class="insight-card__badge"><?php echo esc_html( $cat[0]->name ); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <h3 class="insight-card__title"><a href="<?php echo esc_url( get_permalink( $author_post ) ); ?>"><?php echo esc_html( get_the_title( $author_post ) ); ?></a></h3>
                                    <p class="insight-card__meta"><?php echo esc_html( bires_post_meta_line( $author_post ) ); ?></p>
                                    <p class="insight-card__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt( $author_post ), 20 ) ); ?></p>
                                </article>
                            <?php endforeach; ?>
                        </div>
                        <?php if ( count( $posts ) > 1 ) : ?>
                            <div class="related-posts__more<?php echo count( $posts ) > 4 ? '' : ' related-posts__more--mobile'; ?>">
                                <button type="button" class="services-btn services-btn--white" data-more-btn><?php esc_html_e( 'Показати більше', 'bires-theme' ); ?></button>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if ( $publications ) : ?>
                        <h3 class="publications__title"><?php esc_html_e( 'Публікації', 'bires-theme' ); ?></h3>
                        <ul class="publications">
                            <?php foreach ( $publications as $publication ) : ?>
                                <li class="publication">
                                    <?php if ( ! empty( $publication['url'] ) ) : ?>
                                        <a href="<?php echo esc_url( $publication['url'] ); ?>" rel="noopener"><?php echo esc_html( $publication['title'] ); ?></a>
                                    <?php else : ?>
                                        <span><?php echo esc_html( $publication['title'] ); ?></span>
                                    <?php endif; ?>
                                    <?php if ( ! empty( $publication['source'] ) ) : ?>
                                        <span class="publication__source"><?php echo esc_html( $publication['source'] ); ?></span>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>
    </main>
    <?php
endwhile;

get_footer();
