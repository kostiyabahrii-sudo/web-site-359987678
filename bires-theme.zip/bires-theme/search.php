<?php
get_header();
global $wp_query;
$type_labels = [
    'post' => __( 'Стаття', 'bires-theme' ),
    'page' => __( 'Сторінка', 'bires-theme' ),
    'team' => __( 'Команда', 'bires-theme' ),
    'case' => __( 'Кейс', 'bires-theme' ),
];
?>

<main class="site-main" id="main">
    <section class="page-hero">
        <div class="container container--wide">
            <nav class="breadcrumbs" aria-label="<?php esc_attr_e( 'Навігаційний ланцюжок', 'bires-theme' ); ?>">
                <ol>
                    <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Головна', 'bires-theme' ); ?></a></li>
                    <li aria-current="page"><?php esc_html_e( 'Пошук', 'bires-theme' ); ?></li>
                </ol>
            </nav>
            <h1 class="page-hero__title">
                <?php
                /* translators: %s: search query */
                echo esc_html( sprintf( __( 'Пошук: «%s»', 'bires-theme' ), get_search_query() ) );
                ?>
            </h1>
            <form class="search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                <label class="screen-reader-text" for="search-field"><?php esc_html_e( 'Що шукаємо?', 'bires-theme' ); ?></label>
                <input type="search" id="search-field" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Що шукаємо?', 'bires-theme' ); ?>">
                <button type="submit" class="services-btn services-btn--white"><?php esc_html_e( 'Знайти', 'bires-theme' ); ?></button>
            </form>
            <p class="page-hero__meta">
                <?php
                // Українські відмінки: 1 результат, 2–4 результати, 5+ результатів
                $found = (int) $wp_query->found_posts;
                $mod10 = $found % 10;
                $mod100 = $found % 100;
                if ( 1 === $mod10 && 11 !== $mod100 ) {
                    $found_word = __( 'результат', 'bires-theme' );
                } elseif ( $mod10 >= 2 && $mod10 <= 4 && ( $mod100 < 12 || $mod100 > 14 ) ) {
                    $found_word = __( 'результати', 'bires-theme' );
                } else {
                    $found_word = __( 'результатів', 'bires-theme' );
                }
                /* translators: 1: number of results, 2: word «результатів» in the right form */
                echo esc_html( sprintf( __( 'Знайдено %1$d %2$s', 'bires-theme' ), $found, $found_word ) );
                ?>
            </p>
        </div>
    </section>

    <section class="page-body">
        <div class="container container--wide">
            <?php if ( have_posts() ) : ?>
                <ul class="search-list">
                    <?php while ( have_posts() ) : ?>
                        <?php the_post(); ?>
                        <?php
                        $result_type = get_post_type();
                        $result_label = isset( $type_labels[ $result_type ] ) ? $type_labels[ $result_type ] : '';
                        if ( 'page' === $result_type && bires_is_service_page( get_the_ID() ) ) {
                            $result_label = __( 'Послуга', 'bires-theme' );
                        }
                        ?>
                        <li class="search-result">
                            <?php if ( $result_label ) : ?>
                                <span class="search-result__type"><?php echo esc_html( $result_label ); ?></span>
                            <?php endif; ?>
                            <h2 class="search-result__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <?php
                            $result_excerpt = 'page' === $result_type && bires_is_service_page( get_the_ID() ) ? (string) bires_field( 'service_short' ) : '';
                            $result_excerpt = '' !== $result_excerpt ? $result_excerpt : get_the_excerpt();
                            ?>
                            <?php if ( $result_excerpt ) : ?>
                                <p class="search-result__excerpt"><?php echo esc_html( wp_trim_words( $result_excerpt, 28 ) ); ?></p>
                            <?php endif; ?>
                        </li>
                    <?php endwhile; ?>
                </ul>
                <?php
                the_posts_pagination( [
                    'mid_size'  => 1,
                    'prev_text' => __( 'Назад', 'bires-theme' ),
                    'next_text' => __( 'Далі', 'bires-theme' ),
                ] );
                ?>
            <?php else : ?>
                <div class="page-body__content">
                    <p><?php esc_html_e( 'Нічого не знайдено. Спробуйте інше слово або перегляньте наші послуги та статті блогу.', 'bires-theme' ); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php get_footer(); ?>
