<?php get_header(); ?>

<main class="site-main" id="main">
    <?php while ( have_posts() ) : ?>
        <?php the_post(); ?>
        <?php if ( bires_is_service_page() ) : ?>
            <?php get_template_part( 'template-parts/service-single' ); ?>
        <?php else : ?>
            <div class="container container--wide page-default">
                <h1 class="page-default__title"><?php the_title(); ?></h1>
                <div class="entry-content">
                    <?php the_content(); ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endwhile; ?>
</main>

<?php get_footer(); ?>
