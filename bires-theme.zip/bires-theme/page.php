<?php get_header(); ?>

<main class="site-main" id="main">
    <?php while ( have_posts() ) : ?>
        <?php the_post(); ?>
        <?php if ( bires_is_service_page() ) : ?>
            <?php get_template_part( 'template-parts/service-single' ); ?>
        <?php else : ?>
            <?php // Звичайна текстова сторінка (політика конфіденційності, умови використання тощо) ?>
            <section class="page-hero">
                <div class="container container--wide">
                    <nav class="breadcrumbs" aria-label="<?php esc_attr_e( 'Навігаційний ланцюжок', 'bires-theme' ); ?>">
                        <ol>
                            <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Головна', 'bires-theme' ); ?></a></li>
                            <?php foreach ( array_reverse( get_post_ancestors( get_the_ID() ) ) as $ancestor_id ) : ?>
                                <li><a href="<?php echo esc_url( get_permalink( $ancestor_id ) ); ?>"><?php echo esc_html( get_the_title( $ancestor_id ) ); ?></a></li>
                            <?php endforeach; ?>
                            <li aria-current="page"><?php the_title(); ?></li>
                        </ol>
                    </nav>
                    <h1 class="page-hero__title"><?php the_title(); ?></h1>
                    <p class="page-hero__meta">
                        <?php
                        /* translators: %s: date */
                        echo esc_html( sprintf( __( 'Оновлено: %s', 'bires-theme' ), get_the_modified_date( 'j F Y' ) ) );
                        ?>
                    </p>
                </div>
            </section>
            <section class="page-body">
                <div class="container container--wide">
                    <div class="page-body__content">
                        <?php the_content(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    <?php endwhile; ?>
</main>

<?php get_footer(); ?>
