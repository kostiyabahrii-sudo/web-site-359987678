<?php
$page_id  = get_the_ID();
$root_id  = bires_services_root_id( $page_id );
$root_id  = $root_id ? $root_id : bires_services_listing_id();
$audience = bires_field( 'service_audience', $page_id ) === 'personal' ? 'personal' : 'business';

$hero_title = bires_field( 'hero_title' );
$hero_text  = bires_field( 'hero_text' );

// Сторінка напряму (практика з підпослугами або група): повний перелік її послуг — одразу під першим екраном
$direction_items = bires_direction_services( $page_id );

$intro_text   = bires_field( 'intro_text' );
$ticket_rows  = array_filter( bires_rows( 'ticket_rows' ), function ( $r ) {
    return ! empty( $r['label'] ) || ! empty( $r['value'] );
} );
$steps        = array_filter( bires_rows( 'steps' ), function ( $r ) {
    return ! empty( $r['title'] );
} );
$results      = array_filter( bires_rows( 'results_numbers' ), function ( $r ) {
    return ! empty( $r['number'] );
} );
// Сторінка групи (податкова практика, кадри…) своїх цифр не має — цифри й заголовок як у послуг цієї групи
$results_source = $page_id;
if ( ! $results && get_post_meta( $page_id, 'bires_group_term', true ) ) {
    foreach ( $direction_items as $item ) {
        $rows = array_filter( bires_rows( 'results_numbers', $item->ID ), function ( $r ) {
            return ! empty( $r['number'] );
        } );
        if ( $rows ) {
            $results        = $rows;
            $results_source = $item->ID;
            break;
        }
    }
}
$results_title = bires_field( 'results_title', $results_source );
$results_title = $results_title ? $results_title : __( 'Результати нашої юридичної експертизи', 'bires-theme' );
// Текст під заголовком — як у макеті, якщо на сторінці свій не вписано
$results_text = bires_field( 'results_text', $results_source );
if ( '' === trim( wp_strip_all_tags( (string) $results_text ) ) ) {
    $results_text = bires_results_text_default();
}
$benefits     = array_filter( bires_rows( 'benefits' ), function ( $r ) {
    return ! empty( $r['title'] );
} );

$related_ids = bires_field( 'related_services' );
if ( ! $related_ids ) {
    // Спершу підпослуги цієї сторінки, далі сусідні послуги того ж розділу (для практик верхнього рівня — інші практики)
    $parent_id   = wp_get_post_parent_id( $page_id );
    $neighbours  = ( $parent_id && bires_is_service_page( $parent_id ) ) || ( $parent_id && $parent_id === $root_id ) ? get_pages( [ 'parent' => $parent_id, 'sort_column' => 'menu_order,post_title' ] ) : bires_top_services();
    $related_ids = [];
    // Послуги самого напряму вже є в переліку вище — у «Пов'язаних» тоді інші напрями
    foreach ( array_merge( $direction_items ? [] : get_pages( [ 'parent' => $page_id, 'sort_column' => 'menu_order,post_title' ] ), $neighbours ) as $candidate ) {
        if ( $candidate->ID !== $page_id && bires_is_service_page( $candidate->ID ) && ! in_array( $candidate->ID, $related_ids, true ) ) {
            $related_ids[] = $candidate->ID;
        }
    }
    $related_ids = array_slice( $related_ids, 0, 6 );
}
$related_ids = array_values( array_filter( (array) $related_ids, function ( $id ) {
    return 'publish' === get_post_status( $id );
} ) );

$service_posts = bires_posts_for_service( $page_id, 2 );
$faq   = array_filter( bires_rows( 'faq' ), function ( $r ) {
    return ! empty( $r['question'] ) && ! empty( $r['answer'] );
} );

$val = function ( $name, $fallback ) {
    $v = bires_field( $name );
    return $v ? $v : $fallback;
};

$nav = $direction_items ? [ 'services' => __( 'Послуги', 'bires-theme' ) ] : [];
$nav['intro'] = __( 'Інтро', 'bires-theme' );
if ( $steps ) {
    $nav['steps'] = __( 'Етапи співпраці', 'bires-theme' );
}
if ( $results ) {
    $nav['results'] = __( 'Результати', 'bires-theme' );
}
if ( $benefits ) {
    $nav['approach'] = __( 'Наш підхід', 'bires-theme' );
}
// Порядок пунктів — як порядок блоків на сторінці: спершу блог, потім пов'язані послуги
if ( $service_posts ) {
    $nav['blog'] = __( 'Блог та новини', 'bires-theme' );
}
if ( $related_ids ) {
    $nav['related'] = __( 'Пов\'язані послуги', 'bires-theme' );
}
if ( $faq ) {
    $nav['faq'] = 'FAQ';
}
$nav['contact'] = __( 'Консультація', 'bires-theme' );

$crumb_label = 'personal' === $audience ? __( 'Послуги для фізичних осіб', 'bires-theme' ) : __( 'Послуги для бізнесу', 'bires-theme' );
$ancestors   = array_filter( array_reverse( get_post_ancestors( $page_id ) ), function ( $id ) use ( $root_id ) {
    return $id !== $root_id && bires_is_service_page( $id );
} );
?>

<section class="services-hero services-hero--single">
    <div class="container container--wide">
        <div class="services-hero__content">
            <nav class="breadcrumbs" aria-label="<?php esc_attr_e( 'Навігаційний ланцюжок', 'bires-theme' ); ?>">
                <ol>
                    <?php if ( $root_id ) : ?>
                        <li><a href="<?php echo esc_url( get_permalink( $root_id ) ); ?>"><?php echo esc_html( $crumb_label ); ?></a></li>
                    <?php endif; ?>
                    <?php foreach ( $ancestors as $ancestor_id ) : ?>
                        <li><a href="<?php echo esc_url( get_permalink( $ancestor_id ) ); ?>"><?php echo esc_html( get_the_title( $ancestor_id ) ); ?></a></li>
                    <?php endforeach; ?>
                    <li aria-current="page"><?php the_title(); ?></li>
                </ol>
            </nav>
            <h1 class="services-hero__title"><?php echo esc_html( $hero_title ? $hero_title : get_the_title() ); ?></h1>
            <?php if ( $hero_text ) : ?>
                <?php // Текст — повністю, без «Читати далі» ?>
                <p class="services-hero__desc services-hero__desc--narrow"><?php echo esc_html( $hero_text ); ?></p>
            <?php endif; ?>
            <a href="#contact" class="services-btn services-btn--white"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
        </div>
    </div>
</section>

<nav class="subnav" aria-label="<?php esc_attr_e( 'Розділи сторінки', 'bires-theme' ); ?>">
    <div class="container container--wide">
        <ul class="subnav__list">
            <?php foreach ( $nav as $anchor => $label ) : ?>
                <li><a class="subnav__link" href="#<?php echo esc_attr( $anchor ); ?>"><?php echo esc_html( $label ); ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>
</nav>

<?php if ( $direction_items ) : ?>
    <section class="sp-directions" id="services">
        <div class="container container--wide">
            <div class="section-label"><?php esc_html_e( 'Послуги', 'bires-theme' ); ?></div>
            <?php
            // Заголовок і короткий підсумок ліворуч, перелік послуг рядками праворуч (як «Результати» й FAQ у макеті)
            $count = count( $direction_items );
            $lead  = sprintf(
                /* translators: 1: "5 послуг", 2: direction name */
                __( '%1$s у напрямі «%2$s».', 'bires-theme' ),
                bires_services_count_label( $count ),
                wp_strip_all_tags( get_the_title( $page_id ) )
            ) . ' ' . ( $count > 1 ? __( 'Оберіть потрібну — на сторінці послуги деталі, етапи й вартість.', 'bires-theme' ) : __( 'На сторінці послуги деталі, етапи й вартість.', 'bires-theme' ) );
            ?>
            <div class="sp-directions__layout">
                <div class="sp-directions__head">
                    <h2 class="sp-title"><?php echo esc_html( 1 === $count ? __( 'Послуга напряму', 'bires-theme' ) : __( 'Послуги напряму', 'bires-theme' ) ); ?></h2>
                    <p class="sp-directions__lead"><?php echo bires_nbsp_title( $lead ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside ?></p>
                </div>
                <ol class="sp-directions__list">
                    <?php foreach ( array_values( $direction_items ) as $i => $item ) : ?>
                        <li>
                            <a class="sp-direction" href="<?php echo esc_url( get_permalink( $item ) ); ?>">
                                <span class="sp-direction__num" aria-hidden="true"><?php echo esc_html( sprintf( '%02d', $i + 1 ) ); ?></span>
                                <span class="sp-direction__title"><?php echo bires_nbsp_title( get_the_title( $item ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside ?></span>
                                <span class="sp-direction__arrow" aria-hidden="true"><?php echo bires_icon( 'arrow-up-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ol>
            </div>
        </div>
    </section>
<?php endif; ?>

<section class="sp-intro" id="intro">
    <div class="container container--wide sp-intro__inner">
        <div class="sp-intro__headline">
            <h2 class="sp-title"><?php echo esc_html( $val( 'intro_title', __( 'Практика', 'bires-theme' ) ) ); ?></h2>
            <?php if ( $intro_text ) : ?>
                <?php // Текст практики — повністю, без «Читати далі» ?>
                <div class="sp-lead sp-lead--rich"><?php echo wp_kses_post( wpautop( $intro_text ) ); ?></div>
            <?php endif; ?>
            <a href="#contact" class="services-btn services-btn--outline-dark"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
        </div>
        <div class="sp-intro__card">
            <div class="sp-intro__info">
                <span class="sp-intro__info-icon"><?php echo bires_icon( 'briefcase' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                <div>
                    <h3 class="sp-intro__info-title"><?php echo esc_html( $val( 'intro_card_title', __( 'Вартість та строки', 'bires-theme' ) ) ); ?></h3>
                    <p class="sp-intro__info-text"><?php echo esc_html( bires_intro_card_text( $val( 'intro_card_text', __( 'залежать від складності послуги та узгоджуються індивідуально', 'bires-theme' ) ) ) ); ?></p>
                </div>
            </div>
            <?php
            if ( ! $ticket_rows ) {
                $ticket_rows = [
                    [ 'label' => __( 'Статус', 'bires-theme' ), 'value' => __( 'Запит на правову допомогу', 'bires-theme' ) ],
                    [ 'label' => __( 'Перший етап', 'bires-theme' ), 'value' => __( 'Консультація з юристом', 'bires-theme' ) ],
                    [ 'label' => __( 'Вартість', 'bires-theme' ), 'value' => __( 'Визначається після консультації', 'bires-theme' ) ],
                    [ 'label' => __( 'Строки', 'bires-theme' ), 'value' => __( 'Узгоджуються індивідуально', 'bires-theme' ) ],
                ];
            }
            $ticket_groups = array_chunk( array_values( $ticket_rows ), 2 );
            ?>
            <div class="ticket">
                <div class="ticket__head">
                    <span class="ticket__check"><svg width="24" height="24" viewBox="12 12 24 24" fill="none" aria-hidden="true" focusable="false"><path fill="currentColor" d="M29 15.34C30.51 16.21 31.76 17.46 32.64 18.97C33.52 20.47 33.99 22.18 34 23.92C34.01 25.66 33.57 27.38 32.72 28.89C31.87 30.41 30.63 31.68 29.14 32.58C27.65 33.47 25.94 33.96 24.2 34C22.46 34.03 20.74 33.61 19.21 32.78C17.68 31.95 16.4 30.73 15.48 29.24C14.57 27.76 14.06 26.06 14.01 24.32L14 24L14.01 23.68C14.06 21.95 14.56 20.27 15.46 18.79C16.36 17.32 17.63 16.1 19.14 15.26C20.65 14.42 22.35 13.99 24.08 14C25.81 14.01 27.5 14.48 29 15.34ZM27.71 21.29C27.53 21.12 27.31 21.02 27.06 21C26.82 20.99 26.58 21.06 26.39 21.21L26.29 21.29L23 24.59L21.71 23.29L21.61 23.21C21.42 23.06 21.18 22.99 20.94 23C20.69 23.02 20.47 23.12 20.29 23.29C20.12 23.47 20.02 23.69 20 23.94C19.99 24.18 20.06 24.42 20.21 24.61L20.29 24.71L22.29 26.71L22.39 26.79C22.56 26.93 22.78 27 23 27C23.22 27 23.44 26.93 23.61 26.79L23.71 26.71L27.71 22.71L27.79 22.61C27.94 22.42 28.01 22.18 28 21.94C27.98 21.69 27.88 21.47 27.71 21.29Z"/></svg></span>
                    <span class="ticket__title"><?php echo esc_html( $val( 'ticket_title', __( 'Оцінка справи', 'bires-theme' ) ) ); ?></span>
                </div>
                <?php foreach ( $ticket_groups as $group ) : ?>
                    <dl class="ticket__group">
                        <?php foreach ( $group as $row ) : ?>
                            <div class="ticket__row">
                                <dt><?php echo esc_html( $row['label'] ); ?></dt>
                                <dd><?php echo esc_html( $row['value'] ); ?></dd>
                            </div>
                        <?php endforeach; ?>
                    </dl>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<?php if ( $steps ) : ?>
    <?php
    // Як у макеті: ліворуч заголовок, текст і кнопка (липнуть при прокрутці, як у «Послуги напряму»),
    // праворуч — етапи вертикальною стрічкою зі скляними іконками. Поточний етап світиться, від нього до наступного — лінія
    $steps      = array_values( $steps );
    $step_icons = [ 'chat', 'shield', 'file', 'scales', 'folder', 'briefcase', 'document', 'wallet' ];
    $steps_text = bires_field( 'steps_text' );
    ?>
    <section class="sp-steps" id="steps">
        <div class="container container--wide">
            <div class="section-label"><?php esc_html_e( 'Етапи співпраці', 'bires-theme' ); ?></div>
            <div class="sp-steps__layout">
                <div class="sp-steps__head">
                    <div class="sp-steps__headline">
                        <h2 class="sp-title"><?php echo esc_html( $val( 'steps_title', __( 'Як ми працюємо', 'bires-theme' ) ) ); ?></h2>
                        <p class="sp-lead"><?php echo esc_html( $steps_text ? $steps_text : __( 'Знайдіть швидкі відповіді на запитання, як наша команда адвокатів надає наступні послуги.', 'bires-theme' ) ); ?></p>
                    </div>
                    <a href="#contact" class="services-btn services-btn--white"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
                </div>
                <ol class="sp-steps__list" data-steps>
                    <?php foreach ( $steps as $i => $step ) : ?>
                        <li class="sp-step<?php echo 0 === $i ? ' is-active' : ''; ?>">
                            <span class="sp-step__icon" aria-hidden="true"><?php echo bires_icon( ! empty( $step['icon'] ) ? $step['icon'] : $step_icons[ $i % count( $step_icons ) ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                            <div class="sp-step__text">
                                <h3 class="sp-step__title"><?php echo esc_html( $step['title'] ); ?></h3>
                                <?php if ( ! empty( $step['text'] ) ) : ?>
                                    <p><?php echo nl2br( esc_html( $step['text'] ) ); ?></p>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ol>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php if ( $results ) : ?>
    <section class="sp-results" id="results">
        <div class="container container--wide">
            <div class="section-label"><?php esc_html_e( 'Результати', 'bires-theme' ); ?></div>
            <div class="sp-results__top">
                <div class="sp-results__logo" aria-hidden="true">BIRES</div>
                <div class="sp-results__text">
                    <h2 class="sp-title"><?php echo esc_html( $results_title ); ?></h2>
                    <div class="sp-results__body"><?php echo wp_kses_post( $results_text ); ?></div>
                </div>
            </div>
            <div class="sp-results__numbers">
                <?php foreach ( $results as $result ) : ?>
                    <div class="sp-number">
                        <span class="sp-number__value" style="--ink: <?php echo esc_attr( bires_ink_offset( $result['number'] ) ); ?>"><?php echo esc_html( $result['number'] ); ?></span>
                        <span class="sp-number__label"><?php echo esc_html( $result['label'] ); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php if ( $benefits ) : ?>
    <?php $benefits_track = 'benefits-track-' . wp_unique_id(); ?>
    <section class="sp-benefits" id="approach">
        <div class="container container--wide">
            <div class="section-label"><?php esc_html_e( 'Наш підхід', 'bires-theme' ); ?></div>
            <div class="sp-benefits__heading">
                <div class="sp-benefits__headline">
                    <h2 class="sp-title"><?php echo esc_html( $val( 'benefits_title', __( 'Що ви отримаєте', 'bires-theme' ) ) ); ?></h2>
                    <?php if ( bires_field( 'benefits_text' ) ) : ?>
                        <p class="sp-lead"><?php echo esc_html( bires_field( 'benefits_text' ) ); ?></p>
                    <?php endif; ?>
                </div>
                <?php // Стрілки лише коли карток більше, ніж вміщується (slider.js ховає їх сам) ?>
                <div class="slider-arrows" data-slider-controls="<?php echo esc_attr( $benefits_track ); ?>">
                    <button type="button" class="slider-arrow" data-dir="-1" aria-label="<?php esc_attr_e( 'Назад', 'bires-theme' ); ?>"><?php echo bires_icon( 'arrow-left', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></button>
                    <button type="button" class="slider-arrow" data-dir="1" aria-label="<?php esc_attr_e( 'Вперед', 'bires-theme' ); ?>"><?php echo bires_icon( 'arrow-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></button>
                </div>
            </div>
        </div>
        <?php // Як у макеті: 4 картки в ширину вмісту сторінки; п'ята й далі — за стрілками, нічого не обрізається краєм екрана ?>
        <div class="sp-benefits__wrap">
        <div class="sp-benefits__track" id="<?php echo esc_attr( $benefits_track ); ?>">
            <?php foreach ( array_values( $benefits ) as $i => $benefit ) : ?>
                <div class="sp-benefit">
                    <span class="sp-benefit__icon"><?php echo bires_benefit_icon( $benefit['icon'], $i ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside ?></span>
                    <div>
                        <h3 class="sp-benefit__title"><?php echo esc_html( $benefit['title'] ); ?></h3>
                        <?php if ( ! empty( $benefit['text'] ) ) : ?>
                            <p class="sp-benefit__text"><?php echo esc_html( $benefit['text'] ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        </div>
    </section>
<?php endif; ?>

<?php get_template_part( 'template-parts/blog-preview', null, [ 'layout' => 'pair', 'posts' => $service_posts ] ); ?>
<?php get_template_part( 'template-parts/related-services', null, [ 'ids' => $related_ids ] ); ?>
<?php get_template_part( 'template-parts/faq' ); ?>
<?php get_template_part( 'template-parts/seo-text' ); ?>
<?php get_template_part( 'template-parts/contact-section' ); ?>
