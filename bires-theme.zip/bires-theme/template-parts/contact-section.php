<?php
$email      = bires_option( 'contact_email', 'info@bires.com.ua' );
$phone      = bires_option( 'contact_phone_1', '(+380) 44 334 75 04' );
$manager_id = bires_option( 'contact_manager' );
$proof      = bires_option( 'clients_count_text', __( '1,000+ клієнтів обрали нашу юридичну команду', 'bires-theme' ) );
?>
<section class="contact-section" id="contact">
    <div class="container container--wide">
        <div class="contact-card">
            <div class="contact-card__form">
                <div class="contact-card__heading">
                    <h2><?php esc_html_e( 'Чи маєте ще питання?', 'bires-theme' ); ?></h2>
                    <p class="contact-card__lead"><?php esc_html_e( 'Ми зв’яжемося з вами протягом одного робочого дня або ви можете зв’язатися з нами самостійно 👉', 'bires-theme' ); ?></p>
                    <p class="contact-card__lead contact-card__lead--mobile"><?php esc_html_e( 'Зв’яжемося з вами протягом робочого дня.', 'bires-theme' ); ?></p>
                </div>
                <?php get_template_part( 'template-parts/contact-form', null, [ 'variant' => 'light' ] ); ?>
            </div>
            <div class="contact-card__manager">
                <div class="contact-manager__top">
                    <?php if ( $manager_id ) : ?>
                        <div class="contact-manager__person">
                            <div class="contact-manager__photo">
                                <?php echo get_the_post_thumbnail( $manager_id, 'thumbnail', [ 'loading' => 'lazy', 'alt' => get_the_title( $manager_id ) ] ); ?>
                            </div>
                            <div class="contact-manager__details">
                                <div class="contact-manager__name"><?php echo esc_html( get_the_title( $manager_id ) ); ?></div>
                                <div class="contact-manager__role"><?php echo esc_html( bires_field( 'team_position', $manager_id ) ); ?></div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="contact-manager__actions">
                        <a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $phone ) ); ?>" class="contact-manager__btn">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M17.5 13.13v2.5a1.25 1.25 0 0 1-1.36 1.25 12.37 12.37 0 0 1-5.4-1.92 12.2 12.2 0 0 1-3.75-3.75 12.37 12.37 0 0 1-1.92-5.43A1.25 1.25 0 0 1 6.31 4.4h2.5a1.25 1.25 0 0 1 1.25 1.08c.08.63.23 1.25.44 1.85a1.25 1.25 0 0 1-.28 1.32l-1.06 1.06a10 10 0 0 0 3.75 3.75l1.06-1.06a1.25 1.25 0 0 1 1.32-.28c.6.21 1.22.36 1.85.44a1.25 1.25 0 0 1 1.36 1.32Z" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            <?php esc_html_e( 'Зателефонуйте нам', 'bires-theme' ); ?>
                        </a>
                        <a href="mailto:<?php echo esc_attr( antispambot( $email ) ); ?>" class="contact-manager__btn">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true"><rect x="2.5" y="4.17" width="15" height="11.67" rx="1.67" stroke="black" stroke-width="1.5"/><path d="m3.33 5.83 6.67 5 6.67-5" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            <?php esc_html_e( 'Напишіть нам на пошту', 'bires-theme' ); ?>
                        </a>
                        <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="contact-manager__btn">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true"><rect x="2.5" y="5.83" width="10" height="8.33" rx="1.67" stroke="black" stroke-width="1.5"/><path d="m14.17 8.33 3.33-2.08v7.5l-3.33-2.08" stroke="black" stroke-width="1.5" stroke-linejoin="round"/></svg>
                            <?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?>
                        </a>
                    </div>
                </div>
                <div class="contact-manager__proof">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 2 4 5v6c0 5.25 3.4 9.74 8 11 4.6-1.26 8-5.75 8-11V5l-8-3Z" stroke="white" stroke-width="1.5" stroke-linejoin="round"/><path d="m9 12 2 2 4-4" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    <span><?php echo esc_html( $proof ); ?></span>
                </div>
            </div>
        </div>
    </div>
</section>
