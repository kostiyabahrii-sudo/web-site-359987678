<?php
/**
 * Args: id => team member ID, variant => 'dark' | 'light', heading => h2|h3.
 */
$member_id = (int) $args['id'];
$variant   = isset( $args['variant'] ) ? $args['variant'] : 'dark';
$tag       = isset( $args['heading'] ) ? $args['heading'] : 'h3';
$position  = bires_field( 'team_position', $member_id );
$linkedin  = bires_team_linkedin( $member_id );
$bio       = trim( (string) get_post_field( 'post_content', $member_id ) );
$positions = implode( '<span class="person-card__dot" aria-hidden="true"></span>', array_map( 'esc_html', array_map( 'trim', explode( '•', (string) $position ) ) ) );
?>
<article class="person-card person-card--<?php echo esc_attr( $variant ); ?>">
    <div class="person-card__photo">
        <?php echo get_the_post_thumbnail( $member_id, 'medium_large', [ 'alt' => esc_attr( get_the_title( $member_id ) ), 'loading' => 'lazy' ] ); ?>
    </div>
    <div class="person-card__details">
        <<?php echo esc_attr( $tag ); ?> class="person-card__name">
            <a href="<?php echo esc_url( get_permalink( $member_id ) ); ?>"><?php echo esc_html( get_the_title( $member_id ) ); ?></a>
        </<?php echo esc_attr( $tag ); ?>>
        <div class="person-card__row">
            <span class="person-card__position"><?php echo $positions; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped parts ?></span>
            <span class="person-card__links">
                <?php if ( $linkedin ) : ?>
                    <a class="person-card__icon" href="<?php echo esc_url( $linkedin ); ?>" rel="noopener" aria-label="<?php echo esc_attr( sprintf( 'LinkedIn: %s', get_the_title( $member_id ) ) ); ?>">
                        <svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M20 2H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2ZM8.3 18.3H5.7V9.7h2.6v8.6ZM7 8.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Zm11.3 9.8h-2.6v-4.2c0-1 0-2.3-1.4-2.3s-1.6 1.1-1.6 2.2v4.3h-2.6V9.7h2.5v1.2c.4-.7 1.2-1.4 2.5-1.4 2.7 0 3.2 1.8 3.2 4.1v4.7Z"/></svg>
                    </a>
                <?php endif; ?>
            </span>
        </div>
    </div>
    <?php if ( '' !== trim( wp_strip_all_tags( $bio ) ) ) : ?>
        <?php // Розгорнута картка: на комп'ютері з'являється, якщо курсор секунду тримається на плашці з ім'ям (assets/js/team.js) ?>
        <div class="person-card__panel" aria-hidden="true">
            <div class="person-card__panel-head">
                <a class="person-card__thumb" href="<?php echo esc_url( get_permalink( $member_id ) ); ?>" tabindex="-1"><?php echo get_the_post_thumbnail( $member_id, 'thumbnail', [ 'alt' => '', 'loading' => 'lazy' ] ); ?></a>
                <p class="person-card__name"><a href="<?php echo esc_url( get_permalink( $member_id ) ); ?>" tabindex="-1"><?php echo esc_html( get_the_title( $member_id ) ); ?></a></p>
                <div class="person-card__row">
                    <span class="person-card__position"><?php echo $positions; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped parts ?></span>
                    <?php if ( $linkedin ) : ?>
                        <a class="person-card__icon" href="<?php echo esc_url( $linkedin ); ?>" rel="noopener" tabindex="-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M20 2H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2ZM8.3 18.3H5.7V9.7h2.6v8.6ZM7 8.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Zm11.3 9.8h-2.6v-4.2c0-1 0-2.3-1.4-2.3s-1.6 1.1-1.6 2.2v4.3h-2.6V9.7h2.5v1.2c.4-.7 1.2-1.4 2.5-1.4 2.7 0 3.2 1.8 3.2 4.1v4.7Z"/></svg>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="person-card__bio"><?php echo wp_kses_post( wpautop( strip_shortcodes( $bio ) ) ); ?></div>
        </div>
    <?php endif; ?>
</article>
