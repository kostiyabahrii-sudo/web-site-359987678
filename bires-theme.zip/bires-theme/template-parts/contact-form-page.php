<?php
$form_id    = $args['form_id'];
$sent       = $args['sent'];
$root_id    = bires_services_listing_id();
$practices  = $root_id ? get_pages( [ 'parent' => $root_id, 'sort_column' => 'menu_order,post_title' ] ) : [];
// Галузі права групуються «Бізнес» / «Фізичні особи», щоб однакові назви не дублювались без пояснення.
$practice_groups = [
    'business' => [ 'label' => __( 'Бізнес', 'bires-theme' ), 'options' => [] ],
    'personal' => [ 'label' => __( 'Фізичні особи', 'bires-theme' ), 'options' => [] ],
];
foreach ( $practices as $practice ) {
    $audience       = 'personal' === bires_field( 'service_audience', $practice->ID ) ? 'personal' : 'business';
    $practice_title = bires_field( 'service_card_title', $practice->ID );
    $practice_title = trim( preg_replace( '/\s+/', ' ', $practice_title ? $practice_title : $practice->post_title ) );
    $practice_groups[ $audience ]['options'][ $practice_title . ' (' . $practice_groups[ $audience ]['label'] . ')' ] = $practice_title;
}
$practice_groups = array_values( array_filter( $practice_groups, function ( $group ) {
    return ! empty( $group['options'] );
} ) );
$required   = '<span class="cf-page__req" aria-hidden="true">*</span>';
$optional   = ' <span class="cf-page__opt">' . esc_html__( '(опційно)', 'bires-theme' ) . '</span>';
?>
<?php if ( 'ok' === $sent ) : ?>
    <p class="contact-form__notice" role="status"><?php esc_html_e( 'Дякуємо! Ми зв’яжемося з вами найближчим часом.', 'bires-theme' ); ?></p>
<?php elseif ( 'error' === $sent ) : ?>
    <p class="contact-form__notice contact-form__notice--error" role="alert"><?php esc_html_e( 'Не вдалося надіслати запит. Перевірте ім’я та телефон і спробуйте ще раз.', 'bires-theme' ); ?></p>
<?php endif; ?>
<form class="cf-page" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
    <input type="hidden" name="action" value="bires_contact">
    <?php wp_nonce_field( 'bires_contact', 'bires_contact_nonce' ); ?>
    <div class="contact-form__hp" aria-hidden="true">
        <label for="<?php echo esc_attr( $form_id ); ?>-website">Website</label>
        <input type="text" id="<?php echo esc_attr( $form_id ); ?>-website" name="website" tabindex="-1" autocomplete="off">
    </div>
    <div class="cf-page__fields">
        <div class="cf-page__field">
            <label for="<?php echo esc_attr( $form_id ); ?>-name"><?php esc_html_e( 'Ім’я та прізвище', 'bires-theme' ); ?><?php echo $required; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static markup ?></label>
            <input class="cf-page__input" type="text" id="<?php echo esc_attr( $form_id ); ?>-name" name="name" placeholder="<?php esc_attr_e( 'Ваше ім’я та прізвище', 'bires-theme' ); ?>" autocomplete="name" required>
        </div>
        <div class="cf-page__field">
            <label for="<?php echo esc_attr( $form_id ); ?>-phone"><?php esc_html_e( 'Номер телефону', 'bires-theme' ); ?><?php echo $required; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static markup ?></label>
            <div class="cf-page__phone">
                <?php echo bires_phone_code_dropdown( $form_id, 'cf-page__code', 'dark' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside ?>
                <input type="tel" id="<?php echo esc_attr( $form_id ); ?>-phone" name="phone" placeholder="67 123 45 67" data-ph-other="<?php esc_attr_e( 'Код країни та номер', 'bires-theme' ); ?>" autocomplete="tel-national" required>
            </div>
        </div>
        <div class="cf-page__row">
            <div class="cf-page__field">
                <label for="<?php echo esc_attr( $form_id ); ?>-type"><?php esc_html_e( 'Хто звертається?', 'bires-theme' ); ?><?php echo $optional; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?></label>
                <div class="cf-page__select">
                    <?php
                    $client_types = [ __( 'Фізична особа', 'bires-theme' ), __( 'Юридична особа', 'bires-theme' ) ];
                    echo bires_dropdown( $form_id . '-type', 'client_type', [ [ 'label' => '', 'options' => array_combine( $client_types, $client_types ) ] ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside
                    ?>
                </div>
            </div>
            <div class="cf-page__field">
                <label for="<?php echo esc_attr( $form_id ); ?>-practice"><?php esc_html_e( 'Галузь права', 'bires-theme' ); ?><?php echo $optional; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?></label>
                <div class="cf-page__select">
                    <?php echo bires_dropdown( $form_id . '-practice', 'practice', $practice_groups, __( 'Оберіть галузь права', 'bires-theme' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside ?>
                </div>
            </div>
        </div>
    </div>
    <button type="submit" class="cf-page__submit"><?php esc_html_e( 'Отримати консультацію', 'bires-theme' ); ?></button>
</form>
