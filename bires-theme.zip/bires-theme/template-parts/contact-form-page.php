<?php
$form_id    = $args['form_id'];
$sent       = $args['sent'];
$root_id    = bires_services_listing_id();
$practices  = $root_id ? get_pages( [ 'parent' => $root_id, 'sort_column' => 'menu_order,post_title' ] ) : [];
$chevron    = '<svg class="cf-page__chevron" width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m6 9 6 6 6-6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
$required   = '<span class="cf-page__req" aria-hidden="true">*</span>';
$optional   = ' <span class="cf-page__opt">' . esc_html__( '(опційно)', 'bires-theme' ) . '</span>';
?>
<?php if ( 'ok' === $sent ) : ?>
    <p class="contact-form__notice" role="status"><?php esc_html_e( 'Дякуємо! Ми зв’яжемося з вами найближчим часом.', 'bires-theme' ); ?></p>
<?php elseif ( 'error' === $sent ) : ?>
    <p class="contact-form__notice contact-form__notice--error" role="alert"><?php esc_html_e( 'Не вдалося надіслати запит. Перевірте ім’я та телефон і спробуйте ще раз.', 'bires-theme' ); ?></p>
<?php endif; ?>
<form class="cf-page" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
    <input type="hidden" name="action" value="bires_contact">
    <?php wp_nonce_field( 'bires_contact', 'bires_contact_nonce' ); ?>
    <div class="contact-form__hp" aria-hidden="true">
        <label for="<?php echo esc_attr( $form_id ); ?>-website">Website</label>
        <input type="text" id="<?php echo esc_attr( $form_id ); ?>-website" name="website" tabindex="-1" autocomplete="off">
    </div>
    <div class="cf-page__fields">
        <div class="cf-page__field">
            <label for="<?php echo esc_attr( $form_id ); ?>-name"><?php esc_html_e( 'Ім’я та прізвище', 'bires-theme' ); ?><?php echo $required; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static markup ?></label>
            <input class="cf-page__input" type="text" id="<?php echo esc_attr( $form_id ); ?>-name" name="name" placeholder="<?php esc_attr_e( 'Ваше ім’я та прізвище', 'bires-theme' ); ?>" autocomplete="name" required>
        </div>
        <div class="cf-page__field">
            <label for="<?php echo esc_attr( $form_id ); ?>-phone"><?php esc_html_e( 'Номер телефону', 'bires-theme' ); ?><?php echo $required; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static markup ?></label>
            <div class="cf-page__phone">
                <span class="cf-page__code">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M0 12C0 5.373 5.373 0 12 0s12 5.373 12 12H0Z" fill="#005BBB"/><path d="M24 12c0 6.627-5.373 12-12 12S0 18.627 0 12h24Z" fill="#FFD500"/></svg>
                    +380
                    <?php echo $chevron; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?>
                </span>
                <input type="tel" id="<?php echo esc_attr( $form_id ); ?>-phone" name="phone" placeholder="67 123 45 67" autocomplete="tel-national" required>
            </div>
        </div>
        <div class="cf-page__row">
            <div class="cf-page__field">
                <label for="<?php echo esc_attr( $form_id ); ?>-type"><?php esc_html_e( 'Хто звертається?', 'bires-theme' ); ?><?php echo $optional; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?></label>
                <div class="cf-page__select">
                    <select id="<?php echo esc_attr( $form_id ); ?>-type" name="client_type">
                        <option><?php esc_html_e( 'Фізична особа', 'bires-theme' ); ?></option>
                        <option><?php esc_html_e( 'Юридична особа', 'bires-theme' ); ?></option>
                    </select>
                    <?php echo $chevron; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?>
                </div>
            </div>
            <div class="cf-page__field">
                <label for="<?php echo esc_attr( $form_id ); ?>-practice"><?php esc_html_e( 'Галузь права', 'bires-theme' ); ?><?php echo $optional; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?></label>
                <div class="cf-page__select">
                    <select id="<?php echo esc_attr( $form_id ); ?>-practice" name="practice">
                        <option value=""><?php esc_html_e( 'Оберіть галузь права', 'bires-theme' ); ?></option>
                        <?php foreach ( $practices as $practice ) : ?>
                            <?php $practice_title = bires_field( 'service_card_title', $practice->ID ); ?>
                            <option><?php echo esc_html( $practice_title ? $practice_title : $practice->post_title ); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php echo $chevron; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?>
                </div>
            </div>
        </div>
    </div>
    <button type="submit" class="cf-page__submit"><?php esc_html_e( 'Отримати консультацію', 'bires-theme' ); ?></button>
</form>
