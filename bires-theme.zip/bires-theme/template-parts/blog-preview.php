<?php
/**
 * Args: layout => 'pair' | 'mixed', posts => WP_Post[], id => anchor id.
 */
$layout = isset( $args['layout'] ) ? $args['layout'] : 'mixed';
$preview_posts = isset( $args['posts'] ) ? $args['posts'] : [];
$anchor = isset( $args['id'] ) ? $args['id'] : 'blog';

if ( ! $preview_posts ) {
    return;
}

$blog_url = get_option( 'page_for_posts' ) ? get_permalink( get_option( 'page_for_posts' ) ) : home_url( '/' );
?>
<section class="insights" id="<?php echo esc_attr( $anchor ); ?>">
    <div class="container container--wide">
        <div class="section-label"><?php esc_html_e( 'Новини & блог', 'bires-theme' ); ?></div>
        <div class="insights__heading">
            <div class="insights__headline">
                <h2 class="insights__title"><?php esc_html_e( 'Правові інсайти', 'bires-theme' ); ?></h2>
                <p class="insights__text"><?php esc_html_e( 'Настав час вирішити свої юридичні питання? Почніть зараз.', 'bires-theme' ); ?></p>
            </div>
            <a href="<?php echo esc_url( $blog_url ); ?>" class="services-btn services-btn--outline-light"><?php esc_html_e( 'Переглянути всі статті', 'bires-theme' ); ?></a>
        </div>

        <div class="insights__grid insights__grid--<?php echo esc_attr( $layout ); ?>">
            <?php foreach ( $preview_posts as $i => $post_item ) : ?>
                <?php
                $is_large = 'pair' === $layout || 0 === $i;
                $category = get_the_category( $post_item->ID );
                $category = $category ? $category[0]->name : '';
                $excerpt  = wp_trim_words( get_the_excerpt( $post_item ), 24 );
                ?>
                <?php if ( $is_large ) : ?>
                    <article class="insight-card insight-card--large">
                        <?php if ( has_post_thumbnail( $post_item ) ) : ?>
                            <?php echo get_the_post_thumbnail( $post_item, 'large', [ 'class' => 'insight-card__bg', 'loading' => 'lazy', 'alt' => '' ] ); ?>
                        <?php endif; ?>
                        <?php if ( $category ) : ?>
                            <span class="insight-card__badge"><?php echo esc_html( $category ); ?></span>
                        <?php endif; ?>
                        <div class="insight-card__bottom">
                            <div class="insight-card__texts">
                                <h3 class="insight-card__title"><a href="<?php echo esc_url( get_permalink( $post_item ) ); ?>"><?php echo esc_html( get_the_title( $post_item ) ); ?></a></h3>
                                <p class="insight-card__excerpt"><?php echo esc_html( $excerpt ); ?></p>
                            </div>
                            <span class="insight-card__btn" aria-hidden="true"><?php esc_html_e( 'Читати далі', 'bires-theme' ); ?></span>
                        </div>
                    </article>
                <?php else : ?>
                    <article class="insight-card insight-card--small">
                        <div class="insight-card__media">
                            <?php if ( has_post_thumbnail( $post_item ) ) : ?>
                                <?php echo get_the_post_thumbnail( $post_item, 'medium_large', [ 'loading' => 'lazy', 'alt' => '' ] ); ?>
                            <?php endif; ?>
                            <?php if ( $category ) : ?>
                                <span class="insight-card__badge"><?php echo esc_html( $category ); ?></span>
                            <?php endif; ?>
                        </div>
                        <h3 class="insight-card__title"><a href="<?php echo esc_url( get_permalink( $post_item ) ); ?>"><?php echo esc_html( get_the_title( $post_item ) ); ?></a></h3>
                        <p class="insight-card__excerpt"><?php echo esc_html( $excerpt ); ?></p>
                        <span class="insight-card__btn insight-card__btn--mobile" aria-hidden="true"><?php esc_html_e( 'Читати далі', 'bires-theme' ); ?></span>
                    </article>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
</section>
