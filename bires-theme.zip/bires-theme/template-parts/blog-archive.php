<?php
$blog_page_id = (int) get_option( 'page_for_posts' );
$heading      = is_category() || is_tag() ? single_term_title( '', false ) : ( $blog_page_id ? bires_field( 'hero_title', $blog_page_id ) : '' );
$heading      = $heading ? $heading : __( 'Що варто прочитати', 'bires-theme' );
$categories   = get_categories( [ 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 12 ] );
$current_cat  = is_category() ? get_queried_object_id() : 0;
$all_url      = $blog_page_id ? get_permalink( $blog_page_id ) : home_url( '/' );
?>
<section class="blog-archive">
    <div class="container container--wide">
        <div class="blog-archive__top">
            <h1 class="blog-archive__title"><?php echo esc_html( $heading ); ?></h1>
            <?php if ( $categories ) : ?>
                <nav class="blog-filter" aria-label="<?php esc_attr_e( 'Категорії', 'bires-theme' ); ?>">
                    <a class="blog-filter__item<?php echo $current_cat ? '' : ' is-active'; ?>" href="<?php echo esc_url( $all_url ); ?>"<?php echo $current_cat ? '' : ' aria-current="page"'; ?>><?php esc_html_e( 'Усі дописи', 'bires-theme' ); ?></a>
                    <?php foreach ( $categories as $category ) : ?>
                        <?php $active = $current_cat === (int) $category->term_id; ?>
                        <a class="blog-filter__item<?php echo $active ? ' is-active' : ''; ?>" href="<?php echo esc_url( get_category_link( $category ) ); ?>"<?php echo $active ? ' aria-current="page"' : ''; ?> title="<?php echo esc_attr( $category->name ); ?>"><?php echo esc_html( bires_category_label( $category ) ); ?></a>
                    <?php endforeach; ?>
                </nav>
            <?php endif; ?>
        </div>

        <?php if ( have_posts() ) : ?>
            <div class="blog-grid">
                <?php
                $i = 0;
                while ( have_posts() ) :
                    the_post();
                    $large    = $i < 2;
                    $category = get_the_category();
                    ?>
                    <article class="blog-tile<?php echo $large ? ' blog-tile--large' : ''; ?>">
                        <div class="blog-tile__media">
                            <?php
                            if ( has_post_thumbnail() ) {
                                the_post_thumbnail( $large ? 'large' : 'medium_large', [ 'alt' => '', 'loading' => $i < 2 ? 'eager' : 'lazy', 'fetchpriority' => 0 === $i ? 'high' : 'auto' ] );
                            }
                            ?>
                            <?php if ( $category ) : ?>
                                <span class="insight-card__badge"><?php echo esc_html( bires_category_label( $category[0] ) ); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="blog-tile__text">
                            <h2 class="blog-tile__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <?php $tile_author = (int) bires_field( 'post_team_author' ); ?>
                            <p class="blog-tile__meta">
                                <time class="blog-tile__date" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time>
                                <?php if ( $tile_author && 'publish' === get_post_status( $tile_author ) ) : ?>
                                    <span class="blog-tile__author"> — <?php echo esc_html( get_the_title( $tile_author ) ); ?></span>
                                <?php endif; ?>
                            </p>
                            <p class="blog-tile__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 26 ) ); ?></p>
                        </div>
                    </article>
                    <?php
                    $i++;
                endwhile;
                ?>
            </div>

            <?php
            $links = paginate_links( [
                'type'      => 'array',
                'mid_size'  => 1,
                'end_size'  => 1,
                'prev_text' => '<span class="screen-reader-text">' . esc_html__( 'Попередня сторінка', 'bires-theme' ) . '</span>' . bires_icon( 'chevron-left', 32 ),
                'next_text' => '<span class="screen-reader-text">' . esc_html__( 'Наступна сторінка', 'bires-theme' ) . '</span>' . bires_icon( 'chevron-right', 32 ),
            ] );
            if ( $links ) :
                ?>
                <nav class="pagination" aria-label="<?php esc_attr_e( 'Сторінки', 'bires-theme' ); ?>">
                    <?php echo implode( '', $links ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core paginate_links markup ?>
                </nav>
            <?php endif; ?>
        <?php else : ?>
            <p class="blog-archive__empty"><?php esc_html_e( 'Записів не знайдено.', 'bires-theme' ); ?></p>
        <?php endif; ?>
    </div>
</section>
