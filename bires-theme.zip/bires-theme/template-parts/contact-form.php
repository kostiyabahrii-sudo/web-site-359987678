<?php
$shortcode = bires_option( 'form_shortcode' );

if ( $shortcode ) {
    echo do_shortcode( $shortcode );
    return;
}

$form_id = 'contact-form-' . wp_unique_id();
$sent    = isset( $_GET['bires_sent'] ) ? sanitize_key( wp_unslash( $_GET['bires_sent'] ) ) : '';
$variant = isset( $args['variant'] ) ? $args['variant'] : 'light';

if ( 'page' === $variant ) {
    get_template_part( 'template-parts/contact-form-page', null, [ 'form_id' => $form_id, 'sent' => $sent ] );
    return;
}
?>
<?php if ( 'ok' === $sent ) : ?>
    <p class="contact-form__notice" role="status"><?php esc_html_e( 'Дякуємо! Ми зв’яжемося з вами найближчим часом.', 'bires-theme' ); ?></p>
<?php elseif ( 'error' === $sent ) : ?>
    <p class="contact-form__notice contact-form__notice--error" role="alert"><?php esc_html_e( 'Не вдалося надіслати запит. Перевірте ім’я та телефон і спробуйте ще раз.', 'bires-theme' ); ?></p>
<?php endif; ?>
<form class="contact-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
    <input type="hidden" name="action" value="bires_contact">
    <?php wp_nonce_field( 'bires_contact', 'bires_contact_nonce' ); ?>
    <div class="contact-form__hp" aria-hidden="true">
        <label for="<?php echo esc_attr( $form_id ); ?>-website">Website</label>
        <input type="text" id="<?php echo esc_attr( $form_id ); ?>-website" name="website" tabindex="-1" autocomplete="off">
    </div>
    <div class="contact-form__fields">
        <div class="contact-form__field">
            <label class="screen-reader-text" for="<?php echo esc_attr( $form_id ); ?>-name"><?php esc_html_e( 'Ім’я та прізвище', 'bires-theme' ); ?></label>
            <input type="text" id="<?php echo esc_attr( $form_id ); ?>-name" name="name" placeholder="<?php esc_attr_e( 'Ім’я та прізвище', 'bires-theme' ); ?>" autocomplete="name" required>
        </div>
        <div class="contact-form__field contact-form__field--phone">
            <span class="contact-form__phone-code">
                <span class="contact-form__flag" aria-hidden="true">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M0 12C0 5.373 5.373 0 12 0s12 5.373 12 12H0Z" fill="#005BBB"/><path d="M24 12c0 6.627-5.373 12-12 12S0 18.627 0 12h24Z" fill="#FFD500"/></svg>
                </span>
                +380
                <svg class="contact-form__chevron" width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 6l4 4 4-4" stroke="#0B564E" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </span>
            <label class="screen-reader-text" for="<?php echo esc_attr( $form_id ); ?>-phone"><?php esc_html_e( 'Номер телефону', 'bires-theme' ); ?></label>
            <input type="tel" id="<?php echo esc_attr( $form_id ); ?>-phone" name="phone" placeholder="<?php esc_attr_e( 'Номер телефону', 'bires-theme' ); ?>" autocomplete="tel-national" required>
        </div>
        <div class="contact-form__field">
            <label class="screen-reader-text" for="<?php echo esc_attr( $form_id ); ?>-email"><?php esc_html_e( 'Електронна пошта', 'bires-theme' ); ?></label>
            <input type="email" id="<?php echo esc_attr( $form_id ); ?>-email" name="email" placeholder="<?php esc_attr_e( 'Електронна пошта', 'bires-theme' ); ?>" autocomplete="email">
        </div>
    </div>
    <div class="contact-form__submit">
        <button type="submit" class="contact-form__btn"><?php esc_html_e( 'Відправити запит', 'bires-theme' ); ?></button>
        <p class="contact-form__legal"><?php esc_html_e( 'Надсилаючи форму, я погоджуюсь з умовами конфіденційності.', 'bires-theme' ); ?></p>
    </div>
</form>
