<?php
$content = apply_filters( 'the_content', get_post_field( 'post_content', get_the_ID() ) );

if ( '' === trim( wp_strip_all_tags( $content ) ) ) {
    return;
}
?>
<section class="seo-text">
    <div class="container container--wide seo-text__inner">
        <div class="seo-text__label" aria-hidden="true">[ <?php esc_html_e( 'Роз’яснюємо детальніше', 'bires-theme' ); ?> ]</div>
        <div class="seo-text__body">
            <div class="seo-text__content entry-content" id="seo-text-content" data-collapsible>
                <?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- filtered post content ?>
            </div>
            <button type="button" class="seo-text__toggle" aria-controls="seo-text-content" aria-expanded="false" hidden>
                <span class="screen-reader-text" data-label-more><?php esc_html_e( 'Читати повністю', 'bires-theme' ); ?></span>
                <span class="screen-reader-text" data-label-less hidden><?php esc_html_e( 'Згорнути', 'bires-theme' ); ?></span>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 5v14M6 13l6 6 6-6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </button>
        </div>
    </div>
</section>
