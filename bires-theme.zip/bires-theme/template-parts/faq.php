<?php
$items = array_values( array_filter( bires_rows( 'faq' ), function ( $row ) {
    return ! empty( $row['question'] ) && ! empty( $row['answer'] );
} ) );

if ( ! $items ) {
    return;
}

$title   = bires_field( 'faq_title' );
$title   = $title ? $title : __( 'Відповіді на поширені запитання', 'bires-theme' );
$text    = bires_field( 'faq_text' );
$visible = 6;
?>
<section class="faq" id="faq" aria-labelledby="faq-title">
    <div class="container container--wide">
        <div class="section-label">FAQ</div>
        <div class="faq__inner">
            <div class="faq__headline">
                <h2 class="faq__title" id="faq-title"><?php echo esc_html( $title ); ?></h2>
                <?php if ( $text ) : ?>
                    <p class="faq__text"><?php echo esc_html( $text ); ?></p>
                <?php endif; ?>
            </div>
            <div class="faq__body">
                <div class="faq__list">
                    <?php foreach ( $items as $i => $item ) : ?>
                        <?php
                        $open      = 0 === $i;
                        $hidden    = $i >= $visible;
                        $answer_id = 'faq-answer-' . $i;
                        ?>
                        <div class="faq__item<?php echo $open ? ' is-open' : ''; ?>"<?php echo $hidden ? ' data-faq-extra hidden' : ''; ?>>
                            <h3 class="faq__question">
                                <button type="button" class="faq__trigger" aria-expanded="<?php echo $open ? 'true' : 'false'; ?>" aria-controls="<?php echo esc_attr( $answer_id ); ?>">
                                    <span><?php echo esc_html( $item['question'] ); ?></span>
                                    <span class="faq__icon" aria-hidden="true">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="m6 8 4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                    </span>
                                </button>
                            </h3>
                            <div class="faq__answer" id="<?php echo esc_attr( $answer_id ); ?>"<?php echo $open ? '' : ' hidden'; ?>>
                                <?php echo wp_kses_post( $item['answer'] ); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php if ( count( $items ) > $visible ) : ?>
                    <button type="button" class="services-btn services-btn--outline-light faq__more" data-faq-more><?php esc_html_e( 'Показати більше', 'bires-theme' ); ?></button>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
