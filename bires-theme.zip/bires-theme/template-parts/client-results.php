<?php
$items = array_values( array_filter( bires_with_extra_reviews( bires_rows( 'client_results', 'option' ), 'results' ), function ( $row ) {
    return ! empty( $row['text'] );
} ) );

// Немає логотипа в рядку — той самий логотип компанії з сітки «Наші клієнти» на головній (напр. RG — Restoria Group)
$items = array_map( function ( $row ) {
    if ( empty( $row['logo'] ) ) {
        $row['logo'] = bires_home_logo_for( isset( $row['name'] ) ? $row['name'] : '' );
    }
    return $row;
}, $items );

// Лише картки з логотипом клієнта (картка з назвою замість емблеми виглядає порожньою); відгук без логотипа
// з'явиться, щойно в рядку додадуть логотип. Якщо логотипа немає ні в кого — показуємо всі
$with_logo = array_values( array_filter( $items, function ( $row ) {
    return ! empty( $row['logo'] );
} ) );
if ( $with_logo ) {
    $items = $with_logo;
}

if ( ! $items ) {
    return;
}

$label = bires_option( 'client_results_label', __( 'наші клієнти', 'bires-theme' ) );
$title = bires_option( 'client_results_title', __( 'Результати наших клієнтів', 'bires-theme' ) );
$text  = bires_option( 'client_results_text' );
?>
<section class="client-results">
    <div class="container container--wide">
        <div class="section-label"><?php echo esc_html( $label ); ?></div>
        <div class="client-results__heading">
            <div class="client-results__headline">
                <h2 class="sp-title"><?php echo esc_html( $title ); ?></h2>
                <?php if ( $text ) : ?>
                    <p><?php echo esc_html( $text ); ?></p>
                <?php endif; ?>
            </div>
            <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--outline-dark"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
        </div>
        <div class="client-results__track" id="client-results-track">
            <?php foreach ( $items as $item ) : ?>
                <article class="result-card">
                    <div class="result-card__logo">
                        <?php if ( ! empty( $item['logo'] ) ) : ?>
                            <?php echo wp_get_attachment_image( $item['logo'], 'medium', false, [ 'alt' => esc_attr( isset( $item['name'] ) ? $item['name'] : '' ), 'loading' => 'lazy' ] ); ?>
                        <?php elseif ( ! empty( $item['name'] ) ) : ?>
                            <span><?php echo esc_html( $item['name'] ); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php if ( ! empty( $item['number'] ) ) : ?>
                        <div class="result-card__body">
                            <p class="result-card__number"><?php echo esc_html( $item['number'] ); ?></p>
                            <p class="result-card__text"><?php echo esc_html( $item['text'] ); ?></p>
                        </div>
                    <?php else : ?>
                        <blockquote class="result-card__body result-card__quote">
                            <?php echo bires_quote_mark( 'result-card__mark' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?>
                            <p class="result-card__text"><?php echo esc_html( bires_review_card_text( $item['text'] ) ); ?></p>
                        </blockquote>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        </div>
        <?php if ( count( $items ) > 3 ) : ?>
            <div class="client-results__dots" data-dots-for="client-results-track"></div>
        <?php endif; ?>
        <div class="client-results__more">
            <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--outline-dark"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
        </div>
    </div>
</section>
