<?php
/**
 * Args: ids => int[], variant => 'white' | 'green'.
 */
$ids     = isset( $args['ids'] ) ? array_values( array_filter( (array) $args['ids'], function ( $id ) {
    return 'publish' === get_post_status( $id );
} ) ) : [];
$variant = isset( $args['variant'] ) ? $args['variant'] : 'white';

if ( ! $ids ) {
    return;
}
$track_id = 'related-track-' . wp_unique_id();
?>
<section class="sp-related sp-related--<?php echo esc_attr( $variant ); ?>" id="related">
    <div class="container container--wide">
        <div class="section-label"><?php esc_html_e( 'Послуги', 'bires-theme' ); ?></div>
        <div class="sp-related__heading">
            <h2 class="sp-title"><?php esc_html_e( 'Пов\'язані послуги', 'bires-theme' ); ?></h2>
            <div class="slider-arrows" data-slider-controls="<?php echo esc_attr( $track_id ); ?>">
                <button type="button" class="slider-arrow" data-dir="-1" aria-label="<?php esc_attr_e( 'Назад', 'bires-theme' ); ?>"><?php echo bires_icon( 'arrow-left', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></button>
                <button type="button" class="slider-arrow" data-dir="1" aria-label="<?php esc_attr_e( 'Вперед', 'bires-theme' ); ?>"><?php echo bires_icon( 'arrow-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></button>
            </div>
        </div>
    </div>
    <div class="sp-related__track" id="<?php echo esc_attr( $track_id ); ?>">
        <?php foreach ( $ids as $n => $related_id ) : ?>
            <?php $card_title = bires_field( 'service_card_title', $related_id ); ?>
            <a class="related-card" href="<?php echo esc_url( get_permalink( $related_id ) ); ?>">
                <span class="related-card__top" aria-hidden="true">
                    <?php // Номер у скляному квадраті: бірюзова куля світиться з-за верхнього краю, при наведенні на картку скочується вниз ?>
                    <span class="related-card__num"><span class="related-card__ball"></span><span class="related-card__digit"><?php echo (int) $n + 1; ?></span></span>
                    <span class="related-card__arrow"><?php echo bires_icon( 'arrow-up-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                </span>
                <span class="related-card__text">
                    <span class="related-card__title"><?php echo esc_html( wp_strip_all_tags( preg_replace( '/\s+/', ' ', $card_title ? $card_title : get_the_title( $related_id ) ) ) ); ?></span>
                    <?php $card_desc = bires_service_summary( $related_id ); ?>
                    <?php if ( $card_desc ) : ?>
                        <span class="related-card__desc"><?php echo esc_html( $card_desc ); ?></span>
                    <?php endif; ?>
                </span>
            </a>
        <?php endforeach; ?>
    </div>
</section>
