<?php
$case      = $args['case'];
$case_id   = $case->ID;
$dom_id    = 'case-' . $case_id;
$practice  = bires_field( 'case_practice', $case_id );
$logo      = bires_field( 'case_logo_dark', $case_id );
// Немає кольорового логотипа — світлий, перефарбований у чорний (без порожнього місця у вікні)
$logo_mono = ! $logo && bires_field( 'case_logo', $case_id );
$logo      = $logo ? $logo : bires_field( 'case_logo', $case_id );
$intro     = bires_field( 'case_intro', $case_id );
$author    = bires_field( 'case_author', $case_id );
$site      = bires_field( 'case_site', $case_id );
$expert_id = (int) bires_field( 'case_expert', $case_id );
$expert_tx = bires_field( 'case_expert_text', $case_id );
$pick_text = function ( $rows ) {
    return array_values( array_filter( wp_list_pluck( $rows, 'text' ) ) );
};
$actions   = $pick_text( bires_rows( 'case_actions', $case_id ) );
$results   = $pick_text( bires_rows( 'case_results', $case_id ) );
$badges    = $pick_text( bires_rows( 'case_badges', $case_id ) );
$expert_ok = $expert_id && 'publish' === get_post_status( $expert_id );

// Кейс-відгук (текст клієнта з підписом): розділ називається «Відгук клієнта»
$sections = [ 'intro' => $author ? __( 'Відгук клієнта', 'bires-theme' ) : __( 'Інтро', 'bires-theme' ) ];
if ( $actions ) {
    $sections['actions'] = __( 'Що ми зробили', 'bires-theme' );
}
if ( $expert_ok ) {
    $sections['expert'] = __( 'Наш експерт', 'bires-theme' );
}
if ( $results ) {
    $sections['results'] = __( 'Результати', 'bires-theme' );
}
?>
<dialog class="case-drawer" id="<?php echo esc_attr( $dom_id ); ?>" aria-labelledby="<?php echo esc_attr( $dom_id ); ?>-title">
    <div class="case-drawer__media<?php echo has_post_thumbnail( $case ) ? '' : ' case-drawer__media--empty'; ?>">
        <?php echo get_the_post_thumbnail( $case, 'large', [ 'alt' => '', 'loading' => 'lazy' ] ); ?>
        <button type="button" class="case-drawer__close" data-case-close aria-label="<?php esc_attr_e( 'Закрити', 'bires-theme' ); ?>">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
        </button>
    </div>
    <div class="case-drawer__bar">
        <nav class="case-drawer__nav" aria-label="<?php esc_attr_e( 'Розділи кейсу', 'bires-theme' ); ?>">
            <?php foreach ( $sections as $key => $label ) : ?>
                <a href="#<?php echo esc_attr( $dom_id . '-' . $key ); ?>"<?php echo 'intro' === $key ? ' class="is-active"' : ''; ?>><?php echo esc_html( $label ); ?></a>
            <?php endforeach; ?>
        </nav>
    </div>
    <div class="case-drawer__body">
        <section class="case-drawer__section" id="<?php echo esc_attr( $dom_id ); ?>-intro">
            <div class="case-drawer__heading">
                <h2 id="<?php echo esc_attr( $dom_id ); ?>-title"><?php echo esc_html( $practice ? $practice : get_the_title( $case ) ); ?></h2>
                <?php if ( $logo ) : ?>
                    <?php echo wp_get_attachment_image( $logo, 'medium', false, [ 'class' => 'case-drawer__logo' . ( $logo_mono ? ' case-drawer__logo--mono' : '' ), 'alt' => esc_attr( get_the_title( $case ) ), 'loading' => 'lazy' ] ); ?>
                <?php endif; ?>
            </div>
            <?php if ( $intro ) : ?>
                <div class="case-drawer__text"><?php echo wp_kses_post( $intro ); ?></div>
            <?php endif; ?>
            <?php if ( $author || $site ) : ?>
                <p class="case-drawer__author">
                    <?php if ( $author ) : ?>
                        <span>— <?php echo esc_html( $author ); ?></span>
                    <?php endif; ?>
                    <?php if ( $site ) : ?>
                        <a href="<?php echo esc_url( $site ); ?>" target="_blank" rel="noopener nofollow"><?php echo esc_html( preg_replace( '#^https?://(www\.)?|/$#', '', $site ) ); ?></a>
                    <?php endif; ?>
                </p>
            <?php endif; ?>
        </section>

        <?php if ( $actions ) : ?>
            <section class="case-drawer__section" id="<?php echo esc_attr( $dom_id ); ?>-actions">
                <h3><?php esc_html_e( 'Що ми зробили', 'bires-theme' ); ?></h3>
                <ol class="case-drawer__steps">
                    <?php foreach ( $actions as $action ) : ?>
                        <li><?php echo esc_html( $action ); ?></li>
                    <?php endforeach; ?>
                </ol>
            </section>
        <?php endif; ?>

        <?php if ( $expert_ok ) : ?>
            <section class="case-drawer__section" id="<?php echo esc_attr( $dom_id ); ?>-expert">
                <h3 class="screen-reader-text"><?php esc_html_e( 'Наш експерт', 'bires-theme' ); ?></h3>
                <a class="case-drawer__expert" href="<?php echo esc_url( get_permalink( $expert_id ) ); ?>">
                    <span class="case-drawer__photo"><?php echo get_the_post_thumbnail( $expert_id, 'thumbnail', [ 'alt' => '', 'loading' => 'lazy' ] ); ?></span>
                    <span>
                        <span class="case-drawer__name"><?php echo esc_html( get_the_title( $expert_id ) ); ?></span>
                        <span class="case-drawer__role"><?php echo esc_html( bires_field( 'team_position', $expert_id ) ); ?></span>
                    </span>
                </a>
                <?php if ( $expert_tx ) : ?>
                    <p class="case-drawer__text"><?php echo esc_html( $expert_tx ); ?></p>
                <?php endif; ?>
                <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--outline-dark"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
            </section>
        <?php endif; ?>

        <?php if ( $results ) : ?>
            <section class="case-drawer__section" id="<?php echo esc_attr( $dom_id ); ?>-results">
                <h3><?php esc_html_e( 'Результати', 'bires-theme' ); ?></h3>
                <ul class="case-drawer__results">
                    <?php foreach ( $results as $result ) : ?>
                        <li><?php echo bires_icon( 'arrow-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?><span><?php echo esc_html( $result ); ?></span></li>
                    <?php endforeach; ?>
                </ul>
            </section>
        <?php endif; ?>

        <?php if ( $badges ) : ?>
            <ul class="case-drawer__badges">
                <?php foreach ( $badges as $badge ) : ?>
                    <li><?php echo esc_html( $badge ); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</dialog>
