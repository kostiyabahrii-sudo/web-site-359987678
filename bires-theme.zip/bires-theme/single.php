<?php get_header(); ?>

<main class="site-main" id="main">
    <?php
    while ( have_posts() ) :
        the_post();

        $post_id   = get_the_ID();
        $category  = get_the_category();
        $author_id = (int) bires_field( 'post_team_author' );
        $author_ok = $author_id && 'publish' === get_post_status( $author_id );

        [ $content, $toc ] = bires_prepare_toc( apply_filters( 'the_content', get_the_content() ) );

        $blog_id  = (int) get_option( 'page_for_posts' );
        $related  = bires_related_posts( $post_id, 12 );
        $services = (array) bires_field( 'post_related_services' );
        ?>
        <article class="article">
            <header class="article-hero">
                <div class="article-hero__text">
                    <?php if ( $category ) : ?>
                        <a class="insight-card__badge" href="<?php echo esc_url( get_category_link( $category[0] ) ); ?>"><?php echo esc_html( $category[0]->name ); ?></a>
                    <?php endif; ?>
                    <h1 class="article-hero__title"><?php the_title(); ?></h1>
                    <div class="article-meta article-meta--hero">
                        <?php if ( $author_ok ) : ?>
                            <a href="<?php echo esc_url( get_permalink( $author_id ) ); ?>"><?php echo esc_html( get_the_title( $author_id ) ); ?></a>
                            <span class="article-meta__dot" aria-hidden="true"></span>
                        <?php endif; ?>
                        <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time>
                        <span class="article-meta__dot" aria-hidden="true"></span>
                        <span>
                            <?php
                            /* translators: %d: minutes */
                            echo esc_html( sprintf( __( '%d хв читання', 'bires-theme' ), bires_reading_time( $post_id ) ) );
                            ?>
                        </span>
                    </div>
                </div>
                <div class="article-hero__media">
                    <?php
                    if ( has_post_thumbnail() ) {
                        the_post_thumbnail( 'large', [ 'alt' => '', 'loading' => 'eager', 'fetchpriority' => 'high' ] );
                    }
                    ?>
                </div>
            </header>

            <div class="article-bar">
                <div class="container container--wide article-bar__inner">
                    <nav class="breadcrumbs breadcrumbs--dark" aria-label="<?php esc_attr_e( 'Навігаційний ланцюжок', 'bires-theme' ); ?>">
                        <ol>
                            <li><a href="<?php echo esc_url( $blog_id ? get_permalink( $blog_id ) : home_url( '/' ) ); ?>"><?php esc_html_e( 'Новини & блог', 'bires-theme' ); ?></a></li>
                            <?php if ( $category ) : ?>
                                <li><a href="<?php echo esc_url( get_category_link( $category[0] ) ); ?>"><?php echo esc_html( $category[0]->name ); ?></a></li>
                            <?php endif; ?>
                        </ol>
                    </nav>
                    <div class="article-meta">
                        <?php if ( $author_ok ) : ?>
                            <a href="<?php echo esc_url( get_permalink( $author_id ) ); ?>"><?php echo esc_html( get_the_title( $author_id ) ); ?></a>
                            <span class="article-meta__dot" aria-hidden="true"></span>
                        <?php endif; ?>
                        <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time>
                        <span class="article-meta__dot" aria-hidden="true"></span>
                        <span>
                            <?php
                            /* translators: %d: minutes */
                            echo esc_html( sprintf( __( '%d хв читання', 'bires-theme' ), bires_reading_time( $post_id ) ) );
                            ?>
                        </span>
                    </div>
                </div>
            </div>

            <div class="container container--wide article-layout">
                <aside class="article-aside">
                    <?php if ( $author_ok ) : ?>
                        <div class="article-author">
                            <a class="article-author__person" href="<?php echo esc_url( get_permalink( $author_id ) ); ?>">
                                <span class="article-author__photo">
                                    <?php echo get_the_post_thumbnail( $author_id, 'thumbnail', [ 'alt' => '', 'loading' => 'lazy' ] ); ?>
                                </span>
                                <span class="article-author__details">
                                    <span class="article-author__name"><?php echo esc_html( get_the_title( $author_id ) ); ?></span>
                                    <span class="article-author__role"><?php echo esc_html( bires_field( 'team_practice', $author_id ) ? bires_field( 'team_practice', $author_id ) : bires_field( 'team_position', $author_id ) ); ?></span>
                                </span>
                            </a>
                            <a class="article-author__cta" href="<?php echo esc_url( bires_contact_url() ); ?>"><?php esc_html_e( 'Записатись на консультацію', 'bires-theme' ); ?></a>
                        </div>
                    <?php endif; ?>

                    <?php if ( count( $toc ) > 1 ) : ?>
                        <details class="article-toc" open data-toc>
                            <summary class="article-toc__summary"><?php esc_html_e( 'Зміст', 'bires-theme' ); ?><?php echo bires_icon( 'chevron-down', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></summary>
                            <nav aria-label="<?php esc_attr_e( 'Зміст статті', 'bires-theme' ); ?>">
                            <ol>
                                <?php foreach ( $toc as $n => $item ) : ?>
                                    <li><a href="#<?php echo esc_attr( $item['id'] ); ?>"><?php echo esc_html( sprintf( '%02d. %s', $n + 1, $item['title'] ) ); ?></a></li>
                                <?php endforeach; ?>
                            </ol>
                            </nav>
                        </details>
                    <?php endif; ?>
                </aside>

                <div class="article-content entry-content">
                    <?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- filtered post content ?>
                </div>
            </div>
        </article>

        <?php get_template_part( 'template-parts/related-services', null, [ 'ids' => $services, 'variant' => 'green' ] ); ?>

        <?php if ( $related ) : ?>
            <section class="related-posts">
                <div class="container container--wide">
                    <div class="section-label"><?php esc_html_e( 'Новини & блог', 'bires-theme' ); ?></div>
                    <div class="related-posts__heading">
                        <div>
                            <h2 class="sp-title"><?php esc_html_e( 'Схожі матеріали за темою', 'bires-theme' ); ?></h2>
                            <a href="<?php echo esc_url( $blog_id ? get_permalink( $blog_id ) : home_url( '/' ) ); ?>" class="services-btn services-btn--outline-light"><?php esc_html_e( 'Переглянути всі статті', 'bires-theme' ); ?></a>
                        </div>
                        <p class="related-posts__text"><?php esc_html_e( 'Добірка матеріалів за цією темою: практичні пояснення, поради та розбір юридичних ситуацій, які можуть бути корисними у подібних випадках.', 'bires-theme' ); ?></p>
                    </div>
                    <div class="related-posts__grid<?php echo count( $related ) > 4 ? ' has-teaser' : ''; ?>" data-more-grid>
                        <?php foreach ( $related as $n => $related_post ) : ?>
                            <?php $cat = get_the_category( $related_post->ID ); ?>
                            <article class="insight-card insight-card--small"<?php echo $n >= 8 ? ' data-more-item hidden' : ''; ?>>
                                <div class="insight-card__media">
                                    <?php echo get_the_post_thumbnail( $related_post, 'medium_large', [ 'alt' => '', 'loading' => 'lazy' ] ); ?>
                                    <?php if ( $cat ) : ?>
                                        <span class="insight-card__badge"><?php echo esc_html( $cat[0]->name ); ?></span>
                                    <?php endif; ?>
                                </div>
                                <h3 class="insight-card__title"><a href="<?php echo esc_url( get_permalink( $related_post ) ); ?>"><?php echo esc_html( get_the_title( $related_post ) ); ?></a></h3>
                                <p class="insight-card__meta"><?php echo esc_html( bires_post_meta_line( $related_post ) ); ?></p>
                                <p class="insight-card__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt( $related_post ), 20 ) ); ?></p>
                            </article>
                        <?php endforeach; ?>
                    </div>
                    <?php if ( count( $related ) > 1 ) : ?>
                        <div class="related-posts__more<?php echo count( $related ) > 4 ? '' : ' related-posts__more--mobile'; ?>">
                            <button type="button" class="services-btn services-btn--white" data-more-btn><?php esc_html_e( 'Показати більше', 'bires-theme' ); ?></button>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>
    <?php endwhile; ?>
</main>

<?php get_footer(); ?>
