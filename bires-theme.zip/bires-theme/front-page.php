<?php
get_header();

$front_id = (int) get_option( 'page_on_front' );
$hf       = function ( $name, $default = '' ) use ( $front_id ) {
    $value = $front_id ? bires_field( $name, $front_id ) : '';
    return ( '' === $value || null === $value || false === $value ) ? $default : $value;
};
$hrows    = function ( $name ) use ( $front_id ) {
    return $front_id ? bires_rows( $name, $front_id ) : [];
};

$listing_id = bires_services_listing_id();
$listing    = $listing_id ? get_permalink( $listing_id ) : '';
$services   = $listing_id ? get_pages( [ 'parent' => $listing_id, 'sort_column' => 'menu_order,post_title' ] ) : [];
$by_audience = function ( $audience, $field ) use ( $services, $hf ) {
    $picked = array_filter( (array) $hf( $field, [] ) );
    if ( $picked ) {
        return array_values( array_filter( array_map( 'intval', $picked ), function ( $id ) {
            return 'publish' === get_post_status( $id );
        } ) );
    }
    $ids = [];
    foreach ( $services as $service ) {
        $value = bires_field( 'service_audience', $service->ID );
        if ( ( $value ? $value : 'business' ) === $audience ) {
            $ids[] = $service->ID;
        }
    }
    return $ids;
};
$service_tiles = function ( $ids, $variant ) {
    foreach ( $ids as $id ) {
        $title = bires_field( 'service_card_title', $id );
        ?>
        <a class="home-tile home-tile--<?php echo esc_attr( $variant ); ?>" href="<?php echo esc_url( get_permalink( $id ) ); ?>">
            <span class="home-tile__title"><?php echo esc_html( $title ? $title : get_the_title( $id ) ); ?></span>
            <span class="home-tile__arrow"><?php echo bires_icon( 'arrow-up-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
        </a>
        <?php
    }
};

$hero_image   = $hf( 'home_hero_image' );
$hero_title   = $hf( 'hero_title', __( 'Юридичний супровід бізнесу та приватних клієнтів', 'bires-theme' ) );
$contact_url  = bires_contact_url();
$biz_ids      = $by_audience( 'business', 'home_biz_services' );
$personal_ids = $by_audience( 'personal', 'home_personal_services' );

$points = array_values( array_filter( wp_list_pluck( $hrows( 'home_approach_points' ), 'text' ) ) );
if ( ! $front_id || ! $points ) {
    $points = [ __( 'Надаємо перевагу комплексному юридичному супроводу.', 'bires-theme' ), __( 'Креативні, завжди шукаємо шляхи «як можна».', 'bires-theme' ) ];
}

$stats = array_values( array_filter( $hrows( 'home_stats' ), function ( $row ) {
    return ! empty( $row['number'] );
} ) );
if ( ! $stats ) {
    $stats = [
        [ 'label' => __( 'Професіоналізм', 'bires-theme' ), 'number' => '20', 'caption' => __( 'Років досвіду в праві', 'bires-theme' ) ],
        [ 'label' => __( 'Широкий спектр послуг', 'bires-theme' ), 'number' => '14', 'caption' => __( 'Практик для бізнесу & фізичних осіб', 'bires-theme' ) ],
        [ 'label' => __( 'Конфіденційність', 'bires-theme' ), 'number' => '100%', 'caption' => __( 'Відповідність етиці та захисту даних', 'bires-theme' ) ],
        [ 'label' => __( 'Відкритість до бізнесу', 'bires-theme' ), 'number' => '<75%', 'caption' => __( 'Клієнтів працюють з нами понад 5 років', 'bires-theme' ) ],
    ];
}
$quote_person = (int) $hf( 'home_quote_person', 0 );
if ( ! $quote_person ) {
    $leaders      = bires_team_members( 'managing_partner' );
    $quote_person = $leaders ? $leaders[0]->ID : 0;
}

$reviews = array_values( array_filter( $hrows( 'home_reviews' ), function ( $row ) {
    return ! empty( $row['text'] );
} ) );
$logos   = array_values( array_filter( $hrows( 'home_logos' ), function ( $row ) {
    return ! empty( $row['image'] );
} ) );

$achievements = array_values( array_filter( $hrows( 'home_achievements' ), function ( $row ) {
    return ! empty( $row['title'] );
} ) );

$cases_pages = get_pages( [ 'meta_key' => '_wp_page_template', 'meta_value' => 'page-templates/cases.php', 'number' => 1 ] );
$cases_url   = $cases_pages ? get_permalink( apply_filters( 'wpml_object_id', $cases_pages[0]->ID, 'page', true ) ) : '';

$post_ids = array_filter( (array) $hf( 'home_posts', [] ) );
$posts    = $post_ids
    ? get_posts( [ 'suppress_filters' => false, 'post__in' => array_map( 'intval', $post_ids ), 'orderby' => 'post__in', 'posts_per_page' => 3 ] )
    : get_posts( [ 'suppress_filters' => false, 'posts_per_page' => 3 ] );
?>

<main class="site-main" id="main">
    <section class="home-hero">
        <div class="home-hero__media">
            <?php
            if ( $hero_image ) {
                echo wp_get_attachment_image( $hero_image, 'full', false, [ 'alt' => '', 'fetchpriority' => 'high', 'sizes' => '(max-width: 1024px) 100vw, 50vw' ] );
            } else {
                printf( '<img src="%s" alt="" width="1400" height="933" fetchpriority="high">', esc_url( get_template_directory_uri() . '/assets/images/hero-city.jpg' ) );
            }
            ?>
        </div>
        <div class="home-hero__content">
            <h1 class="home-hero__title"><?php echo esc_html( $hero_title ); ?></h1>
            <a href="<?php echo esc_url( $contact_url ); ?>" class="services-btn services-btn--white"><?php echo esc_html( $hf( 'home_hero_button', __( 'Отримайте консультацію', 'bires-theme' ) ) ); ?></a>
        </div>
        <?php if ( $logos ) : ?>
            <div class="home-hero__logos" aria-hidden="true">
                <?php foreach ( $logos as $logo ) : ?>
                    <?php echo wp_get_attachment_image( $logo['image'], 'medium', false, [ 'alt' => '', 'loading' => 'lazy' ] ); ?>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <?php if ( $biz_ids ) : ?>
        <section class="home-services home-services--business">
            <div class="container container--wide">
                <div class="section-label"><?php echo esc_html( $hf( 'home_biz_label', __( 'Наші послуги', 'bires-theme' ) ) ); ?></div>
                <div class="home-services__heading">
                    <h2 class="home-services__title home-services__title--quote"><?php echo esc_html( $hf( 'home_biz_title', __( 'Для бізнесу — правова підтримка, коли вона потрібна.', 'bires-theme' ) ) ); ?></h2>
                    <?php if ( $listing ) : ?>
                        <a href="<?php echo esc_url( $listing ); ?>" class="services-btn services-btn--outline-dark"><?php esc_html_e( 'Дізнатись більше', 'bires-theme' ); ?></a>
                    <?php endif; ?>
                </div>
                <p class="home-services__label"><?php esc_html_e( 'Сфери практики', 'bires-theme' ); ?></p>
            </div>
            <div class="home-services__track"><?php $service_tiles( $biz_ids, 'light' ); ?></div>
            <?php if ( $listing ) : ?>
                <div class="home-services__more"><a href="<?php echo esc_url( $listing ); ?>" class="services-btn services-btn--outline-dark"><?php esc_html_e( 'Дізнатись більше', 'bires-theme' ); ?></a></div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if ( $personal_ids ) : ?>
        <section class="home-services home-services--personal">
            <div class="container container--wide">
                <div class="home-services__heading">
                    <div class="home-services__intro">
                        <h2 class="home-services__title"><?php echo esc_html( $hf( 'home_personal_title', __( 'Для фізичних осіб.', 'bires-theme' ) ) ); ?></h2>
                        <?php if ( $listing ) : ?>
                            <a href="<?php echo esc_url( $listing ); ?>" class="services-btn services-btn--outline-light"><?php esc_html_e( 'Дізнатись більше', 'bires-theme' ); ?></a>
                        <?php endif; ?>
                    </div>
                    <p class="home-services__text"><?php echo esc_html( $hf( 'home_personal_text', __( 'Ми надаємо професійну правову підтримку у справах, що стосуються приватних клієнтів. Забезпечуємо комплексний юридичний супровід у справах сімейного, міграційного, кримінального, а також у питаннях та захисту прав фізичних осіб.', 'bires-theme' ) ) ); ?></p>
                </div>
                <p class="home-services__label"><?php esc_html_e( 'Сфери практики', 'bires-theme' ); ?></p>
            </div>
            <div class="home-services__track"><?php $service_tiles( $personal_ids, 'dark' ); ?></div>
            <?php if ( $listing ) : ?>
                <div class="home-services__more"><a href="<?php echo esc_url( $listing ); ?>" class="services-btn services-btn--outline-light"><?php esc_html_e( 'Дізнатись більше', 'bires-theme' ); ?></a></div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <section class="home-approach">
        <div class="container container--wide">
            <div class="section-label"><?php echo esc_html( $hf( 'home_approach_label', __( 'Наш підхід', 'bires-theme' ) ) ); ?></div>
            <div class="home-approach__inner">
                <div class="home-approach__media">
                    <?php
                    $approach_image = $hf( 'home_approach_image' );
                    if ( $approach_image ) {
                        echo wp_get_attachment_image( $approach_image, 'large', false, [ 'alt' => '', 'loading' => 'lazy', 'sizes' => '(max-width: 1024px) 100vw, 694px' ] );
                    } else {
                        printf( '<img src="%s" alt="" width="1024" height="1024" loading="lazy">', esc_url( get_template_directory_uri() . '/assets/images/about-office.jpg' ) );
                    }
                    ?>
                </div>
                <div class="home-approach__content">
                    <h2 class="sp-title"><?php echo esc_html( $hf( 'home_approach_title', __( 'Чому клієнти обирають компанію Bires?', 'bires-theme' ) ) ); ?></h2>
                    <p class="home-approach__text"><?php echo esc_html( $hf( 'home_approach_text', __( 'Ми маємо унікальний практичний досвід представництва та захисту інтересів українських та іноземних клієнтів у судах, арбітражних установах і органах державної влади.', 'bires-theme' ) ) ); ?></p>
                    <ul class="home-approach__list">
                        <?php foreach ( $points as $point ) : ?>
                            <li>
                                <svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 1 1 0 20 10 10 0 0 1 0-20Zm3.7 6.8a1 1 0 0 0-1.4 0L11 12.1l-1.3-1.3a1 1 0 1 0-1.4 1.4l2 2a1 1 0 0 0 1.4 0l4-4a1 1 0 0 0 0-1.4Z"/></svg>
                                <?php echo esc_html( $point ); ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="<?php echo esc_url( $contact_url ); ?>" class="services-btn services-btn--outline-dark"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
                </div>
            </div>
        </div>
    </section>

    <section class="home-stats">
        <div class="container container--wide home-stats__mobile-label">
            <div class="section-label"><?php echo esc_html( $hf( 'home_approach_label', __( 'Наш підхід', 'bires-theme' ) ) ); ?></div>
        </div>
        <div class="container container--wide home-stats__inner">
            <div class="home-stats__quote">
                <figure>
                    <svg width="32" height="24" viewBox="0 0 21 16" aria-hidden="true"><path fill="currentColor" d="M0 16V9.6C0 4.3 2.6 1.1 7.7 0l1 1.9C6.1 2.8 4.8 4.6 4.6 7.2H8.6V16H0Zm12 0V9.6C12 4.3 14.6 1.1 19.7 0l1 1.9c-2.6.9-3.9 2.7-4.1 5.3h4V16H12Z"/></svg>
                    <blockquote><p><?php echo esc_html( $hf( 'home_quote', __( 'Готові працювати з командою, яка ставить клієнта в центр рішень?', 'bires-theme' ) ) ); ?></p></blockquote>
                    <?php if ( $quote_person ) : ?>
                        <figcaption class="home-stats__person">
                            <span class="home-stats__photo"><?php echo $hf( 'home_quote_photo' ) ? wp_get_attachment_image( (int) $hf( 'home_quote_photo' ), 'thumbnail', false, [ 'alt' => '', 'loading' => 'lazy' ] ) : get_the_post_thumbnail( $quote_person, 'thumbnail', [ 'alt' => '', 'loading' => 'lazy' ] ); ?></span>
                            <span>
                                <a class="home-stats__name" href="<?php echo esc_url( get_permalink( $quote_person ) ); ?>"><?php echo esc_html( get_the_title( $quote_person ) ); ?></a>
                                <span class="home-stats__role"><?php echo esc_html( $hf( 'home_quote_role', bires_field( 'team_position', $quote_person ) ) ); ?></span>
                            </span>
                        </figcaption>
                    <?php endif; ?>
                </figure>
            </div>
            <dl class="home-stats__grid">
                <?php foreach ( $stats as $stat ) : ?>
                    <div class="home-stat">
                        <dt class="home-stat__label"><?php echo esc_html( $stat['label'] ); ?></dt>
                        <dd>
                            <span class="home-stat__number"><?php echo esc_html( $stat['number'] ); ?></span>
                            <span class="home-stat__caption"><?php echo esc_html( $stat['caption'] ); ?></span>
                        </dd>
                    </div>
                <?php endforeach; ?>
            </dl>
        </div>
    </section>

    <?php if ( $reviews || $logos ) : ?>
        <section class="home-reviews">
            <div class="container container--wide">
                <div class="section-label"><?php echo esc_html( $hf( 'home_reviews_label', __( 'наші клієнти', 'bires-theme' ) ) ); ?></div>
                <div class="home-reviews__heading">
                    <div class="home-reviews__headline">
                        <h2 class="home-services__title"><?php echo esc_html( $hf( 'home_reviews_title', __( 'Що наші клієнти говорять про нас?', 'bires-theme' ) ) ); ?></h2>
                        <p><?php echo esc_html( $hf( 'home_reviews_text', __( 'Настав час вирішити свої юридичні питання? Почніть зараз.', 'bires-theme' ) ) ); ?></p>
                    </div>
                    <?php if ( $cases_url ) : ?>
                        <a href="<?php echo esc_url( $cases_url ); ?>" class="services-btn services-btn--outline-dark"><?php esc_html_e( 'Переглянути кейси клієнтів', 'bires-theme' ); ?></a>
                    <?php endif; ?>
                </div>
                <div class="home-reviews__body">
                    <?php if ( $reviews ) : ?>
                        <div class="home-reviews__slider">
                            <div class="home-reviews__track" id="home-reviews-track">
                                <?php foreach ( $reviews as $review ) : ?>
                                    <?php $rating = max( 1, min( 5, (int) ( isset( $review['rating'] ) ? $review['rating'] : 5 ) ) ); ?>
                                    <figure class="review-card">
                                        <figcaption class="review-card__person">
                                            <span>
                                                <span class="review-card__name"><?php echo esc_html( $review['name'] ); ?></span>
                                                <span class="review-card__role"><?php echo esc_html( $review['role'] ); ?></span>
                                            </span>
                                            <?php if ( ! empty( $review['logo'] ) ) : ?>
                                                <?php echo wp_get_attachment_image( $review['logo'], 'medium', false, [ 'class' => 'review-card__logo', 'alt' => '', 'loading' => 'lazy' ] ); ?>
                                            <?php endif; ?>
                                        </figcaption>
                                        <div class="review-card__body">
                                            <div class="review-card__meta">
                                                <span class="review-card__stars" role="img" aria-label="<?php echo esc_attr( sprintf( /* translators: %d: rating */ __( 'Оцінка %d з 5', 'bires-theme' ), $rating ) ); ?>">
                                                    <?php for ( $s = 1; $s <= 5; $s++ ) : ?>
                                                        <svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true"><path fill="<?php echo $s <= $rating ? '#f63100' : '#c6ccd2'; ?>" d="m12 2 2.9 6.3 6.9.7-5.2 4.6 1.5 6.8L12 16.9l-6.1 3.5 1.5-6.8L2.2 9l6.9-.7L12 2Z"/></svg>
                                                    <?php endfor; ?>
                                                </span>
                                                <?php if ( ! empty( $review['badge'] ) ) : ?>
                                                    <span class="review-card__badge"><?php echo esc_html( $review['badge'] ); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <blockquote class="review-card__text">
                                                <span class="review-card__mark" aria-hidden="true">&ldquo;</span>
                                                <p><?php echo esc_html( $review['text'] ); ?></p>
                                            </blockquote>
                                        </div>
                                    </figure>
                                <?php endforeach; ?>
                            </div>
                            <?php if ( count( $reviews ) > 1 ) : ?>
                                <div class="client-results__dots" data-dots-for="home-reviews-track"></div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <?php if ( $logos ) : ?>
                        <ul class="home-logos">
                            <?php foreach ( $logos as $logo ) : ?>
                                <li class="home-logos__item"><?php echo wp_get_attachment_image( $logo['image'], 'medium', false, [ 'alt' => esc_attr( isset( $logo['name'] ) ? $logo['name'] : '' ), 'loading' => 'lazy' ] ); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
                <?php if ( $cases_url ) : ?>
                    <div class="home-reviews__more"><a href="<?php echo esc_url( $cases_url ); ?>" class="services-btn services-btn--outline-dark"><?php esc_html_e( 'Переглянути кейси клієнтів', 'bires-theme' ); ?></a></div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if ( $achievements ) : ?>
        <section class="home-achievements" data-achievements>
            <div class="container container--wide">
                <div class="section-label"><?php echo esc_html( $hf( 'home_achievements_label', __( 'Наші досягнення', 'bires-theme' ) ) ); ?></div>
            </div>
            <div class="home-achievements__inner">
                <div class="home-achievements__texts">
                    <?php foreach ( $achievements as $i => $item ) : ?>
                        <?php $tags = array_filter( array_map( 'trim', explode( ',', (string) $item['tags'] ) ) ); ?>
                        <article class="achievement" data-achievement="<?php echo (int) $i; ?>"<?php echo $i ? ' hidden' : ''; ?>>
                            <div class="achievement__main">
                                <h3 class="achievement__title"><?php echo esc_html( $item['title'] ); ?></h3>
                                <?php if ( ! empty( $item['text'] ) ) : ?>
                                    <p class="achievement__text"><?php echo esc_html( $item['text'] ); ?></p>
                                <?php endif; ?>
                                <?php if ( $tags ) : ?>
                                    <ul class="achievement__tags">
                                        <?php foreach ( $tags as $tag ) : ?>
                                            <li><?php echo esc_html( $tag ); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                            </div>
                            <div class="achievement__footer">
                                <span><?php echo esc_html( $item['period'] ); ?></span>
                                <?php if ( count( $achievements ) > 1 ) : ?>
                                    <button type="button" class="achievement__next" data-achievement-next aria-label="<?php esc_attr_e( 'Наступне досягнення', 'bires-theme' ); ?>"><?php echo bires_icon( 'arrow-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></button>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
                <div class="home-achievements__track" data-achievement-track>
                    <?php foreach ( $achievements as $item ) : ?>
                        <div class="home-achievements__slide">
                            <?php
                            if ( ! empty( $item['image'] ) ) {
                                echo wp_get_attachment_image( $item['image'], 'large', false, [ 'alt' => '', 'loading' => 'lazy', 'sizes' => '(max-width: 1024px) 90vw, 618px' ] );
                            }
                            ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php get_template_part( 'template-parts/blog-preview', null, [ 'layout' => 'mixed', 'posts' => $posts ] ); ?>

    <?php get_template_part( 'template-parts/contact-section' ); ?>
</main>

<?php get_footer(); ?>
