<?php
get_header();

$hero_title = bires_option( 'team_hero_title', __( 'Наша команда', 'bires-theme' ) );
$hero_image = bires_option( 'team_hero_image' );

$managing = bires_team_members( 'managing_partner' );
$partners = bires_team_members( 'partner' );
$heads    = bires_team_members( 'practice_head' );
$others   = bires_team_members( 'team' );

$flags = array_filter( array_map( 'trim', explode( ',', bires_option( 'team_card2_flags', 'lv,ee,gb,cy,pl,us,fr' ) ) ) );
?>

<main class="site-main" id="main">
    <section class="team-hero">
        <div class="container container--wide team-hero__inner">
            <div class="team-hero__content">
                <nav class="breadcrumbs" aria-label="<?php esc_attr_e( 'Навігаційний ланцюжок', 'bires-theme' ); ?>">
                    <ol>
                        <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Головна', 'bires-theme' ); ?></a></li>
                        <li aria-current="page"><?php esc_html_e( 'Команда', 'bires-theme' ); ?></li>
                    </ol>
                </nav>
                <h1 class="team-hero__title"><?php echo esc_html( $hero_title ); ?></h1>
                <a href="#team-list" class="services-btn services-btn--white"><?php esc_html_e( 'Познайомтесь з нами', 'bires-theme' ); ?></a>
            </div>
            <?php if ( $hero_image ) : ?>
                <div class="team-hero__media">
                    <?php echo wp_get_attachment_image( $hero_image, 'large', false, [ 'alt' => '', 'fetchpriority' => 'high' ] ); ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="team-about">
        <div class="container container--wide">
            <div class="section-label"><?php esc_html_e( 'Про нас', 'bires-theme' ); ?></div>
            <div class="team-about__headline">
                <h2 class="sp-title"><?php echo esc_html( bires_option( 'team_intro_title', __( 'Різні підходи. Одна команда', 'bires-theme' ) ) ); ?></h2>
                <?php if ( bires_option( 'team_intro_text' ) ) : ?>
                    <p class="team-about__text"><?php echo esc_html( bires_option( 'team_intro_text' ) ); ?></p>
                <?php endif; ?>
            </div>
            <div class="team-about__cards">
                <div class="team-stat team-stat--image">
                    <?php
                    $card1_image = bires_option( 'team_card1_image' );
                    if ( $card1_image ) {
                        echo wp_get_attachment_image( $card1_image, 'medium_large', false, [ 'class' => 'team-stat__bg', 'alt' => '', 'loading' => 'lazy' ] );
                    }
                    ?>
                    <span class="team-stat__icon team-stat__icon--light"><?php echo bires_icon( 'briefcase' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                    <div class="team-stat__inner">
                        <h3 class="team-stat__inner-title"><?php echo esc_html( bires_option( 'team_card1_title', __( 'Трудове та HR право', 'bires-theme' ) ) ); ?></h3>
                        <?php if ( bires_option( 'team_card1_text' ) ) : ?>
                            <p><?php echo esc_html( bires_option( 'team_card1_text' ) ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="team-stat team-stat--dark">
                    <div class="team-stat__top">
                        <h3 class="team-stat__label"><?php echo esc_html( bires_option( 'team_card2_title', __( 'Міжнародні клієнти', 'bires-theme' ) ) ); ?></h3>
                        <span class="team-stat__number"><?php echo esc_html( bires_option( 'team_card2_number', '70%' ) ); ?></span>
                    </div>
                    <div class="team-stat__bottom">
                        <?php if ( $flags ) : ?>
                            <div class="team-stat__flags" aria-hidden="true">
                                <?php foreach ( $flags as $flag ) : ?>
                                    <span class="team-stat__flag"><?php echo bires_flag_svg( $flag ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <p class="team-stat__caption"><?php echo esc_html( bires_option( 'team_card2_text', __( 'Супроводжуємо бізнес та приватні справи по всьому світу.', 'bires-theme' ) ) ); ?></p>
                    </div>
                </div>
                <div class="team-stat team-stat--mint">
                    <span class="team-stat__number team-stat__number--mint"><?php echo esc_html( bires_option( 'team_card3_number', '500+' ) ); ?></span>
                    <span class="team-stat__icon"><?php echo bires_icon( 'check-circle' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                    <p class="team-stat__sub"><?php echo esc_html( bires_option( 'team_card3_text', __( 'успішно реалізованих кейсів у різних галузях права.', 'bires-theme' ) ) ); ?></p>
                </div>
            </div>
        </div>
    </section>

    <div id="team-list">
        <?php
        $leaders = [
            [ 'members' => $managing, 'title' => __( 'Керуючий партнер', 'bires-theme' ), 'theme' => 'dark' ],
            [ 'members' => $partners, 'title' => _n( 'Партнер', 'Партнери', max( 1, count( $partners ) ), 'bires-theme' ), 'theme' => 'green' ],
        ];
        foreach ( $leaders as $block ) :
            if ( ! $block['members'] ) {
                continue;
            }
            ?>
            <section class="team-lead team-lead--<?php echo esc_attr( $block['theme'] ); ?>">
                <div class="container container--wide">
                    <div class="team-lead__heading">
                        <h2 class="sp-title"><?php echo esc_html( $block['title'] ); ?></h2>
                        <span class="bracket-label" aria-hidden="true">[ <?php esc_html_e( 'команда', 'bires-theme' ); ?> ]</span>
                    </div>
                    <?php foreach ( $block['members'] as $i => $member ) : ?>
                        <?php $quote = bires_field( 'team_quote', $member->ID ); ?>
                        <div class="team-lead__row<?php echo ( 'green' === $block['theme'] ) !== ( 1 === $i % 2 ) ? ' team-lead__row--reverse' : ''; ?>">
                            <?php get_template_part( 'template-parts/person-card', null, [ 'id' => $member->ID, 'variant' => 'dark' === $block['theme'] ? 'dark' : 'light' ] ); ?>
                            <?php if ( $quote ) : ?>
                                <blockquote class="team-quote">
                                    <div class="team-quote__top" aria-hidden="true">
                                        <span class="team-quote__mark">&ldquo;</span>
                                        <span class="team-quote__logo">BIRES</span>
                                    </div>
                                    <p><?php echo esc_html( $quote ); ?></p>
                                </blockquote>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endforeach; ?>

        <?php
        $groups = [
            [ 'members' => $heads, 'title' => __( 'Керівники практик', 'bires-theme' ), 'text' => bires_option( 'team_heads_text', __( 'Наша команда, що представляє інтереси власників бізнесу та приватних клієнтів.', 'bires-theme' ) ) ],
            [ 'members' => $others, 'title' => __( 'Команда', 'bires-theme' ), 'text' => '' ],
        ];
        foreach ( $groups as $g => $block ) :
            if ( ! $block['members'] ) {
                continue;
            }
            $track_id = 'team-track-' . $g;
            ?>
            <section class="team-slider">
                <div class="container container--wide">
                    <div class="team-slider__heading">
                        <div>
                            <h2 class="sp-title"><?php echo esc_html( $block['title'] ); ?></h2>
                            <?php if ( $block['text'] ) : ?>
                                <p class="team-slider__text"><?php echo esc_html( $block['text'] ); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="slider-arrows slider-arrows--light" data-slider-controls="<?php echo esc_attr( $track_id ); ?>">
                            <button type="button" class="slider-arrow" data-dir="-1" aria-label="<?php esc_attr_e( 'Назад', 'bires-theme' ); ?>"><?php echo bires_icon( 'arrow-left', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></button>
                            <button type="button" class="slider-arrow" data-dir="1" aria-label="<?php esc_attr_e( 'Вперед', 'bires-theme' ); ?>"><?php echo bires_icon( 'arrow-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></button>
                        </div>
                    </div>
                </div>
                <div class="team-slider__track" id="<?php echo esc_attr( $track_id ); ?>">
                    <?php foreach ( $block['members'] as $member ) : ?>
                        <?php get_template_part( 'template-parts/person-card', null, [ 'id' => $member->ID, 'variant' => 'dark' ] ); ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endforeach; ?>
    </div>
</main>

<?php get_footer(); ?>
