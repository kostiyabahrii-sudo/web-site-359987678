<?php

define( 'BIRES_VERSION', '1.9.14' );
define( 'BIRES_SERVICES_TEMPLATE', 'page-templates/services-listing.php' );
define( 'BIRES_SERVICE_TEMPLATE', 'page-templates/service.php' );

require get_template_directory() . '/inc/setup.php';
require get_template_directory() . '/inc/helpers.php';
require get_template_directory() . '/inc/languages.php';
require get_template_directory() . '/inc/old-media.php';
require get_template_directory() . '/inc/enqueue.php';
require get_template_directory() . '/inc/post-types.php';
require get_template_directory() . '/inc/acf-fields.php';
require get_template_directory() . '/inc/schema.php';
require get_template_directory() . '/inc/forms.php';
require get_template_directory() . '/inc/menu.php';
require get_template_directory() . '/inc/blog.php';
require get_template_directory() . '/inc/team.php';
require get_template_directory() . '/inc/sitemap.php';
require get_template_directory() . '/inc/demo-content.php';
require get_template_directory() . '/inc/migrated-site.php';
require get_template_directory() . '/inc/migration.php';
require get_template_directory() . '/inc/import-old.php';
