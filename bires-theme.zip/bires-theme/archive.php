<?php get_header(); ?>

<main class="site-main" id="main">
    <?php get_template_part( 'template-parts/blog-archive' ); ?>
</main>

<?php get_footer(); ?>
