<?php
/*
 * Template Name: Кейси
 */

get_header();

$hero_title = bires_field( 'hero_title' );
$hero_text  = bires_field( 'hero_text' );
$cases      = get_posts( [
    'suppress_filters' => false,
    'post_type'      => 'case',
    'posts_per_page' => -1,
    'orderby'        => [ 'menu_order' => 'ASC', 'date' => 'DESC' ],
] );
?>
<main class="site-main" id="main">
    <section class="cases-hero">
        <div class="container container--wide">
            <div class="cases-hero__heading">
                <div class="cases-hero__text">
                    <nav class="breadcrumbs" aria-label="<?php esc_attr_e( 'Навігаційний ланцюжок', 'bires-theme' ); ?>">
                        <ol>
                            <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Головна', 'bires-theme' ); ?></a></li>
                            <li aria-current="page"><?php the_title(); ?></li>
                        </ol>
                    </nav>
                    <h1 class="cases-hero__title"><?php echo esc_html( $hero_title ? $hero_title : get_the_title() ); ?></h1>
                    <?php if ( $hero_text ) : ?>
                        <p class="cases-hero__lead"><?php echo esc_html( $hero_text ); ?></p>
                    <?php endif; ?>
                </div>
                <?php if ( count( $cases ) > 1 ) : ?>
                    <div class="slider-arrows slider-arrows--light" data-slider-controls="cases-track">
                        <button type="button" class="slider-arrow" data-dir="-1" aria-label="<?php esc_attr_e( 'Назад', 'bires-theme' ); ?>"><?php echo bires_icon( 'arrow-left', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></button>
                        <button type="button" class="slider-arrow" data-dir="1" aria-label="<?php esc_attr_e( 'Вперед', 'bires-theme' ); ?>"><?php echo bires_icon( 'arrow-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php if ( $cases ) : ?>
            <div class="cases-track" id="cases-track">
                <?php foreach ( $cases as $case ) : ?>
                    <?php $logo = bires_field( 'case_logo', $case->ID ); ?>
                    <button type="button" class="case-card" aria-haspopup="dialog" aria-controls="case-<?php echo (int) $case->ID; ?>">
                        <?php echo get_the_post_thumbnail( $case, 'large', [ 'class' => 'case-card__bg', 'alt' => '', 'loading' => 'lazy' ] ); ?>
                        <span class="case-card__logo<?php echo bires_field( 'case_logo_large', $case->ID ) ? ' case-card__logo--large' : ''; ?>">
                            <?php if ( $logo ) : ?>
                                <?php echo wp_get_attachment_image( $logo, 'full', false, [ 'alt' => esc_attr( get_the_title( $case ) ), 'loading' => 'lazy' ] ); ?>
                            <?php else : ?>
                                <span class="case-card__name"><?php echo esc_html( get_the_title( $case ) ); ?></span>
                            <?php endif; ?>
                        </span>
                        <span class="case-card__more">
                            <?php esc_html_e( 'Детальніше про співпрацю', 'bires-theme' ); ?>
                            <?php echo bires_icon( 'arrow-up-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?>
                        </span>
                    </button>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <?php
    while ( have_posts() ) :
        the_post();
        if ( '' !== trim( get_the_content() ) ) :
            ?>
            <section class="cases-content">
                <div class="container container--wide entry-content"><?php the_content(); ?></div>
            </section>
            <?php
        endif;
    endwhile;
    ?>

    <?php get_template_part( 'template-parts/client-results' ); ?>
    <?php get_template_part( 'template-parts/contact-section' ); ?>

    <?php foreach ( $cases as $case ) : ?>
        <?php get_template_part( 'template-parts/case-drawer', null, [ 'case' => $case ] ); ?>
    <?php endforeach; ?>
</main>
<?php
get_footer();
