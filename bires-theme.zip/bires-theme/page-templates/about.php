<?php
/*
 * Template Name: Про нас
 */

get_header();

while ( have_posts() ) :
    the_post();
    $hero_title = bires_field( 'hero_title' );
    $hero_text  = bires_field( 'hero_text' );
    $stats      = array_values( array_filter( bires_rows( 'about_stats' ), function ( $row ) {
        return ! empty( $row['number'] );
    } ) );
    $members    = get_posts( [
        'suppress_filters' => false,
        'post_type'      => 'team',
        'posts_per_page' => 12,
        'orderby'        => [ 'menu_order' => 'ASC', 'title' => 'ASC' ],
    ] );
    ?>
    <main class="site-main" id="main">
        <section class="team-hero">
            <div class="container container--wide team-hero__inner">
                <div class="team-hero__content">
                    <nav class="breadcrumbs" aria-label="<?php esc_attr_e( 'Навігаційний ланцюжок', 'bires-theme' ); ?>">
                        <ol>
                            <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Головна', 'bires-theme' ); ?></a></li>
                            <li aria-current="page"><?php the_title(); ?></li>
                        </ol>
                    </nav>
                    <h1 class="team-hero__title"><?php echo esc_html( $hero_title ? $hero_title : __( 'Про фірму Bires Law Firm', 'bires-theme' ) ); ?></h1>
                    <?php if ( $hero_text ) : ?>
                        <p class="about-hero__lead"><?php echo esc_html( $hero_text ); ?></p>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--white"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
                </div>
                <?php if ( has_post_thumbnail() ) : ?>
                    <div class="team-hero__media">
                        <?php the_post_thumbnail( 'large', [ 'alt' => '', 'fetchpriority' => 'high' ] ); ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <?php if ( '' !== trim( get_the_content() ) || $stats ) : ?>
            <section class="team-about about-intro">
                <div class="container container--wide">
                    <div class="section-label"><?php esc_html_e( 'Про нас', 'bires-theme' ); ?></div>
                    <?php if ( '' !== trim( get_the_content() ) ) : ?>
                        <div class="about-intro__content entry-content"><?php the_content(); ?></div>
                    <?php endif; ?>
                    <?php if ( $stats ) : ?>
                        <div class="about-stats">
                            <?php foreach ( $stats as $stat ) : ?>
                                <div class="team-stat team-stat--dark">
                                    <span class="team-stat__number"><?php echo esc_html( $stat['number'] ); ?></span>
                                    <?php if ( ! empty( $stat['text'] ) ) : ?>
                                        <p class="team-stat__sub"><?php echo esc_html( $stat['text'] ); ?></p>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php get_template_part( 'template-parts/client-results' ); ?>

        <?php if ( $members ) : ?>
            <section class="team-slider">
                <div class="container container--wide">
                    <div class="team-slider__heading">
                        <div>
                            <h2 class="sp-title"><?php esc_html_e( 'Наша команда', 'bires-theme' ); ?></h2>
                            <p class="team-slider__text"><a href="<?php echo esc_url( get_post_type_archive_link( 'team' ) ); ?>"><?php esc_html_e( 'Усі юристи та адвокати', 'bires-theme' ); ?></a></p>
                        </div>
                        <div class="slider-arrows slider-arrows--light" data-slider-controls="about-team-track">
                            <button type="button" class="slider-arrow" data-dir="-1" aria-label="<?php esc_attr_e( 'Назад', 'bires-theme' ); ?>"><?php echo bires_icon( 'arrow-left', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></button>
                            <button type="button" class="slider-arrow" data-dir="1" aria-label="<?php esc_attr_e( 'Вперед', 'bires-theme' ); ?>"><?php echo bires_icon( 'arrow-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></button>
                        </div>
                    </div>
                </div>
                <div class="team-slider__track" id="about-team-track">
                    <?php foreach ( $members as $member ) : ?>
                        <?php get_template_part( 'template-parts/person-card', null, [ 'id' => $member->ID, 'variant' => 'dark' ] ); ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php get_template_part( 'template-parts/contact-section' ); ?>
    </main>
    <?php
endwhile;

get_footer();
