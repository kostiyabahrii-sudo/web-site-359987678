<?php
/*
Template Name: Послуги (каталог)
*/

get_header();

while ( have_posts() ) :
    the_post();

    $services = bires_top_services();

    // Кримінальне право, стягнення, майно — у макеті і для бізнесу, і для фізичних осіб (та сама сторінка)
    $groups = [
        'business' => bires_services_for( $services, 'business' ),
        'personal' => bires_services_for( $services, 'personal' ),
    ];

    // Смужка фільтра «Послуги для бізнесу» — категорії з макету, у яких є хоч один напрям
    $tile_cats = [];
    $used_cats = [];
    foreach ( bires_service_tiles( $groups['business'] ) as $tile ) {
        $key               = isset( $tile['service'] ) ? 's' . $tile['service']->ID : 'g' . $tile['group']->term_id;
        $tile_cats[ $key ] = bires_tile_filter_cats( $tile );
        $used_cats         = array_merge( $used_cats, $tile_cats[ $key ] );
    }
    $filter_terms = [];
    foreach ( bires_service_filter_cats() as $slug => $name ) {
        if ( in_array( $slug, $used_cats, true ) ) {
            $term                  = get_term_by( 'slug', $slug, 'service_category' );
            $filter_terms[ $slug ] = $term ? $term->name : $name;
        }
    }

    $hero_title = bires_field( 'hero_title' );
    $hero_text  = bires_field( 'hero_text' );
    ?>

    <main class="site-main" id="main">
        <section class="services-hero">
            <div class="container container--wide">
                <div class="services-hero__content">
                    <div class="services-hero__breadcrumb"><?php esc_html_e( 'Всі послуги', 'bires-theme' ); ?></div>
                    <h1 class="services-hero__title"><?php echo esc_html( $hero_title ? $hero_title : get_the_title() ); ?></h1>
                    <?php if ( $hero_text ) : ?>
                        <p class="services-hero__desc"><?php echo esc_html( $hero_text ); ?></p>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--white"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
                </div>
            </div>
        </section>

        <?php
        $sections = [
            'business' => __( 'Послуги для бізнесу', 'bires-theme' ),
            'personal' => __( 'Послуги для фізичних осіб', 'bires-theme' ),
        ];
        foreach ( $sections as $audience => $section_title ) :
            if ( ! $groups[ $audience ] ) {
                continue;
            }
            $is_business = 'business' === $audience;
            ?>
            <section class="services-list services-list--<?php echo esc_attr( $audience ); ?>">
                <div class="container container--wide">
                    <div class="services-list__heading">
                        <h2 class="services-list__title"><?php echo esc_html( $section_title ); ?></h2>
                        <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--<?php echo $is_business ? 'outline-dark' : 'outline-light'; ?>"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
                    </div>

                    <?php if ( $is_business && $filter_terms ) : ?>
                        <div class="services-filter" aria-label="<?php esc_attr_e( 'Категорії послуг', 'bires-theme' ); ?>">
                            <button type="button" class="services-filter__btn is-active" data-filter="all" aria-pressed="true"><?php esc_html_e( 'Усі послуги', 'bires-theme' ); ?></button>
                            <?php foreach ( $filter_terms as $slug => $name ) : ?>
                                <button type="button" class="services-filter__btn" data-filter="<?php echo esc_attr( $slug ); ?>" aria-pressed="false"><?php echo esc_html( $name ); ?></button>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <?php // Плитки напрямів (як у макеті): іконка, назва, стрілка; уся плитка — посилання на сторінку напряму ?>
                    <div class="services-grid"<?php echo $is_business ? ' data-services-grid' : ''; ?>>
                        <?php foreach ( bires_service_tiles( $groups[ $audience ] ) as $tile ) : ?>
                            <?php
                            $key  = isset( $tile['service'] ) ? 's' . $tile['service']->ID : 'g' . $tile['group']->term_id;
                            $cats = $is_business && isset( $tile_cats[ $key ] ) ? implode( ' ', $tile_cats[ $key ] ) : '';
                            ?>
                            <a href="<?php echo esc_url( bires_tile_url( $tile ) ); ?>" class="service-tile<?php echo $is_business ? '' : ' service-tile--green'; ?>"<?php echo isset( $tile['group'] ) ? ' id="' . esc_attr( rawurldecode( $tile['group']->slug ) ) . '"' : ''; ?><?php echo $is_business ? ' data-cats="' . esc_attr( $cats ) . '"' : ''; ?>>
                                <div class="service-tile__heading">
                                    <span class="service-tile__icon"><?php echo bires_icon( bires_tile_icon( $tile ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                                    <h3 class="service-tile__title"><?php echo bires_card_title( bires_tile_title( $tile ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside ?></h3>
                                </div>
                                <span class="service-tile__arrow"><?php echo bires_icon( 'arrow-up-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    <div class="services-list__more">
                        <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--<?php echo $is_business ? 'outline-dark' : 'outline-light'; ?>"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
                    </div>
                </div>
            </section>
        <?php endforeach; ?>

        <?php get_template_part( 'template-parts/seo-text' ); ?>
        <?php get_template_part( 'template-parts/faq' ); ?>
    </main>

    <?php
endwhile;

get_footer();
