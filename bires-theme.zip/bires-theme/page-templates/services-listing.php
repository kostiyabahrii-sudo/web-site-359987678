<?php
/*
Template Name: Послуги (каталог)
*/

get_header();

while ( have_posts() ) :
    the_post();

    $services = bires_top_services();

    $groups = [ 'business' => [], 'personal' => [] ];
    foreach ( $services as $service ) {
        $audience = bires_field( 'service_audience', $service->ID ) === 'personal' ? 'personal' : 'business';
        $groups[ $audience ][] = $service;
    }

    $tile_terms = [];
    $used_terms = [];
    foreach ( $groups['business'] as $service ) {
        $terms = get_the_terms( $service->ID, 'service_category' );
        $tile_terms[ $service->ID ] = [];
        if ( $terms && ! is_wp_error( $terms ) && ! bires_service_group( $service->ID ) ) {
            foreach ( $terms as $term ) {
                $used_terms[ $term->term_id ] = true;
                $tile_terms[ $service->ID ][] = $term->slug;
            }
        }
    }

    $filter_terms = [];
    if ( $used_terms ) {
        $filter_terms = get_terms( [
            'taxonomy'   => 'service_category',
            'include'    => array_keys( $used_terms ),
            'orderby'    => 'term_id',
            'hide_empty' => false,
        ] );
        $filter_terms = is_wp_error( $filter_terms ) ? [] : $filter_terms;
    }

    $hero_title = bires_field( 'hero_title' );
    $hero_text  = bires_field( 'hero_text' );
    ?>

    <main class="site-main" id="main">
        <section class="services-hero">
            <div class="container container--wide">
                <div class="services-hero__content">
                    <div class="services-hero__breadcrumb"><?php esc_html_e( 'Всі послуги', 'bires-theme' ); ?></div>
                    <h1 class="services-hero__title"><?php echo esc_html( $hero_title ? $hero_title : get_the_title() ); ?></h1>
                    <?php if ( $hero_text ) : ?>
                        <p class="services-hero__desc"><?php echo esc_html( $hero_text ); ?></p>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--white"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
                </div>
            </div>
        </section>

        <?php
        $sections = [
            'business' => __( 'Послуги для бізнесу', 'bires-theme' ),
            'personal' => __( 'Послуги для фізичних осіб', 'bires-theme' ),
        ];
        foreach ( $sections as $audience => $section_title ) :
            if ( ! $groups[ $audience ] ) {
                continue;
            }
            $is_business = 'business' === $audience;
            ?>
            <section class="services-list services-list--<?php echo esc_attr( $audience ); ?>">
                <div class="container container--wide">
                    <div class="services-list__heading">
                        <h2 class="services-list__title"><?php echo esc_html( $section_title ); ?></h2>
                        <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--<?php echo $is_business ? 'outline-dark' : 'outline-light'; ?>"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
                    </div>

                    <?php if ( $is_business && $filter_terms ) : ?>
                        <div class="services-filter" aria-label="<?php esc_attr_e( 'Категорії послуг', 'bires-theme' ); ?>">
                            <button type="button" class="services-filter__btn is-active" data-filter="all" aria-pressed="true"><?php esc_html_e( 'Усі послуги', 'bires-theme' ); ?></button>
                            <?php foreach ( $filter_terms as $term ) : ?>
                                <button type="button" class="services-filter__btn" data-filter="<?php echo esc_attr( $term->slug ); ?>" aria-pressed="false"><?php echo esc_html( $term->name ); ?></button>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <div class="services-grid"<?php echo $is_business ? ' data-services-grid' : ''; ?>>
                        <?php foreach ( bires_service_tiles( $groups[ $audience ] ) as $tile ) : ?>
                            <?php if ( isset( $tile['group'] ) ) : ?>
                                <?php // Група послуг (як акордеон на старому сайті): назва групи й посилання на її послуги ?>
                                <div class="service-tile service-tile--group<?php echo $is_business ? '' : ' service-tile--green'; ?><?php echo count( $tile['items'] ) > BIRES_CATALOG_VISIBLE_ITEMS ? ' service-tile--collapsible' : ''; ?>" id="<?php echo esc_attr( rawurldecode( $tile['group']->slug ) ); ?>"<?php echo $is_business ? ' data-cats=""' : ''; ?>>
                                    <div class="service-tile__heading">
                                        <h3 class="service-tile__title"><?php echo esc_html( $tile['group']->name ); ?></h3>
                                    </div>
                                    <?php
                                    // Довгий список: видно три послуги, решта — під кнопкою «Розгорнути всі» (приховані лишаються в розмітці)
                                    $collapsible = count( $tile['items'] ) > BIRES_CATALOG_VISIBLE_ITEMS;
                                    $list_id     = 'tile-list-' . $tile['group']->term_id . '-' . $audience;
                                    ?>
                                    <div class="service-tile__links">
                                        <ul class="service-tile__list" id="<?php echo esc_attr( $list_id ); ?>">
                                            <?php foreach ( $tile['items'] as $i => $item ) : ?>
                                                <li<?php echo $collapsible && $i >= BIRES_CATALOG_VISIBLE_ITEMS ? ' class="is-extra"' : ''; ?>><a href="<?php echo esc_url( get_permalink( $item ) ); ?>"><?php echo esc_html( get_the_title( $item ) ); ?></a></li>
                                            <?php endforeach; ?>
                                        </ul>
                                        <?php if ( $collapsible ) : ?>
                                            <button type="button" class="service-tile__more" aria-expanded="false" aria-controls="<?php echo esc_attr( $list_id ); ?>" data-more="<?php esc_attr_e( 'Розгорнути всі', 'bires-theme' ); ?>" data-less="<?php esc_attr_e( 'Згорнути', 'bires-theme' ); ?>"><?php esc_html_e( 'Розгорнути всі', 'bires-theme' ); ?></button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php continue; ?>
                            <?php endif; ?>
                            <?php
                            $service    = $tile['service'];
                            $card_title = bires_field( 'service_card_title', $service->ID );
                            $icon       = bires_field( 'service_icon', $service->ID );
                            $cats_attr  = $is_business ? ' data-cats="' . esc_attr( implode( ' ', $tile_terms[ $service->ID ] ) ) . '"' : '';
                            ?>
                            <a href="<?php echo esc_url( get_permalink( $service ) ); ?>" class="service-tile<?php echo $is_business ? '' : ' service-tile--green'; ?>"<?php echo $cats_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above ?>>
                                <div class="service-tile__heading">
                                    <?php if ( $icon ) : ?>
                                        <span class="service-tile__icon"><?php echo bires_icon( $icon ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                                    <?php endif; ?>
                                    <h3 class="service-tile__title"><?php echo bires_card_title( $card_title ? $card_title : get_the_title( $service ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside ?></h3>
                                </div>
                                <span class="service-tile__arrow"><?php echo bires_icon( 'arrow-up-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    <div class="services-list__more">
                        <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--<?php echo $is_business ? 'outline-dark' : 'outline-light'; ?>"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
                    </div>
                </div>
            </section>
        <?php endforeach; ?>

        <?php get_template_part( 'template-parts/seo-text' ); ?>
        <?php get_template_part( 'template-parts/faq' ); ?>
    </main>

    <?php
endwhile;

get_footer();
