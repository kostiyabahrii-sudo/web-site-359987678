<?php
/*
Template Name: Послуги (каталог)
*/

get_header();

while ( have_posts() ) :
    the_post();

    $services = bires_top_services();

    $groups = [ 'business' => [], 'personal' => [] ];
    foreach ( $services as $service ) {
        $audience = bires_field( 'service_audience', $service->ID ) === 'personal' ? 'personal' : 'business';
        $groups[ $audience ][] = $service;
    }

    $tile_terms = [];
    $used_terms = [];
    foreach ( $groups['business'] as $service ) {
        $terms = get_the_terms( $service->ID, 'service_category' );
        $tile_terms[ $service->ID ] = [];
        if ( $terms && ! is_wp_error( $terms ) && ! bires_service_group( $service->ID ) ) {
            foreach ( $terms as $term ) {
                $used_terms[ $term->term_id ] = true;
                $tile_terms[ $service->ID ][] = $term->slug;
            }
        }
    }

    // Плитки-групи (податкова практика, кадри…): їхні категорії фільтра — у полі групи bires_filter_cats
    $group_cats = [];
    foreach ( bires_service_tiles( $groups['business'] ) as $tile ) {
        if ( isset( $tile['group'] ) ) {
            $slugs = array_filter( (array) get_term_meta( $tile['group']->term_id, 'bires_filter_cats', true ) );
            $group_cats[ $tile['group']->term_id ] = [];
            foreach ( $slugs as $slug ) {
                $term = get_term_by( 'slug', $slug, 'service_category' );
                if ( $term ) {
                    $used_terms[ $term->term_id ]              = true;
                    $group_cats[ $tile['group']->term_id ][] = $term->slug;
                }
            }
        }
    }

    $filter_terms = [];
    if ( $used_terms ) {
        $filter_terms = get_terms( [
            'taxonomy'   => 'service_category',
            'include'    => array_keys( $used_terms ),
            'orderby'    => 'term_id',
            'hide_empty' => false,
        ] );
        $filter_terms = is_wp_error( $filter_terms ) ? [] : $filter_terms;
    }

    $hero_title = bires_field( 'hero_title' );
    $hero_text  = bires_field( 'hero_text' );
    ?>

    <main class="site-main" id="main">
        <section class="services-hero">
            <div class="container container--wide">
                <div class="services-hero__content">
                    <div class="services-hero__breadcrumb"><?php esc_html_e( 'Всі послуги', 'bires-theme' ); ?></div>
                    <h1 class="services-hero__title"><?php echo esc_html( $hero_title ? $hero_title : get_the_title() ); ?></h1>
                    <?php if ( $hero_text ) : ?>
                        <p class="services-hero__desc"><?php echo esc_html( $hero_text ); ?></p>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--white"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
                </div>
            </div>
        </section>

        <?php
        $sections = [
            'business' => __( 'Послуги для бізнесу', 'bires-theme' ),
            'personal' => __( 'Послуги для фізичних осіб', 'bires-theme' ),
        ];
        foreach ( $sections as $audience => $section_title ) :
            if ( ! $groups[ $audience ] ) {
                continue;
            }
            $is_business = 'business' === $audience;
            ?>
            <section class="services-list services-list--<?php echo esc_attr( $audience ); ?>">
                <div class="container container--wide">
                    <div class="services-list__heading">
                        <h2 class="services-list__title"><?php echo esc_html( $section_title ); ?></h2>
                        <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--<?php echo $is_business ? 'outline-dark' : 'outline-light'; ?>"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
                    </div>

                    <?php if ( $is_business && $filter_terms ) : ?>
                        <div class="services-filter" aria-label="<?php esc_attr_e( 'Категорії послуг', 'bires-theme' ); ?>">
                            <button type="button" class="services-filter__btn is-active" data-filter="all" aria-pressed="true"><?php esc_html_e( 'Усі послуги', 'bires-theme' ); ?></button>
                            <?php foreach ( $filter_terms as $term ) : ?>
                                <button type="button" class="services-filter__btn" data-filter="<?php echo esc_attr( $term->slug ); ?>" aria-pressed="false"><?php echo esc_html( $term->name ); ?></button>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <?php // Плитки напрямів (як у макеті): іконка, назва, стрілка; уся плитка — посилання на сторінку напряму ?>
                    <div class="services-grid"<?php echo $is_business ? ' data-services-grid' : ''; ?>>
                        <?php foreach ( bires_service_tiles( $groups[ $audience ] ) as $tile ) : ?>
                            <?php
                            $tile_cats = '';
                            if ( $is_business ) {
                                $tile_cats = isset( $tile['service'] ) ? implode( ' ', $tile_terms[ $tile['service']->ID ] ) : implode( ' ', isset( $group_cats[ $tile['group']->term_id ] ) ? $group_cats[ $tile['group']->term_id ] : [] );
                            }
                            ?>
                            <a href="<?php echo esc_url( bires_tile_url( $tile ) ); ?>" class="service-tile<?php echo $is_business ? '' : ' service-tile--green'; ?>"<?php echo isset( $tile['group'] ) ? ' id="' . esc_attr( rawurldecode( $tile['group']->slug ) ) . '"' : ''; ?><?php echo $is_business ? ' data-cats="' . esc_attr( $tile_cats ) . '"' : ''; ?>>
                                <div class="service-tile__heading">
                                    <span class="service-tile__icon"><?php echo bires_icon( bires_tile_icon( $tile ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                                    <h3 class="service-tile__title"><?php echo bires_card_title( bires_tile_title( $tile ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside ?></h3>
                                </div>
                                <span class="service-tile__arrow"><?php echo bires_icon( 'arrow-up-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    <div class="services-list__more">
                        <a href="<?php echo esc_url( bires_contact_url() ); ?>" class="services-btn services-btn--<?php echo $is_business ? 'outline-dark' : 'outline-light'; ?>"><?php esc_html_e( 'Отримайте консультацію', 'bires-theme' ); ?></a>
                    </div>
                </div>
            </section>
        <?php endforeach; ?>

        <?php get_template_part( 'template-parts/seo-text' ); ?>
        <?php get_template_part( 'template-parts/faq' ); ?>
    </main>

    <?php
endwhile;

get_footer();
