<?php
/*
 * Template Name: Мапа сайту (HTML)
 */

get_header();

list( $groups, $current, $total ) = bires_sitemap_paginate( bires_sitemap_groups(), get_query_var( 'page' ) );
$base_url = get_permalink();
?>
<main class="site-main" id="main">
    <section class="sitemap">
        <div class="container container--wide">
            <nav class="breadcrumbs" aria-label="<?php esc_attr_e( 'Навігаційний ланцюжок', 'bires-theme' ); ?>">
                <ol>
                    <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Головна', 'bires-theme' ); ?></a></li>
                    <li aria-current="page"><?php the_title(); ?></li>
                </ol>
            </nav>
            <h1 class="sitemap__title"><?php the_title(); ?></h1>

            <div class="sitemap__groups">
                <?php foreach ( $groups as $group ) : ?>
                    <section class="sitemap__group">
                        <h2 class="sitemap__heading">
                            <?php echo esc_html( $group['title'] ); ?>
                            <?php if ( $group['continued'] ) : ?>
                                <span class="sitemap__continued"><?php esc_html_e( '(продовження)', 'bires-theme' ); ?></span>
                            <?php endif; ?>
                        </h2>
                        <ul class="sitemap__list">
                            <?php foreach ( $group['items'] as $item ) : ?>
                                <li class="sitemap__item sitemap__item--depth-<?php echo (int) min( 3, $item['depth'] ); ?>"><a href="<?php echo esc_url( $item['url'] ); ?>"><?php echo esc_html( $item['title'] ); ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </section>
                <?php endforeach; ?>
            </div>

            <?php if ( $total > 1 ) : ?>
                <nav class="pagination" aria-label="<?php esc_attr_e( 'Сторінки', 'bires-theme' ); ?>">
                    <?php for ( $n = 1; $n <= $total; $n++ ) : ?>
                        <?php if ( $n === $current ) : ?>
                            <span class="page-numbers current" aria-current="page"><?php echo (int) $n; ?></span>
                        <?php else : ?>
                            <a class="page-numbers" href="<?php echo esc_url( 1 === $n ? $base_url : trailingslashit( $base_url ) . user_trailingslashit( (string) $n, 'single_paged' ) ); ?>"><?php echo (int) $n; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                </nav>
            <?php endif; ?>
        </div>
    </section>
</main>
<?php
get_footer();
