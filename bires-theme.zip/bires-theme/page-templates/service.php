<?php
/*
Template Name: Послуга
*/

get_header();
?>

<main class="site-main" id="main">
    <?php while ( have_posts() ) : ?>
        <?php the_post(); ?>
        <?php get_template_part( 'template-parts/service-single' ); ?>
    <?php endwhile; ?>
</main>

<?php
get_footer();
