<?php
/*
 * Template Name: Контакти
 */

get_header();

$email      = bires_option( 'contact_email', 'info@bires.com.ua' );
$phones     = array_filter( [ bires_option( 'contact_phone_2', '(+380) 96 106 20 56' ), bires_option( 'contact_phone_1', '(+380) 44 334 75 04' ) ] );
$telegram   = bires_option( 'social_telegram' );
$manager    = bires_contact_manager( false );
$hero_title = bires_field( 'hero_title' );
$form_title = bires_field( 'contact_form_title' );
$form_text  = bires_field( 'contact_form_text' );
$qr_id      = bires_field( 'contact_qr' );
$office_lbl = bires_field( 'office_label' );
$office     = bires_field( 'office_title' );
$address    = bires_field( 'office_address' );
$gallery    = array_filter( wp_list_pluck( bires_rows( 'office_gallery' ), 'image' ) );
$map_query  = bires_field( 'map_query' );
$map_image  = bires_field( 'map_image' );
$map_link   = bires_field( 'map_link' );
?>
<main class="site-main contact-page" id="main">
    <section class="contact-hero" id="contact">
        <div class="contact-hero__info">
            <h1 class="contact-hero__title"><?php echo esc_html( $hero_title ? $hero_title : __( 'Маєте юридичне питання?', 'bires-theme' ) ); ?></h1>
            <div class="contact-hero__details">
                <?php if ( $manager ) : ?>
                    <div class="contact-hero__manager">
                        <div class="contact-hero__photo<?php echo $manager['cutout'] ? ' is-cutout' : ''; ?>">
                            <?php echo bires_contact_manager_photo( $manager, 'contact-hero' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_get_attachment_image ?>
                        </div>
                        <div>
                            <p class="contact-hero__name"><?php echo esc_html( $manager['name'] ); ?></p>
                            <p class="contact-hero__role"><?php echo esc_html( $manager['role'] ); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
                <dl class="contact-list">
                    <?php if ( $phones ) : ?>
                        <div class="contact-list__row">
                            <dt><?php esc_html_e( 'Телефон', 'bires-theme' ); ?></dt>
                            <dd class="contact-list__phones">
                                <?php foreach ( array_values( $phones ) as $i => $phone ) : ?>
                                    <?php if ( $i ) : ?><span class="contact-list__dot" aria-hidden="true"></span><?php endif; ?>
                                    <a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a>
                                <?php endforeach; ?>
                            </dd>
                        </div>
                    <?php endif; ?>
                    <div class="contact-list__row">
                        <dt><?php esc_html_e( 'Електронна пошта', 'bires-theme' ); ?></dt>
                        <dd><a href="mailto:<?php echo esc_attr( antispambot( $email ) ); ?>"><?php echo esc_html( antispambot( $email ) ); ?></a></dd>
                    </div>
                    <?php if ( $telegram ) : ?>
                        <div class="contact-list__row contact-list__row--qr">
                            <dt><?php esc_html_e( 'Телеграм', 'bires-theme' ); ?></dt>
                            <dd>
                                <a class="contact-list__tg" href="<?php echo esc_url( $telegram ); ?>" rel="noopener">
                                    <svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="10" fill="#fff"/><path d="m4.6 9.7 9.2-3.6c.4-.2.8.1.7.7l-1.6 7.4c-.1.5-.4.6-.9.4l-2.4-1.8-1.2 1.1c-.1.1-.2.2-.5.2l.2-2.5 4.5-4.1c.2-.2 0-.3-.3-.1l-5.6 3.5-2.4-.7c-.5-.2-.5-.5.3-.9Z" fill="#000"/></svg>
                                    <?php echo esc_html( $telegram ); ?>
                                </a>
                                <?php if ( $qr_id ) : ?>
                                    <?php echo wp_get_attachment_image( $qr_id, 'thumbnail', false, [ 'class' => 'contact-list__qr', 'alt' => esc_attr__( 'QR-код Телеграм', 'bires-theme' ), 'loading' => 'lazy' ] ); ?>
                                <?php endif; ?>
                            </dd>
                        </div>
                    <?php endif; ?>
                </dl>
            </div>
        </div>
        <div class="contact-hero__form">
            <div class="contact-hero__heading">
                <h2><?php echo esc_html( $form_title ? $form_title : __( 'Зв’яжіться з нами', 'bires-theme' ) ); ?></h2>
                <p>
                    <?php echo esc_html( $form_text ? $form_text : __( 'Заповніть форму або пишіть на:', 'bires-theme' ) ); ?>
                    <a href="mailto:<?php echo esc_attr( antispambot( $email ) ); ?>"><?php echo esc_html( antispambot( $email ) ); ?></a>
                </p>
            </div>
            <?php get_template_part( 'template-parts/contact-form', null, [ 'variant' => 'page' ] ); ?>
        </div>
    </section>

    <?php if ( $office || $gallery ) : ?>
        <section class="office">
            <div class="container container--wide">
                <div class="section-label"><?php echo esc_html( $office_lbl ? $office_lbl : __( 'Офіс', 'bires-theme' ) ); ?></div>
                <div class="office__heading">
                    <div>
                        <?php if ( $office ) : ?>
                            <h2 class="office__title"><?php echo esc_html( $office ); ?></h2>
                        <?php endif; ?>
                        <?php if ( $address ) : ?>
                            <p class="office__address"><?php echo nl2br( esc_html( $address ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped before nl2br ?></p>
                        <?php endif; ?>
                    </div>
                    <?php if ( count( $gallery ) > 1 ) : ?>
                        <div class="slider-arrows" data-slider-controls="office-track">
                            <button type="button" class="slider-arrow" data-dir="-1" aria-label="<?php esc_attr_e( 'Назад', 'bires-theme' ); ?>"><?php echo bires_icon( 'arrow-left', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></button>
                            <button type="button" class="slider-arrow" data-dir="1" aria-label="<?php esc_attr_e( 'Вперед', 'bires-theme' ); ?>"><?php echo bires_icon( 'arrow-right', 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php if ( $gallery ) : ?>
                <div class="office__track" id="office-track">
                    <?php foreach ( array_values( $gallery ) as $i => $image_id ) : ?>
                        <div class="office__slide">
                            <?php echo wp_get_attachment_image( $image_id, 'large', false, [ 'loading' => 'lazy', 'sizes' => '(max-width: 767px) 90vw, 932px' ] ); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if ( $map_image || $map_query ) : ?>
        <?php $route_url = $map_query ? 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( $map_query ) : $map_link; ?>
        <section class="contact-map" aria-label="<?php esc_attr_e( 'Мапа', 'bires-theme' ); ?>">
            <div class="container container--wide">
                <div class="contact-map__head">
                    <div class="section-label"><?php esc_html_e( 'Як дістатися', 'bires-theme' ); ?></div>
                    <?php if ( $route_url ) : ?>
                        <a class="contact-map__route" href="<?php echo esc_url( $route_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Прокласти маршрут', 'bires-theme' ); ?><?php echo bires_icon( 'arrow-up-right', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></a>
                    <?php endif; ?>
                </div>
                <?php if ( $map_query ) : ?>
                    <?php // Жива мапа Google; щоб колесо миші не «чіплялось» за мапу під час прокрутки сторінки — вмикається кліком ?>
                    <div class="contact-map__frame contact-map__frame--live" data-map>
                        <iframe title="<?php echo esc_attr( sprintf( /* translators: %s: address */ __( 'Мапа: %s', 'bires-theme' ), $map_query ) ); ?>" src="<?php echo esc_url( 'https://www.google.com/maps?output=embed&hl=uk&z=16&q=' . rawurlencode( $map_query ) ); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
                        <button type="button" class="contact-map__activate" data-map-activate><span><?php esc_html_e( 'Натисніть, щоб рухати мапу', 'bires-theme' ); ?></span></button>
                    </div>
                <?php else : ?>
                    <div class="contact-map__frame">
                        <?php if ( $map_link ) : ?><a href="<?php echo esc_url( $map_link ); ?>" target="_blank" rel="noopener"><?php endif; ?>
                        <?php echo wp_get_attachment_image( $map_image, 'full', false, [ 'loading' => 'lazy', 'alt' => esc_attr( $address ? wp_strip_all_tags( $address ) : __( 'Мапа', 'bires-theme' ) ) ] ); ?>
                        <?php if ( $map_link ) : ?></a><?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>
</main>
<?php
get_footer();
