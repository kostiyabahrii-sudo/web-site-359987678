Сюди кладуть файли шрифту Proxima Nova (ліцензія):
proxima-nova-regular.woff2
proxima-nova-medium.woff2
proxima-nova-semibold.woff2
proxima-nova-bold.woff2
