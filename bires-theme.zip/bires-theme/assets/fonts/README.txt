Сюди кладуть файли шрифту Proxima Nova (ліцензія):
proxima-nova-regular.woff2
proxima-nova-medium.woff2
proxima-nova-semibold.woff2
proxima-nova-bold.woff2

Шрифт великих цифр (Reckless Standard XL Regular, потрібна веб-ліцензія — пробна TRIAL-версія для сайту не дозволена):
reckless-standard-xl-regular.woff2  (можна також .woff, .otf або .ttf)
