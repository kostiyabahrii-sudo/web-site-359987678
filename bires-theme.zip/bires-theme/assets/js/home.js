document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-achievements]').forEach(function (section) {
        const items = section.querySelectorAll('[data-achievement]');
        const track = section.querySelector('[data-achievement-track]');
        const slides = track ? Array.from(track.children) : [];
        let active = 0;

        // Активне фото завжди стоїть першим, наступні йдуть за ним по колу (виглядає наступне, як у макеті).
        // Без прокрутки стрічки — тож не лишається смужки від попереднього фото і нічого не обрізається.
        function show(index) {
            active = (index + items.length) % items.length;
            items.forEach(function (item, i) {
                item.hidden = i !== active;
            });
            slides.forEach(function (slide, i) {
                slide.style.order = (i - active + slides.length) % slides.length;
                slide.classList.remove('is-entering');
                void slide.offsetWidth;
                slide.classList.add('is-entering');
            });
        }

        section.querySelectorAll('[data-achievement-next]').forEach(function (button) {
            button.addEventListener('click', function () {
                show(active + 1);
                const next = items[active].querySelector('[data-achievement-next]');
                if (next) {
                    next.focus();
                }
            });
        });
    });
});
