document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-achievements]').forEach(function (section) {
        const items = section.querySelectorAll('[data-achievement]');
        const track = section.querySelector('[data-achievement-track]');
        let active = 0;

        function show(index) {
            active = (index + items.length) % items.length;
            items.forEach(function (item, i) {
                item.hidden = i !== active;
            });
            const slide = track.children[active];
            if (slide) {
                track.scrollTo({ left: slide.offsetLeft - track.firstElementChild.offsetLeft, behavior: 'smooth' });
            }
        }

        section.querySelectorAll('[data-achievement-next]').forEach(function (button) {
            button.addEventListener('click', function () {
                show(active + 1);
                const next = items[active].querySelector('[data-achievement-next]');
                if (next) {
                    next.focus();
                }
            });
        });
    });
});
