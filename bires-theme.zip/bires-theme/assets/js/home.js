document.addEventListener('DOMContentLoaded', function () {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Стрічка з картками однакової ширини: номер картки біля лівого краю та прокрутка до картки
    function strip(track) {
        const cards = function () {
            return Array.from(track.children);
        };
        return {
            cards: cards,
            index: function () {
                const list = cards();
                if (list.length < 2) {
                    return 0;
                }
                const step = list[1].offsetLeft - list[0].offsetLeft;
                return step > 0 ? Math.round(track.scrollLeft / step) : 0;
            },
            go: function (index, smooth) {
                const list = cards();
                if (list[index]) {
                    track.scrollTo({ left: list[index].offsetLeft - list[0].offsetLeft, behavior: smooth && !reduceMotion ? 'smooth' : 'auto' });
                }
            },
        };
    }

    // Кінець прокрутки (свайп, колесо, scrollTo): подія scrollend, а де її немає — пауза після останнього scroll
    function onScrollEnd(track, callback) {
        let timer = 0;
        if ('onscrollend' in window) {
            track.addEventListener('scrollend', callback);
            return;
        }
        track.addEventListener('scroll', function () {
            clearTimeout(timer);
            timer = setTimeout(callback, 140);
        }, { passive: true });
    }

    /* ===== Відгуки: логотип праворуч показує відгук своєї компанії ===== */
    document.querySelectorAll('[data-reviews]').forEach(function (section) {
        const track = section.querySelector('[data-reviews-track]');
        if (!track) {
            return;
        }
        const reviews = strip(track);
        const tiles = Array.from(section.querySelectorAll('.home-logos__button'));
        const buttons = tiles.filter(function (button) {
            return button.hasAttribute('data-review-logo');
        });
        let hoverTimer = 0;

        // Вибрана (кольорова) плитка — одна: натиснута або та, чий відгук зараз показано
        function select(current) {
            tiles.forEach(function (button) {
                const on = button === current;
                button.setAttribute('aria-pressed', on ? 'true' : 'false');
                button.parentElement.classList.toggle('is-active', on);
            });
        }

        function mark(slot) {
            select(buttons.find(function (button) {
                return Number(button.dataset.reviewLogo) === slot;
            }) || null);
        }

        function show(slot) {
            if (reviews.index() !== slot) {
                reviews.go(slot, true);
            }
            mark(slot);
        }

        // Логотип без відгуку: натискання робить його кольоровим (відгук ліворуч не змінюється)
        tiles.forEach(function (button) {
            if (!button.hasAttribute('data-review-logo')) {
                button.addEventListener('click', function () {
                    select(button);
                });
            }
        });

        buttons.forEach(function (button) {
            const slot = Number(button.dataset.reviewLogo);
            // Наведення мишею (з короткою паузою, щоб не перемикати, коли курсор лише пробігає по сітці)
            button.addEventListener('pointerenter', function (event) {
                if (event.pointerType !== 'mouse') {
                    return;
                }
                clearTimeout(hoverTimer);
                hoverTimer = setTimeout(function () {
                    show(slot);
                }, 90);
            });
            button.addEventListener('pointerleave', function () {
                clearTimeout(hoverTimer);
            });
            // Клік, дотик на телефоні, Enter/пробіл з клавіатури
            button.addEventListener('click', function () {
                clearTimeout(hoverTimer);
                show(slot);
            });
        });

        // Відгук перегорнули свайпом — підсвічуємо його логотип
        onScrollEnd(track, function () {
            mark(reviews.index());
        });
    });

    /* ===== Наші досягнення: активне фото й наступне поруч; клік по наступному, стрілка або свайп — далі ===== */
    document.querySelectorAll('[data-achievements]').forEach(function (section) {
        const items = Array.from(section.querySelectorAll('[data-achievement]'));
        const track = section.querySelector('[data-achievement-track]');
        if (!track || !items.length) {
            return;
        }
        const photos = strip(track);
        const count = items.length;
        let active = 0;

        // Текст ліворуч — від фото, що стоїть першим у стрічці
        function sync(index) {
            const next = ((index % count) + count) % count;
            photos.cards().forEach(function (slide, i) {
                slide.classList.toggle('is-active', i === index);
            });
            if (next === active) {
                return;
            }
            active = next;
            items.forEach(function (item, i) {
                const hide = i !== active;
                item.classList.toggle('is-hidden', hide);
                item.toggleAttribute('inert', hide);
                if (hide) {
                    item.setAttribute('aria-hidden', 'true');
                } else {
                    item.removeAttribute('aria-hidden');
                }
            });
        }

        function go(index) {
            photos.go(index, true);
            sync(index);
        }

        // Фото йдуть двічі поспіль: з останнього досягнення стрілка веде на копію першого, після чого стрічка
        // непомітно повертається на початок — справа завжди видно наступне фото, як у макеті
        onScrollEnd(track, function () {
            let index = photos.index();
            if (count > 1 && index >= count) {
                index -= count;
                photos.go(index, false);
            }
            sync(index);
        });

        track.addEventListener('scroll', function () {
            sync(photos.index());
        }, { passive: true });

        photos.cards().forEach(function (slide, i) {
            slide.addEventListener('click', function () {
                if (i !== photos.index()) {
                    go(i);
                }
            });
        });

        section.querySelectorAll('[data-achievement-next]').forEach(function (button) {
            button.addEventListener('click', function () {
                go(photos.index() + 1);
                const next = items[active].querySelector('[data-achievement-next]');
                if (next) {
                    next.focus({ preventScroll: true });
                }
            });
        });
    });
});
