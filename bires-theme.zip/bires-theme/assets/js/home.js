document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-achievements]').forEach(function (section) {
        const items = section.querySelectorAll('[data-achievement]');
        const track = section.querySelector('[data-achievement-track]');
        const slides = track ? Array.from(track.children) : [];
        let active = 0;

        // Показуємо лише одне фото — активне; нове плавно проявляється поверх попереднього.
        function show(index) {
            active = (index + items.length) % items.length;
            items.forEach(function (item, i) {
                item.hidden = i !== active;
            });
            slides.forEach(function (slide, i) {
                slide.classList.toggle('is-active', i === active);
            });
        }

        section.querySelectorAll('[data-achievement-next]').forEach(function (button) {
            button.addEventListener('click', function () {
                show(active + 1);
                const next = items[active].querySelector('[data-achievement-next]');
                if (next) {
                    next.focus();
                }
            });
        });
    });
});
