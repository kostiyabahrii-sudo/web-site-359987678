document.addEventListener('DOMContentLoaded', function () {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Відповідь плавно розгортається й згортається (висота, відступ, прозорість); стрілка повертається через CSS
    function slide(answer, open) {
        if (answer.faqAnimation) {
            answer.faqAnimation.cancel();
        }
        if (reduceMotion || !answer.animate) {
            answer.hidden = !open;
            return;
        }
        answer.hidden = false;
        const full = { height: answer.scrollHeight + 'px', marginTop: getComputedStyle(answer).marginTop, opacity: 1 };
        const none = { height: '0px', marginTop: '0px', opacity: 0 };
        answer.style.overflow = 'hidden';
        const animation = answer.animate(open ? [none, full] : [full, none], { duration: open ? 320 : 260, easing: 'ease' });
        answer.faqAnimation = animation;
        animation.onfinish = function () {
            answer.style.overflow = '';
            answer.hidden = !open;
            answer.faqAnimation = null;
        };
    }

    document.querySelectorAll('.faq__trigger').forEach(function (trigger) {
        trigger.addEventListener('click', function () {
            const item = trigger.closest('.faq__item');
            const answer = document.getElementById(trigger.getAttribute('aria-controls'));
            const open = trigger.getAttribute('aria-expanded') !== 'true';

            trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
            item.classList.toggle('is-open', open);
            slide(answer, open);
        });
    });

    document.querySelectorAll('[data-faq-more]').forEach(function (button) {
        button.addEventListener('click', function () {
            button.closest('.faq').querySelectorAll('[data-faq-extra]').forEach(function (item) {
                item.hidden = false;
            });
            button.remove();
        });
    });

    document.querySelectorAll('[data-collapsible]').forEach(function (content) {
        const toggle = content.parentElement.querySelector('.seo-text__toggle');
        if (!toggle) {
            return;
        }

        content.classList.add('is-collapsed');
        if (content.scrollHeight <= content.clientHeight + 8) {
            content.classList.remove('is-collapsed');
            return;
        }

        toggle.hidden = false;
        toggle.addEventListener('click', function () {
            const expanded = toggle.getAttribute('aria-expanded') === 'true';
            toggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
            content.classList.toggle('is-collapsed', expanded);
            toggle.querySelector('[data-label-more]').hidden = !expanded;
            toggle.querySelector('[data-label-less]').hidden = expanded;
        });
    });
});
