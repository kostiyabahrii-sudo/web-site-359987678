document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.faq__trigger').forEach(function (trigger) {
        trigger.addEventListener('click', function () {
            const item = trigger.closest('.faq__item');
            const answer = document.getElementById(trigger.getAttribute('aria-controls'));
            const open = trigger.getAttribute('aria-expanded') !== 'true';

            trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
            item.classList.toggle('is-open', open);
            answer.hidden = !open;
        });
    });

    document.querySelectorAll('[data-faq-more]').forEach(function (button) {
        button.addEventListener('click', function () {
            button.closest('.faq').querySelectorAll('[data-faq-extra]').forEach(function (item) {
                item.hidden = false;
            });
            button.remove();
        });
    });

    document.querySelectorAll('[data-collapsible]').forEach(function (content) {
        const toggle = content.parentElement.querySelector('.seo-text__toggle');
        if (!toggle) {
            return;
        }

        content.classList.add('is-collapsed');
        if (content.scrollHeight <= content.clientHeight + 8) {
            content.classList.remove('is-collapsed');
            return;
        }

        toggle.hidden = false;
        toggle.addEventListener('click', function () {
            const expanded = toggle.getAttribute('aria-expanded') === 'true';
            toggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
            content.classList.toggle('is-collapsed', expanded);
            toggle.querySelector('[data-label-more]').hidden = !expanded;
            toggle.querySelector('[data-label-less]').hidden = expanded;
        });
    });
});
