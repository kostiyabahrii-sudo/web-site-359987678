document.addEventListener('DOMContentLoaded', function () {
    const toggle = document.querySelector('.person-hero__toggle');
    if (toggle) {
        const bio = document.getElementById(toggle.getAttribute('aria-controls'));
        toggle.addEventListener('click', function () {
            const open = toggle.getAttribute('aria-expanded') !== 'true';
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            bio.hidden = !open;
        });
    }

    document.querySelectorAll('[data-more-btn]').forEach(function (button) {
        button.addEventListener('click', function () {
            const section = button.closest('section');
            section.classList.add('is-expanded');
            section.querySelectorAll('[data-more-item]').forEach(function (item) {
                item.hidden = false;
            });
            button.parentElement.remove();
        });
    });
});
