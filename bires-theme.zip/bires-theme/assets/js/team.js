document.addEventListener('DOMContentLoaded', function () {
    const toggle = document.querySelector('.person-hero__toggle');
    if (toggle) {
        const bio = document.getElementById(toggle.getAttribute('aria-controls'));
        toggle.addEventListener('click', function () {
            const open = toggle.getAttribute('aria-expanded') !== 'true';
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            bio.hidden = !open;
        });
    }

    // Картка юриста: курсор на плашці з ім'ям — плашка біла, через секунду картка розгортається (біографія)
    if (window.matchMedia('(hover: hover) and (min-width: 1101px)').matches) {
        document.querySelectorAll('.person-card').forEach(function (card) {
            const details = card.querySelector('.person-card__details');
            const panel = card.querySelector('.person-card__panel');
            if (!details) {
                return;
            }
            let timer = 0;

            function measure() {
                card.style.setProperty('--person-details-h', details.offsetHeight + 'px');
            }

            function close() {
                clearTimeout(timer);
                card.classList.remove('is-lit', 'is-open');
                if (panel) {
                    panel.querySelector('.person-card__bio').scrollTop = 0;
                }
            }

            // Посилання на ім'я накриває всю картку, тож «над плашкою» визначаємо за висотою курсора
            card.addEventListener('pointermove', function (event) {
                if (event.pointerType !== 'mouse' || card.classList.contains('is-open')) {
                    return;
                }
                const onDetails = event.clientY >= details.getBoundingClientRect().top;
                if (onDetails && !card.classList.contains('is-lit')) {
                    measure();
                    card.classList.add('is-lit');
                    if (panel) {
                        timer = setTimeout(function () {
                            card.classList.add('is-open');
                        }, 1000);
                    }
                } else if (!onDetails && card.classList.contains('is-lit')) {
                    close();
                }
            });
            card.addEventListener('pointerleave', close);
        });
    }

    document.querySelectorAll('[data-more-btn]').forEach(function (button) {
        button.addEventListener('click', function () {
            const section = button.closest('section');
            section.classList.add('is-expanded');
            section.querySelectorAll('[data-more-item]').forEach(function (item) {
                item.hidden = false;
            });
            button.parentElement.remove();
        });
    });
});
