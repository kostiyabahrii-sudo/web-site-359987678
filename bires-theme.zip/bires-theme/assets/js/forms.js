/**
 * Випадні списки форм (data-dd): «Хто звертається?», «Галузь права», код країни телефону.
 * Нативний <select> лишається у формі й отримує значення; без JS працює він сам.
 */
document.addEventListener('DOMContentLoaded', function () {
    const canHover = window.matchMedia('(hover: hover)');
    const all = [];

    document.querySelectorAll('[data-dd]').forEach(function (dd) {
        const select = dd.querySelector('.dd__native');
        const button = dd.querySelector('.dd__button');
        const panel = dd.querySelector('.dd__panel');
        const list = dd.querySelector('.dd__list');
        const search = dd.querySelector('.dd__search');
        const empty = dd.querySelector('.dd__empty');
        const groups = Array.from(dd.querySelectorAll('.dd__group'));
        const options = Array.from(dd.querySelectorAll('.dd__option'));
        const isPhone = dd.classList.contains('dd--phone');
        const tel = isPhone ? dd.closest('.contact-form__field--phone, .cf-page__phone')?.querySelector('input[type="tel"]') : null;
        const label = select.id ? document.querySelector('label[for="' + select.id + '"]') : null;
        let active = -1;
        let typed = '';
        let typedTimer = 0;

        if (!select || !button || !panel || !list) {
            return;
        }
        dd.classList.add('is-enhanced');
        select.tabIndex = -1;
        select.setAttribute('aria-hidden', 'true');
        if (label) {
            label.htmlFor = button.id;
            label.id = label.id || select.id + '-label';
            list.setAttribute('aria-labelledby', label.id);
        }
        if (tel) {
            tel.dataset.ph = tel.placeholder;
        }

        function visible() {
            return options.filter(function (o) { return !o.hidden; });
        }

        function render() {
            const current = options.find(function (o) { return o.dataset.value === select.value; });
            options.forEach(function (o) { o.setAttribute('aria-selected', o === current ? 'true' : 'false'); });
            const value = button.querySelector('.dd__value');
            if (isPhone && current) {
                button.querySelector('.dd__flag').innerHTML = current.querySelector('.dd__flag').innerHTML;
                value.textContent = current.dataset.dial === '+' ? '+…' : current.dataset.dial;
                button.setAttribute('aria-label', (label ? label.textContent.trim() + ': ' : '') + current.querySelector('.dd__name').textContent.trim() + ' ' + current.dataset.dial);
                if (tel) {
                    tel.placeholder = current.dataset.value === 'other' ? tel.dataset.phOther : tel.dataset.ph;
                    tel.autocomplete = current.dataset.value === 'ua' ? 'tel-national' : 'tel';
                }
            } else {
                value.textContent = current ? current.querySelector('.dd__name').textContent.trim() : (dd.dataset.placeholder || '');
                dd.classList.toggle('is-placeholder', !current);
            }
        }

        function setActive(index, scroll) {
            const vis = visible();
            options.forEach(function (o) { o.classList.remove('is-active'); });
            if (!vis.length) {
                active = -1;
                (search || list).removeAttribute('aria-activedescendant');
                return;
            }
            active = Math.max(0, Math.min(vis.length - 1, index));
            vis[active].classList.add('is-active');
            (search || list).setAttribute('aria-activedescendant', vis[active].id);
            if (scroll !== false) {
                vis[active].scrollIntoView({ block: 'nearest' });
            }
        }

        function filter(query) {
            const q = query.trim().toLowerCase().replace(/^\+/, '');
            options.forEach(function (o) { o.hidden = q !== '' && o.dataset.search.indexOf(q) === -1; });
            if (empty) {
                empty.hidden = visible().length > 0;
            }
            setActive(0);
        }

        function open() {
            if (!panel.hidden) {
                return;
            }
            all.forEach(function (other) { if (other !== api) { other.close(false); } });
            panel.hidden = false;
            dd.classList.add('is-open');
            button.setAttribute('aria-expanded', 'true');
            // Відкриваємо вгору, якщо знизу не вистачає місця
            dd.classList.remove('dd--up');
            const rect = panel.getBoundingClientRect();
            const anchor = button.getBoundingClientRect();
            if (rect.bottom > window.innerHeight - 8 && anchor.top - rect.height - 16 > 0) {
                dd.classList.add('dd--up');
            }
            if (search) {
                search.value = '';
                filter('');
            }
            const selected = visible().findIndex(function (o) { return o.getAttribute('aria-selected') === 'true'; });
            setActive(selected < 0 ? 0 : selected);
            (search && canHover.matches ? search : list).focus({ preventScroll: true });
        }

        function close(focusButton) {
            if (panel.hidden) {
                return;
            }
            panel.hidden = true;
            dd.classList.remove('is-open');
            button.setAttribute('aria-expanded', 'false');
            if (focusButton) {
                button.focus();
            }
        }

        function choose(option) {
            if (option.dataset.value !== select.value) {
                select.value = option.dataset.value;
                select.dispatchEvent(new Event('change', { bubbles: true }));
            }
            render();
            close(true);
            if (tel && canHover.matches) {
                tel.focus();
            }
        }

        function onKey(event) {
            const vis = visible();
            switch (event.key) {
                case 'ArrowDown':
                    event.preventDefault();
                    setActive(active + 1);
                    break;
                case 'ArrowUp':
                    event.preventDefault();
                    setActive(active - 1);
                    break;
                case 'Home':
                case 'End':
                    if (event.target === list) {
                        event.preventDefault();
                        setActive(event.key === 'Home' ? 0 : vis.length - 1);
                    }
                    break;
                case 'Enter':
                    event.preventDefault();
                    if (vis[active]) {
                        choose(vis[active]);
                    }
                    break;
                case ' ':
                    if (event.target === list) {
                        event.preventDefault();
                        if (vis[active]) {
                            choose(vis[active]);
                        }
                    }
                    break;
                case 'Escape':
                    event.preventDefault();
                    close(true);
                    break;
                case 'Tab':
                    close(false);
                    break;
                default:
                    // Швидкий перехід за першими літерами
                    if (event.target === list && event.key.length === 1 && !event.ctrlKey && !event.metaKey) {
                        clearTimeout(typedTimer);
                        typed += event.key.toLowerCase();
                        typedTimer = setTimeout(function () { typed = ''; }, 600);
                        const hit = vis.findIndex(function (o) { return o.textContent.trim().toLowerCase().indexOf(typed) === 0; });
                        if (hit > -1) {
                            setActive(hit);
                        }
                    }
            }
        }

        button.addEventListener('click', function () {
            if (panel.hidden) {
                open();
            } else {
                close(false);
            }
        });
        button.addEventListener('keydown', function (event) {
            if (['ArrowDown', 'ArrowUp', 'Enter', ' '].indexOf(event.key) > -1) {
                event.preventDefault();
                open();
            }
        });
        list.addEventListener('keydown', onKey);
        if (search) {
            search.addEventListener('keydown', onKey);
            search.addEventListener('input', function () { filter(search.value); });
        }
        options.forEach(function (option) {
            option.addEventListener('click', function () { choose(option); });
            option.addEventListener('mousemove', function () {
                const index = visible().indexOf(option);
                if (index !== active) {
                    setActive(index, false);
                }
            });
        });
        document.addEventListener('pointerdown', function (event) {
            if (!dd.contains(event.target)) {
                close(false);
            }
        });
        select.addEventListener('change', render);
        select.form?.addEventListener('reset', function () { setTimeout(render, 0); });

        const api = { close: close };
        all.push(api);
        render();
        groups.forEach(function (g) { g.setAttribute('aria-hidden', 'true'); });
    });
});
