document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('.services-filter__btn');
    const tiles = document.querySelectorAll('[data-services-grid] .service-tile');

    // Посилання з мегаменю на групу послуг: /poslugy/#назва-групи — одразу відкриває потрібний фільтр
    function fromHash() {
        let wanted = '';
        try {
            wanted = decodeURIComponent(location.hash.slice(1)).toLowerCase();
        } catch (e) {
            return;
        }
        buttons.forEach(function (button) {
            let filter = '';
            try {
                filter = decodeURIComponent(button.dataset.filter).toLowerCase();
            } catch (e) {
                filter = button.dataset.filter;
            }
            if (wanted && filter === wanted) {
                button.click();
                button.closest('.services-list').scrollIntoView();
            }
        });
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            const filter = button.dataset.filter;

            buttons.forEach(function (btn) {
                const active = btn === button;
                btn.classList.toggle('is-active', active);
                btn.setAttribute('aria-pressed', active ? 'true' : 'false');
            });

            tiles.forEach(function (tile) {
                const cats = tile.dataset.cats.split(' ');
                tile.classList.toggle('is-hidden', filter !== 'all' && !cats.includes(filter));
            });
        });
    });

    // «Розгорнути всі» / «Згорнути» у плитках з довгим списком — для кожної плитки окремо
    document.addEventListener('click', function (event) {
        const button = event.target.closest('.service-tile__more');
        if (!button) {
            return;
        }
        const tile = button.closest('.service-tile');
        const expanded = !tile.classList.contains('is-expanded');
        tile.classList.toggle('is-expanded', expanded);
        button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        button.textContent = expanded ? button.dataset.less : button.dataset.more;
    });

    fromHash();
    window.addEventListener('hashchange', fromHash);
});
