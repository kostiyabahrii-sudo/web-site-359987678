document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('.services-filter__btn');
    const tiles = document.querySelectorAll('[data-services-grid] .service-tile');

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            const filter = button.dataset.filter;

            buttons.forEach(function (btn) {
                const active = btn === button;
                btn.classList.toggle('is-active', active);
                btn.setAttribute('aria-pressed', active ? 'true' : 'false');
            });

            tiles.forEach(function (tile) {
                const cats = tile.dataset.cats.split(' ');
                tile.classList.toggle('is-hidden', filter !== 'all' && !cats.includes(filter));
            });
        });
    });
});
