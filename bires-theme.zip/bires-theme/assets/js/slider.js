document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-slider-controls]').forEach(function (controls) {
        const track = document.getElementById(controls.dataset.sliderControls);
        if (!track) {
            return;
        }
        const buttons = controls.querySelectorAll('.slider-arrow');

        function update() {
            const max = track.scrollWidth - track.clientWidth - 2;
            buttons[0].disabled = track.scrollLeft <= 2;
            buttons[1].disabled = track.scrollLeft >= max;
            controls.hidden = max <= 0;
        }

        buttons.forEach(function (button) {
            button.addEventListener('click', function () {
                const card = track.firstElementChild;
                const step = card ? card.getBoundingClientRect().width + 20 : track.clientWidth;
                track.scrollBy({ left: step * Number(button.dataset.dir), behavior: 'smooth' });
            });
        });

        track.addEventListener('scroll', update, { passive: true });
        window.addEventListener('resize', update);
        update();
    });

    document.querySelectorAll('[data-dots-for]').forEach(function (dots) {
        const track = document.getElementById(dots.dataset.dotsFor);
        if (!track) {
            return;
        }

        function pages() {
            return Math.max(1, Math.ceil((track.scrollWidth - 2) / track.clientWidth));
        }

        function render() {
            const count = pages();
            dots.hidden = count < 2;
            if (dots.children.length !== count) {
                dots.innerHTML = '';
                for (let i = 0; i < count; i++) {
                    const button = document.createElement('button');
                    button.type = 'button';
                    button.setAttribute('aria-label', String(i + 1) + ' / ' + count);
                    button.addEventListener('click', function () {
                        const max = track.scrollWidth - track.clientWidth;
                        track.scrollTo({ left: count > 1 ? max * i / (count - 1) : 0, behavior: 'smooth' });
                    });
                    dots.appendChild(button);
                }
            }
            const max = track.scrollWidth - track.clientWidth;
            const active = max > 0 ? Math.round(track.scrollLeft / max * (count - 1)) : 0;
            Array.prototype.forEach.call(dots.children, function (button, i) {
                button.setAttribute('aria-current', i === active ? 'true' : 'false');
            });
        }

        track.addEventListener('scroll', render, { passive: true });
        window.addEventListener('resize', render);
        render();
    });
});
