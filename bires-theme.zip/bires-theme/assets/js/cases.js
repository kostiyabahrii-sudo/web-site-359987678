document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.case-card[aria-controls]').forEach(function (card) {
        const drawer = document.getElementById(card.getAttribute('aria-controls'));
        if (!drawer || typeof drawer.showModal !== 'function') {
            return;
        }
        card.addEventListener('click', function () {
            drawer.showModal();
            drawer.scrollTop = 0;
            document.body.classList.add('has-drawer');
        });
    });

    document.querySelectorAll('.case-drawer').forEach(function (drawer) {
        const links = drawer.querySelectorAll('.case-drawer__nav a');

        drawer.addEventListener('close', function () {
            document.body.classList.remove('has-drawer');
        });
        drawer.addEventListener('click', function (event) {
            if (event.target === drawer || event.target.closest('[data-case-close]')) {
                drawer.close();
            }
        });

        links.forEach(function (link) {
            link.addEventListener('click', function (event) {
                event.preventDefault();
                const target = drawer.querySelector(link.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });

        drawer.addEventListener('scroll', function () {
            const navBottom = drawer.querySelector('.case-drawer__nav').getBoundingClientRect().bottom;
            let current = links[0];
            links.forEach(function (link) {
                const section = drawer.querySelector(link.getAttribute('href'));
                if (section && section.getBoundingClientRect().top <= navBottom + 40) {
                    current = link;
                }
            });
            if (drawer.scrollTop + drawer.clientHeight >= drawer.scrollHeight - 2) {
                current = links[links.length - 1];
            }
            links.forEach(function (link) {
                link.classList.toggle('is-active', link === current);
            });
        }, { passive: true });
    });
});
