document.addEventListener('DOMContentLoaded', function () {
    const toc = document.querySelector('[data-toc]');
    if (toc && window.matchMedia('(max-width: 767px)').matches) {
        toc.open = false;
    }

    const links = Array.from(document.querySelectorAll('.article-toc a'));
    const headings = links
        .map(function (link) { return document.getElementById(link.getAttribute('href').slice(1)); })
        .filter(Boolean);

    if (headings.length && 'IntersectionObserver' in window) {
        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) {
                    return;
                }
                links.forEach(function (link) {
                    const active = link.getAttribute('href') === '#' + entry.target.id;
                    link.classList.toggle('is-active', active);
                    if (active) {
                        link.setAttribute('aria-current', 'location');
                    } else {
                        link.removeAttribute('aria-current');
                    }
                });
            });
        }, { rootMargin: '0px 0px -70% 0px' });
        headings.forEach(function (heading) { observer.observe(heading); });
        links[0].classList.add('is-active');
    }

    document.querySelectorAll('[data-more-btn]').forEach(function (button) {
        button.addEventListener('click', function () {
            const section = button.closest('section');
            section.classList.add('is-expanded');
            section.querySelectorAll('[data-more-item]').forEach(function (item) {
                item.hidden = false;
            });
            button.parentElement.remove();
        });
    });
});
