document.addEventListener('DOMContentLoaded', function () {
    const links = Array.from(document.querySelectorAll('.subnav__link'));
    const sections = links
        .map(function (link) { return document.querySelector(link.getAttribute('href')); })
        .filter(Boolean);

    if (sections.length && 'IntersectionObserver' in window) {
        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) {
                    return;
                }
                links.forEach(function (link) {
                    const active = link.getAttribute('href') === '#' + entry.target.id;
                    link.classList.toggle('is-active', active);
                    if (active) {
                        link.setAttribute('aria-current', 'location');
                        link.scrollIntoView({ block: 'nearest', inline: 'nearest' });
                    } else {
                        link.removeAttribute('aria-current');
                    }
                });
            });
        }, { rootMargin: '-45% 0px -50% 0px' });
        sections.forEach(function (section) { observer.observe(section); });
    }


    /* Етапи співпраці: поточний етап (той, що минув середину екрана) світиться, від нього до наступного — лінія */
    document.querySelectorAll('[data-steps]').forEach(function (list) {
        const steps = Array.from(list.children);
        let queued = false;

        function update() {
            queued = false;
            const line = window.innerHeight * 0.55;
            let active = 0;
            steps.forEach(function (step, i) {
                if (step.getBoundingClientRect().top <= line) {
                    active = i;
                }
            });
            steps.forEach(function (step, i) {
                step.classList.toggle('is-active', i === active);
            });
        }

        window.addEventListener('scroll', function () {
            if (!queued) {
                queued = true;
                window.requestAnimationFrame(update);
            }
        }, { passive: true });
        window.addEventListener('resize', update);
        update();
    });
});
