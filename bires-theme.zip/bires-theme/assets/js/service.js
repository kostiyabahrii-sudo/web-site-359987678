document.addEventListener('DOMContentLoaded', function () {
    // Довгий текст: кнопка «Читати далі» лише там, де текст справді не вміщується
    // (лише блоки .sp-more: атрибут data-more мають і кнопки «Розгорнути всі» в мегаменю)
    document.querySelectorAll('.sp-more[data-more]').forEach(function (box) {
        const text = box.querySelector('.sp-more__text');
        const toggle = box.querySelector('.sp-more__toggle');
        if (!text || !toggle) {
            return;
        }
        const more = toggle.textContent;
        function measure() {
            if (box.classList.contains('is-open')) {
                return;
            }
            box.classList.remove('is-fit');
            const fits = text.scrollHeight <= text.clientHeight + 4;
            box.classList.toggle('is-fit', fits);
            toggle.hidden = fits;
        }
        toggle.addEventListener('click', function () {
            const open = box.classList.toggle('is-open');
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            toggle.textContent = open ? toggle.dataset.less : more;
        });
        measure();
        window.addEventListener('resize', measure);
        if (document.fonts) {
            document.fonts.ready.then(measure);
        }
    });

    const links = Array.from(document.querySelectorAll('.subnav__link'));
    const sections = links
        .map(function (link) { return document.querySelector(link.getAttribute('href')); })
        .filter(Boolean);

    if (sections.length && 'IntersectionObserver' in window) {
        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) {
                    return;
                }
                links.forEach(function (link) {
                    const active = link.getAttribute('href') === '#' + entry.target.id;
                    link.classList.toggle('is-active', active);
                    if (active) {
                        link.setAttribute('aria-current', 'location');
                        link.scrollIntoView({ block: 'nearest', inline: 'nearest' });
                    } else {
                        link.removeAttribute('aria-current');
                    }
                });
            });
        }, { rootMargin: '-45% 0px -50% 0px' });
        sections.forEach(function (section) { observer.observe(section); });
    }

    // Етапи співпраці: підсвічуємо етап, що ближче до центру екрана.
    const steps = Array.from(document.querySelectorAll('.sp-step'));
    if (steps.length) {
        const setActive = function (step) {
            steps.forEach(function (item) { item.classList.toggle('is-active', item === step); });
        };
        setActive(steps[0]);
        if ('IntersectionObserver' in window) {
            const stepObserver = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        setActive(entry.target);
                    }
                });
            }, { rootMargin: '-40% 0px -45% 0px' });
            steps.forEach(function (step) { stepObserver.observe(step); });
        }
    }
});
