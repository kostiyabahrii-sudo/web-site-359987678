document.addEventListener('DOMContentLoaded', function () {
    const header = document.querySelector('.site-header');
    const overlay = document.querySelector('.site-overlay');
    const nav = document.getElementById('site-nav');
    const burger = document.querySelector('.mobile-menu-toggle');
    const desktop = window.matchMedia('(min-width: 1101px)');
    const hoverCapable = window.matchMedia('(hover: hover)');

    // Адмін-панель WordPress (видно лише адміністратору): на телефонах до 600px вона
    // прокручується разом зі сторінкою, тож відступ шапки рахуємо за її фактичним низом.
    const adminBar = document.getElementById('wpadminbar');
    function syncAdminBar() {
        if (adminBar) {
            const bottom = Math.max(0, Math.round(adminBar.getBoundingClientRect().bottom));
            document.documentElement.style.setProperty('--admin-bar', bottom + 'px');
        }
    }

    // «Розумна» шапка: ховається при прокрутці вниз і повертається, щойно гортаємо вгору.
    // Біля верху сторінки та з відкритим меню вона видима завжди.
    const root = document.documentElement;
    let lastY = window.scrollY;
    function setHeaderHidden(hidden) {
        root.classList.toggle('header-hidden', hidden);
    }

    function onScroll() {
        const y = window.scrollY;
        header.classList.toggle('scrolled', y > 50);
        syncAdminBar();
        const busy = header.classList.contains('is-menu-open') || header.classList.contains('is-mega-open');
        if (y < 100 || busy) {
            setHeaderHidden(false);
            lastY = y;
            return;
        }
        if (Math.abs(y - lastY) < 8) {
            return;
        }
        setHeaderHidden(y > lastY);
        lastY = y;
    }
    onScroll();
    // Перехід клавіатурою (Tab) до пункту меню — шапка має бути видна.
    header.addEventListener('focusin', function () {
        setHeaderHidden(false);
    });
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', syncAdminBar);

    // Картки мегаменю мають різну висоту (за вмістом): розкладаємо їх у колонки — кожну наступну в найнижчу,
    // щоб коротка картка не лишала порожнечі. До чотирьох колонок (на телефоні — одна, список).
    function layoutCards(panel) {
        const box = panel && panel.querySelector('.mega__cards');
        if (!box || panel.hidden || !box.clientWidth) {
            return;
        }
        const width = box.clientWidth;
        const total = box.querySelectorAll('.mega-card').length;
        // Колонок не більше, ніж карток. «Для бізнесу» — до чотирьох колонок на всю ширину (від 260 px);
        // «Для фізичних осіб» — стільки колонок сталої ширини 420 px, скільки вміщається
        const personal = panel.classList.contains('mega__panel--personal');
        const fit = Math.floor((width + 16) / ((personal ? 420 : 260) + 16));
        const count = desktop.matches ? Math.max(1, Math.min(total, personal ? fit : Math.min(4, Math.max(2, fit)))) : 1;
        if (box.dataset.cols === String(count) && box.dataset.width === String(width)) {
            return;
        }
        box.dataset.cols = count;
        box.dataset.width = width;
        const cards = Array.prototype.slice.call(box.querySelectorAll('.mega-card'));
        cards.sort(function (a, b) {
            return a.dataset.order - b.dataset.order;
        });
        const cols = [];
        box.textContent = '';
        for (let i = 0; i < count; i++) {
            cols.push(box.appendChild(document.createElement('ul')));
            cols[i].className = 'mega__col';
        }
        cards.forEach(function (card) {
            let lowest = cols[0];
            cols.forEach(function (col) {
                if (col.offsetHeight < lowest.offsetHeight) {
                    lowest = col;
                }
            });
            lowest.appendChild(card);
        });
    }

    document.querySelectorAll('.mega__cards').forEach(function (box) {
        box.querySelectorAll('.mega-card').forEach(function (card, index) {
            card.dataset.order = index;
        });
    });

    function layoutOpenMega() {
        document.querySelectorAll('.has-mega.is-open .mega__panel').forEach(layoutCards);
    }

    // Висота панелі мегаменю — до низу екрана: рахуємо, де вона починається (під шапкою й адмін-панеллю)
    function syncMegaTop() {
        const mega = document.querySelector('.has-mega.is-open .mega');
        if (mega && desktop.matches) {
            mega.style.setProperty('--mega-top', Math.max(0, Math.round(mega.getBoundingClientRect().top)) + 'px');
        }
    }
    header.addEventListener('transitionend', syncMegaTop);
    window.addEventListener('resize', syncMegaTop);

    function setMega(item, open) {
        const toggle = item.querySelector('.site-nav__toggle');
        item.classList.toggle('is-open', open);
        toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (!open) {
            // Закрите меню при наступному відкритті знову компактне
            collapseCards(item);
        }
        if (open) {
            item.querySelectorAll('.mega__panel').forEach(layoutCards);
        }
        const anyOpen = !!document.querySelector('.has-mega.is-open');
        header.classList.toggle('is-mega-open', anyOpen);
        syncMegaTop();
        if (desktop.matches) {
            overlay.hidden = !anyOpen;
        }
    }

    // «Розгорнути всі» / «Згорнути» у картках мегаменю й плитках каталогу (незалежно для кожної).
    // Розгорнута картка росте за вмістом. У сітці каталогу (ряди однакової висоти) сусіди в ряду не розтягуються:
    // поки щось розгорнуто, решта плиток зберігає свою висоту.
    function lockCards(list) {
        Array.prototype.forEach.call(list.children, function (card) {
            if (card.offsetHeight) {
                card.dataset.h = card.offsetHeight;
                card.style.height = card.dataset.h + 'px';
                card.style.alignSelf = 'start';
            }
        });
    }

    function unlockCards(list) {
        Array.prototype.forEach.call(list.children, function (card) {
            card.style.height = '';
            card.style.minHeight = '';
            card.style.alignSelf = '';
            delete card.dataset.h;
        });
    }

    // Плавне розгортання: картка змінює висоту поступово, нові пункти списку проявляються
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    function animateCard(card, from, expanded) {
        const to = card.offsetHeight;
        if (reduceMotion.matches || !card.animate || from === to || !card.offsetParent) {
            return;
        }
        card.animate([{ height: from + 'px', overflow: 'hidden' }, { height: to + 'px', overflow: 'hidden' }], { duration: 320, easing: 'ease' });
        if (expanded) {
            card.querySelectorAll('.is-extra').forEach(function (item) {
                item.animate([{ opacity: 0, transform: 'translateY(-4px)' }, { opacity: 1, transform: 'none' }], { duration: 320, easing: 'ease' });
            });
        }
    }

    function setCardExpanded(card, expanded, instant) {
        const from = card.offsetHeight;
        const list = card.parentElement;
        const button = card.querySelector('.mega-card__more, .service-tile__more');
        if (expanded && list.classList.contains('services-grid') && !list.querySelector(':scope > .is-expanded')) {
            lockCards(list);
        }
        const height = card.dataset.h ? card.dataset.h + 'px' : '';
        card.classList.toggle('is-expanded', expanded);
        card.style.height = expanded ? '' : height;
        card.style.minHeight = expanded ? height : '';
        if (!list.querySelector(':scope > .is-expanded')) {
            unlockCards(list);
        }
        if (button) {
            button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
            button.textContent = expanded ? button.dataset.less : button.dataset.more;
        }
        if (!instant) {
            animateCard(card, from, expanded);
        }
    }

    // Згортання без анімації: закрите меню, інша ширина вікна, фільтр каталогу
    function collapseCards(root) {
        root.querySelectorAll('.mega-card.is-expanded, .service-tile.is-expanded').forEach(function (card) {
            setCardExpanded(card, false, true);
        });
    }
    window.biresCollapseCards = collapseCards;

    document.addEventListener('click', function (event) {
        const button = event.target.closest('.mega-card__more, .service-tile__more');
        if (button) {
            const card = button.closest('.mega-card, .service-tile');
            setCardExpanded(card, !card.classList.contains('is-expanded'));
        }
    });

    // Інша ширина вікна — інші ряди й колонки: розгорнуте згортаємо й розкладаємо картки заново
    let cardsWidth = window.innerWidth;
    let layoutTimer;
    window.addEventListener('resize', function () {
        if (window.innerWidth !== cardsWidth) {
            cardsWidth = window.innerWidth;
            collapseCards(document);
            clearTimeout(layoutTimer);
            layoutTimer = setTimeout(layoutOpenMega, 150);
        }
    });

    function closeAll(except) {
        document.querySelectorAll('.has-mega.is-open').forEach(function (item) {
            if (item !== except) {
                setMega(item, false);
            }
        });
    }

    document.querySelectorAll('.has-mega').forEach(function (item) {
        const toggle = item.querySelector('.site-nav__toggle');
        let closeTimer;

        toggle.addEventListener('click', function () {
            const open = !item.classList.contains('is-open');
            closeAll(item);
            setMega(item, open);
        });

        item.addEventListener('mouseenter', function () {
            if (!desktop.matches || !hoverCapable.matches) {
                return;
            }
            clearTimeout(closeTimer);
            closeAll(item);
            setMega(item, true);
        });

        item.addEventListener('mouseleave', function () {
            if (!desktop.matches || !hoverCapable.matches) {
                return;
            }
            closeTimer = setTimeout(function () {
                setMega(item, false);
            }, 200);
        });

        item.querySelectorAll('.mega__tab').forEach(function (tab, index, tabs) {
            tab.addEventListener('click', function () {
                tabs.forEach(function (other) {
                    const active = other === tab;
                    other.classList.toggle('is-active', active);
                    other.setAttribute('aria-selected', active ? 'true' : 'false');
                    document.getElementById(other.getAttribute('aria-controls')).hidden = !active;
                });
                layoutCards(document.getElementById(tab.getAttribute('aria-controls')));
            });
        });
    });

    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') {
            return;
        }
        const open = document.querySelector('.has-mega.is-open');
        if (open) {
            setMega(open, false);
            open.querySelector('.site-nav__toggle').focus();
        }
    });

    overlay.addEventListener('click', function () {
        closeAll();
    });

    if (burger && nav) {
        burger.addEventListener('click', function () {
            const open = burger.getAttribute('aria-expanded') !== 'true';
            burger.setAttribute('aria-expanded', open ? 'true' : 'false');
            nav.classList.toggle('is-open', open);
            header.classList.toggle('is-menu-open', open);
            document.body.style.overflow = open ? 'hidden' : '';
        });
    }

    desktop.addEventListener('change', function () {
        closeAll();
        overlay.hidden = true;
        if (burger && desktop.matches) {
            burger.setAttribute('aria-expanded', 'false');
            nav.classList.remove('is-open');
            header.classList.remove('is-menu-open');
            document.body.style.overflow = '';
        }
    });

    const lang = document.querySelector('.lang-switcher__toggle');
    if (lang) {
        const list = document.getElementById(lang.getAttribute('aria-controls'));
        lang.addEventListener('click', function () {
            const open = lang.getAttribute('aria-expanded') !== 'true';
            lang.setAttribute('aria-expanded', open ? 'true' : 'false');
            list.hidden = !open;
        });
        document.addEventListener('click', function (event) {
            if (!event.target.closest('.lang-switcher')) {
                lang.setAttribute('aria-expanded', 'false');
                list.hidden = true;
            }
        });
    }

    document.querySelectorAll('.footer-col__toggle').forEach(function (toggle) {
        const list = document.getElementById(toggle.getAttribute('aria-controls'));
        toggle.addEventListener('click', function () {
            const open = toggle.getAttribute('aria-expanded') !== 'true';
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            if (list) {
                list.classList.toggle('is-open', open);
            }
        });
    });
});
