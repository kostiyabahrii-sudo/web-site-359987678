document.addEventListener('DOMContentLoaded', function () {
    const header = document.querySelector('.site-header');
    const overlay = document.querySelector('.site-overlay');
    const nav = document.getElementById('site-nav');
    const burger = document.querySelector('.mobile-menu-toggle');
    const desktop = window.matchMedia('(min-width: 1101px)');
    const hoverCapable = window.matchMedia('(hover: hover)');

    // Адмін-панель WordPress (видно лише адміністратору): на телефонах до 600px вона
    // прокручується разом зі сторінкою, тож відступ шапки рахуємо за її фактичним низом.
    const adminBar = document.getElementById('wpadminbar');
    function syncAdminBar() {
        if (adminBar) {
            const bottom = Math.max(0, Math.round(adminBar.getBoundingClientRect().bottom));
            document.documentElement.style.setProperty('--admin-bar', bottom + 'px');
        }
    }

    // «Розумна» шапка: ховається при прокрутці вниз і повертається, щойно гортаємо вгору.
    // Біля верху сторінки та з відкритим меню вона видима завжди.
    const root = document.documentElement;
    let lastY = window.scrollY;
    function setHeaderHidden(hidden) {
        root.classList.toggle('header-hidden', hidden);
    }

    function onScroll() {
        const y = window.scrollY;
        header.classList.toggle('scrolled', y > 50);
        syncAdminBar();
        const busy = header.classList.contains('is-menu-open') || header.classList.contains('is-mega-open');
        if (y < 100 || busy) {
            setHeaderHidden(false);
            lastY = y;
            return;
        }
        if (Math.abs(y - lastY) < 8) {
            return;
        }
        setHeaderHidden(y > lastY);
        lastY = y;
    }
    onScroll();
    // Перехід клавіатурою (Tab) до пункту меню — шапка має бути видна.
    header.addEventListener('focusin', function () {
        setHeaderHidden(false);
    });
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', syncAdminBar);

    function setMega(item, open) {
        const toggle = item.querySelector('.site-nav__toggle');
        item.classList.toggle('is-open', open);
        toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (!open) {
            // Закрите меню при наступному відкритті знову компактне
            item.querySelectorAll('.mega-card.is-expanded').forEach(function (card) {
                setCardExpanded(card, false);
            });
        }
        const anyOpen = !!document.querySelector('.has-mega.is-open');
        header.classList.toggle('is-mega-open', anyOpen);
        if (desktop.matches) {
            overlay.hidden = !anyOpen;
        }
    }

    // Мегаменю: у картках із довгим списком — «Розгорнути всі» / «Згорнути» (незалежно для кожної картки)
    function setCardExpanded(card, expanded) {
        const button = card.querySelector('.mega-card__more');
        card.classList.toggle('is-expanded', expanded);
        if (button) {
            button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
            button.textContent = expanded ? button.dataset.less : button.dataset.more;
        }
    }

    document.addEventListener('click', function (event) {
        const button = event.target.closest('.mega-card__more');
        if (button) {
            const card = button.closest('.mega-card');
            setCardExpanded(card, !card.classList.contains('is-expanded'));
        }
    });

    function closeAll(except) {
        document.querySelectorAll('.has-mega.is-open').forEach(function (item) {
            if (item !== except) {
                setMega(item, false);
            }
        });
    }

    document.querySelectorAll('.has-mega').forEach(function (item) {
        const toggle = item.querySelector('.site-nav__toggle');
        let closeTimer;

        toggle.addEventListener('click', function () {
            const open = !item.classList.contains('is-open');
            closeAll(item);
            setMega(item, open);
        });

        item.addEventListener('mouseenter', function () {
            if (!desktop.matches || !hoverCapable.matches) {
                return;
            }
            clearTimeout(closeTimer);
            closeAll(item);
            setMega(item, true);
        });

        item.addEventListener('mouseleave', function () {
            if (!desktop.matches || !hoverCapable.matches) {
                return;
            }
            closeTimer = setTimeout(function () {
                setMega(item, false);
            }, 200);
        });

        item.querySelectorAll('.mega__tab').forEach(function (tab, index, tabs) {
            tab.addEventListener('click', function () {
                tabs.forEach(function (other) {
                    const active = other === tab;
                    other.classList.toggle('is-active', active);
                    other.setAttribute('aria-selected', active ? 'true' : 'false');
                    document.getElementById(other.getAttribute('aria-controls')).hidden = !active;
                });
            });
        });
    });

    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') {
            return;
        }
        const open = document.querySelector('.has-mega.is-open');
        if (open) {
            setMega(open, false);
            open.querySelector('.site-nav__toggle').focus();
        }
    });

    overlay.addEventListener('click', function () {
        closeAll();
    });

    if (burger && nav) {
        burger.addEventListener('click', function () {
            const open = burger.getAttribute('aria-expanded') !== 'true';
            burger.setAttribute('aria-expanded', open ? 'true' : 'false');
            nav.classList.toggle('is-open', open);
            header.classList.toggle('is-menu-open', open);
            document.body.style.overflow = open ? 'hidden' : '';
        });
    }

    desktop.addEventListener('change', function () {
        closeAll();
        overlay.hidden = true;
        if (burger && desktop.matches) {
            burger.setAttribute('aria-expanded', 'false');
            nav.classList.remove('is-open');
            header.classList.remove('is-menu-open');
            document.body.style.overflow = '';
        }
    });

    const lang = document.querySelector('.lang-switcher__toggle');
    if (lang) {
        const list = document.getElementById(lang.getAttribute('aria-controls'));
        lang.addEventListener('click', function () {
            const open = lang.getAttribute('aria-expanded') !== 'true';
            lang.setAttribute('aria-expanded', open ? 'true' : 'false');
            list.hidden = !open;
        });
        document.addEventListener('click', function (event) {
            if (!event.target.closest('.lang-switcher')) {
                lang.setAttribute('aria-expanded', 'false');
                list.hidden = true;
            }
        });
    }

    document.querySelectorAll('.footer-col__toggle').forEach(function (toggle) {
        const list = document.getElementById(toggle.getAttribute('aria-controls'));
        toggle.addEventListener('click', function () {
            const open = toggle.getAttribute('aria-expanded') !== 'true';
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            if (list) {
                list.classList.toggle('is-open', open);
            }
        });
    });
});
