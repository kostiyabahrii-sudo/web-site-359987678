<?php
/**
 * Демо-контент: «Інструменти → Демо-контент Bires».
 * Одним натисканням створює сторінки, послуги, команду, кейси, статті, меню та тексти з макета.
 * Фото та логотипи беруться з макета (assets/demo).
 */

add_action( 'admin_menu', function () {
    add_management_page( __( 'Демо-контент Bires', 'bires-theme' ), __( 'Демо-контент Bires', 'bires-theme' ), 'manage_options', 'bires-demo', 'bires_demo_screen' );
} );

function bires_demo_screen() {
    $done = false;
    $busy = false;
    if ( isset( $_POST['bires_demo'] ) && check_admin_referer( 'bires_demo' ) && current_user_can( 'manage_options' ) ) {
        @set_time_limit( 300 );
        if ( false === bires_demo_seed() ) {
            $busy = true;
        } else {
            update_option( 'bires_demo_seeded', current_time( 'mysql' ) );
            $done = true;
        }
    }
    $acf  = function_exists( 'update_field' );
    $last = get_option( 'bires_demo_seeded' );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Демо-контент Bires', 'bires-theme' ); ?></h1>
        <?php if ( $done ) : ?>
            <div class="notice notice-success"><p><?php esc_html_e( 'Готово! Відкрийте сайт.', 'bires-theme' ); ?> <a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank"><?php esc_html_e( 'Перейти на сайт', 'bires-theme' ); ?></a></p></div>
        <?php endif; ?>
        <?php if ( $busy ) : ?>
            <div class="notice notice-warning"><p><?php esc_html_e( 'Демо-контент уже заповнюється (кнопку натиснули двічі або в іншій вкладці). Зачекайте хвилину й відкрийте сайт — повторно натискати не потрібно.', 'bires-theme' ); ?></p></div>
        <?php endif; ?>
        <?php if ( ! $acf ) : ?>
            <div class="notice notice-error"><p><?php esc_html_e( 'Спочатку встановіть і активуйте ACF PRO або Secure Custom Fields.', 'bires-theme' ); ?></p></div>
        <?php endif; ?>
        <p><?php esc_html_e( 'Заповнює сайт текстами з макета: сторінки та їх шаблони, 15 послуг, команду, кейси, статті блогу, мега-меню і меню футера, налаштування сайту.', 'bires-theme' ); ?></p>
        <p><?php esc_html_e( 'Наявні сторінки з такими ж адресами використовуються повторно, нічого не дублюється. Меню «Головне», «Практики» і «Компанія» створюються заново. Фото та логотипи — з макета Figma.', 'bires-theme' ); ?></p>
        <?php if ( $last ) : ?>
            <p><em><?php echo esc_html( sprintf( __( 'Останній запуск: %s', 'bires-theme' ), $last ) ); ?></em></p>
        <?php endif; ?>
        <form method="post" onsubmit="var b=this.querySelector('button');if(b.disabled){return false;}b.disabled=true;b.textContent=b.getAttribute('data-busy');">
            <?php wp_nonce_field( 'bires_demo' ); ?>
            <input type="hidden" name="bires_demo" value="1">
            <p><button type="submit" class="button button-primary button-hero" data-busy="<?php esc_attr_e( 'Заповнюється… (до хвилини)', 'bires-theme' ); ?>" <?php disabled( ! $acf ); ?>><?php esc_html_e( 'Заповнити демо-контентом', 'bires-theme' ); ?></button></p>
        </form>
    </div>
    <?php
}

/* ---------- допоміжні ---------- */

function bires_demo_image( $name, $w, $h, $bg, $text = '', $fg = [ 20, 20, 20 ], $person = false ) {
    $existing = get_page_by_path( 'bires-demo-' . $name, OBJECT, 'attachment' );
    if ( $existing ) {
        return $existing->ID;
    }
    if ( ! function_exists( 'imagecreatetruecolor' ) ) {
        return 0;
    }
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $im = imagecreatetruecolor( $w, $h );
    imagefill( $im, 0, 0, imagecolorallocate( $im, $bg[0], $bg[1], $bg[2] ) );
    if ( $person ) {
        imagefilledellipse( $im, (int) ( $w / 2 ), (int) ( $h * 0.38 ), (int) ( $w * 0.42 ), (int) ( $h * 0.42 ), imagecolorallocate( $im, 205, 195, 185 ) );
        imagefilledellipse( $im, (int) ( $w / 2 ), $h, (int) ( $w * 0.9 ), (int) ( $h * 0.8 ), imagecolorallocate( $im, 40, 45, 55 ) );
    }
    if ( $text ) {
        $font = 5;
        $tw   = imagefontwidth( $font ) * strlen( $text );
        imagestring( $im, $font, (int) max( 4, ( $w - $tw ) / 2 ), (int) ( $h / 2 - 8 ), $text, imagecolorallocate( $im, $fg[0], $fg[1], $fg[2] ) );
    }
    $up   = wp_upload_dir();
    $file = trailingslashit( $up['path'] ) . 'bires-demo-' . $name . '.png';
    imagepng( $im, $file );
    imagedestroy( $im );
    $att = wp_insert_attachment( [ 'post_mime_type' => 'image/png', 'post_title' => 'bires-demo-' . $name, 'post_name' => 'bires-demo-' . $name, 'post_status' => 'inherit' ], $file );
    wp_update_attachment_metadata( $att, wp_generate_attachment_metadata( $att, $file ) );
    return $att;
}

/**
 * Фото з макета, що лежать у темі (assets/demo). Імпортуються в медіатеку один раз.
 */
function bires_demo_asset( $file ) {
    $slug     = 'bires-demo-photo-' . sanitize_title( pathinfo( $file, PATHINFO_FILENAME ) );
    $source   = get_template_directory() . '/assets/demo/' . $file;
    $existing = get_page_by_path( $slug, OBJECT, 'attachment' );
    if ( ! file_exists( $source ) ) {
        return $existing ? $existing->ID : 0;
    }
    $hash = md5_file( $source );
    if ( $existing ) {
        // Файл у темі оновився — перезавантажуємо його в медіатеку.
        if ( get_post_meta( $existing->ID, '_bires_demo_hash', true ) === $hash ) {
            return $existing->ID;
        }
        wp_delete_attachment( $existing->ID, true );
    }
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $up   = wp_upload_dir();
    $dest = trailingslashit( $up['path'] ) . $slug . '.' . pathinfo( $file, PATHINFO_EXTENSION );
    copy( $source, $dest );
    $type = wp_check_filetype( $dest );
    $att  = wp_insert_attachment( [ 'post_mime_type' => $type['type'], 'post_title' => $slug, 'post_name' => $slug, 'post_status' => 'inherit' ], $dest );
    wp_update_attachment_metadata( $att, wp_generate_attachment_metadata( $att, $dest ) );
    update_post_meta( $att, '_bires_demo_hash', $hash );
    return $att;
}

function bires_demo_page( $title, $slug, $args = [] ) {
    $path     = isset( $args['path'] ) ? $args['path'] : $slug;
    $existing = get_page_by_path( $path );
    if ( $existing ) {
        $id = $existing->ID;
        if ( ! empty( $args['content'] ) && '' === trim( $existing->post_content ) ) {
            wp_update_post( [ 'ID' => $id, 'post_content' => $args['content'] ] );
        }
    } else {
        $id = wp_insert_post( [
            'post_type'    => 'page',
            'post_status'  => 'publish',
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_parent'  => isset( $args['parent'] ) ? $args['parent'] : 0,
            'menu_order'   => isset( $args['order'] ) ? $args['order'] : 0,
            'post_content' => isset( $args['content'] ) ? $args['content'] : '',
        ] );
    }
    if ( ! empty( $args['template'] ) ) {
        update_post_meta( $id, '_wp_page_template', $args['template'] );
    }
    return $id;
}

function bires_demo_post( $type, $title, $slug, $args = [] ) {
    $existing = get_page_by_path( $slug, OBJECT, $type );
    if ( $existing ) {
        return $existing->ID;
    }
    return wp_insert_post( array_merge( [ 'post_type' => $type, 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug ], $args ) );
}

function bires_demo_thumb( $id, $att ) {
    if ( ! $att ) {
        return;
    }
    $current = get_post_thumbnail_id( $id );
    // Заглушки з попереднього запуску замінюються фото; власні фото користувача не чіпаємо.
    if ( ! $current || 0 === strpos( (string) get_post_field( 'post_name', $current ), 'bires-demo-' ) ) {
        set_post_thumbnail( $id, $att );
    }
}

function bires_demo_menu( $name, $location, $items ) {
    $obj = wp_get_nav_menu_object( $name );
    if ( $obj ) {
        wp_delete_nav_menu( $obj->term_id );
    }
    $menu_id = wp_create_nav_menu( $name );
    bires_demo_menu_items( $menu_id, $items, 0 );
    $locs              = get_theme_mod( 'nav_menu_locations', [] );
    $locs[ $location ] = $menu_id;
    set_theme_mod( 'nav_menu_locations', $locs );
}

function bires_demo_menu_items( $menu_id, $items, $parent ) {
    foreach ( $items as $item ) {
        $children = isset( $item['children'] ) ? $item['children'] : [];
        unset( $item['children'] );
        $item['menu-item-parent-id'] = $parent;
        $item['menu-item-status']    = 'publish';
        $id                          = wp_update_nav_menu_item( $menu_id, 0, $item );
        bires_demo_menu_items( $menu_id, $children, $id );
    }
}

/* ---------- наповнення ---------- */

/** Тексти «Політики конфіденційності» та «Умов використання» для демо (шаблон, який варто вичитати юристу). */
function bires_demo_legal_texts() {
    $privacy = <<<HTML
<p>Ця політика пояснює, які персональні дані збирає сайт Bires Law Firm (далі — «Bires», «ми»), навіщо вони потрібні, як ми їх захищаємо та які права ви маєте. Користуючись сайтом і надсилаючи форми, ви погоджуєтесь з цією політикою.</p>
<h2>Які дані ми збираємо</h2>
<ul>
<li><strong>Дані, які ви вводите у формах:</strong> ім’я та прізвище, номер телефону з кодом країни, електронна пошта, хто звертається (фізична чи юридична особа), галузь права.</li>
<li><strong>Технічні дані:</strong> IP-адреса, тип браузера та пристрою, сторінки, які ви відвідали, і файли cookie.</li>
</ul>
<h2>Навіщо ми обробляємо дані</h2>
<ul>
<li>щоб відповісти на ваше звернення та домовитися про консультацію;</li>
<li>щоб укласти й виконати договір про надання правової допомоги;</li>
<li>щоб підтримувати роботу сайту, захищати його від спаму та покращувати.</li>
</ul>
<h2>Правові підстави</h2>
<p>Ми обробляємо персональні дані відповідно до Закону України «Про захист персональних даних» на підставі вашої згоди, яку ви надаєте, надсилаючи форму, а також для укладення та виконання договору. Для відвідувачів з ЄС ми дотримуємося вимог Загального регламенту про захист даних (GDPR).</p>
<h2>Адвокатська таємниця</h2>
<p>Усе, що ви повідомляєте нам у зверненні, ми зберігаємо як адвокатську таємницю відповідно до Закону України «Про адвокатуру та адвокатську діяльність». Ми не розголошуємо ці відомості без вашої згоди, крім випадків, прямо передбачених законом.</p>
<h2>Кому ми передаємо дані</h2>
<p>Ми не продаємо і не передаємо ваші дані третім особам для реклами. Доступ до них мають лише юристи та співробітники Bires, які працюють з вашим зверненням, а також постачальники хостингу й електронної пошти в обсязі, потрібному для роботи сайту. Дані можуть бути надані державним органам лише у випадках, передбачених законом.</p>
<h2>Скільки ми зберігаємо дані</h2>
<p>Ми зберігаємо дані не довше, ніж це потрібно для мети, з якою їх отримали, або протягом строку, встановленого законом. Після цього дані видаляються або знеособлюються.</p>
<h2>Файли cookie</h2>
<p>Сайт використовує технічні cookie, без яких він не працює коректно, і може використовувати аналітичні cookie, щоб розуміти, як відвідувачі користуються сайтом. Ви можете вимкнути або видалити cookie в налаштуваннях браузера, але частина функцій сайту тоді може працювати некоректно.</p>
<h2>Ваші права</h2>
<p>Відповідно до статті 8 Закону України «Про захист персональних даних» ви маєте право:</p>
<ul>
<li>знати, які ваші дані ми обробляємо і з якою метою;</li>
<li>вимагати виправлення неточних або видалення ваших даних;</li>
<li>відкликати згоду на обробку даних;</li>
<li>подати скаргу Уповноваженому Верховної Ради України з прав людини або до суду.</li>
</ul>
<p>Щоб скористатися цими правами, напишіть нам — ми відповімо протягом 30 днів.</p>
<h2>Захист даних</h2>
<p>Сайт працює через захищене з’єднання (HTTPS), доступ до даних мають лише уповноважені особи, а резервні копії зберігаються в захищеному середовищі.</p>
<h2>Зміни політики</h2>
<p>Ми можемо оновлювати цю політику. Актуальна редакція завжди опублікована на цій сторінці, дата оновлення вказана вгорі.</p>
<h2>Контакти</h2>
<p>З питань обробки персональних даних пишіть на <a href="mailto:info@bires.com.ua">info@bires.com.ua</a> або телефонуйте: (+380) 44 334 75 04.</p>
HTML;

    $terms = <<<HTML
<p>Ці умови регулюють користування сайтом Bires Law Firm (далі — «Bires», «ми»). Відкриваючи сайт і користуючись ним, ви погоджуєтесь з цими умовами. Якщо ви з ними не згодні, будь ласка, не користуйтеся сайтом.</p>
<h2>Інформація на сайті</h2>
<p>Матеріали сайту, зокрема статті блогу, описи послуг і кейсів, мають загальний довідковий характер і не є юридичною консультацією. Кожна ситуація індивідуальна: щоб отримати пораду щодо вашої справи, зверніться до нас, і юрист проаналізує її особисто.</p>
<h2>Відносини адвоката і клієнта</h2>
<p>Звернення через форму, телефон чи пошту саме по собі не створює відносин адвоката і клієнта. Такі відносини виникають лише після укладення договору про надання правової допомоги. Водночас інформацію з вашого звернення ми зберігаємо конфіденційно.</p>
<h2>Інтелектуальна власність</h2>
<p>Тексти, логотип, дизайн, фото та інші матеріали сайту належать Bires або використовуються на законних підставах. Цитування дозволене з посиланням на сайт; інше копіювання чи використання — лише з нашої письмової згоди.</p>
<h2>Посилання на інші сайти</h2>
<p>Сайт може містити посилання на сторонні ресурси. Ми не відповідаємо за їхній зміст і політику конфіденційності.</p>
<h2>Обмеження відповідальності</h2>
<p>Ми стежимо за актуальністю інформації, але законодавство змінюється, тому не гарантуємо, що всі матеріали сайту повні й актуальні на момент читання. Bires не відповідає за рішення, ухвалені лише на підставі матеріалів сайту без звернення до юриста.</p>
<h2>Звернення через сайт</h2>
<p>Надсилаючи форму, ви підтверджуєте, що вказали достовірні дані і маєте право їх надати. Обробка цих даних описана в <a href="/privacy-policy/">Політиці конфіденційності</a>.</p>
<h2>Зміни умов і застосовне право</h2>
<p>Ми можемо оновлювати ці умови; актуальна редакція завжди опублікована на цій сторінці. До цих умов застосовується законодавство України.</p>
<h2>Контакти</h2>
<p>Питання щодо умов використання надсилайте на <a href="mailto:info@bires.com.ua">info@bires.com.ua</a>.</p>
HTML;

    return [ 'privacy' => $privacy, 'terms' => $terms ];
}

/**
 * Запуск наповнення з блокуванням: два одночасні запуски (подвійне натискання,
 * повторний запит браузера) дублювали пункти меню. Повертає false, якщо вже йде інший запуск.
 */
function bires_demo_seed() {
    global $wpdb;
    $now      = time();
    $acquired = (bool) $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES ('bires_demo_lock', %s, 'no')", $now ) );
    if ( ! $acquired ) {
        // Замок від запуску, що впав (понад 10 хв), перехоплюємо атомарно.
        $since = (int) $wpdb->get_var( "SELECT option_value FROM {$wpdb->options} WHERE option_name = 'bires_demo_lock'" );
        if ( $now - $since < 600 ) {
            return false;
        }
        $acquired = (bool) $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = 'bires_demo_lock' AND option_value = %s", $now, $since ) );
        if ( ! $acquired ) {
            return false;
        }
    }
    try {
        bires_demo_seed_run();
    } finally {
        $wpdb->delete( $wpdb->options, [ 'option_name' => 'bires_demo_lock' ] );
    }
    return true;
}

function bires_demo_seed_run() {
    if ( ! function_exists( 'update_field' ) ) {
        return;
    }
    require_once ABSPATH . 'wp-admin/includes/taxonomy.php';

    update_option( 'permalink_structure', '/%postname%/' );

    // Стандартні записи WordPress заважають демо: «Hello world!» потрапляє в блог.
    foreach ( [ [ 'hello-world', 'post' ], [ 'sample-page', 'page' ] ] as $default ) {
        $p = get_page_by_path( $default[0], OBJECT, $default[1] );
        if ( $p ) {
            wp_trash_post( $p->ID );
        }
    }

    /* Сторінки */
    $faq = [
        [ 'question' => 'Чи може бути підприємство учасником кримінального провадження?', 'answer' => 'Так. Юридична особа може бути залучена до кримінального провадження в різному статусі. Зокрема, юридична особа може бути залучена як потерпіла сторона, коли кримінальним правопорушенням їй завдано майнової шкоди.' ],
        [ 'question' => 'Які заходи кримінально-правового характеру можуть застосовуватися щодо юридичної особи?', 'answer' => 'Штраф, конфіскація майна, ліквідація.' ],
        [ 'question' => 'Яким чином підприємство може реалізовувати свої права у кримінальному провадженні, яке здійснюється щодо нього?', 'answer' => 'Через представника — адвоката.' ],
        [ 'question' => 'Чи може юридична особа зазнавати інших обмежувальних заходів, окрім заходів кримінально-правового характеру?', 'answer' => 'Так, зокрема арешт майна, тимчасовий доступ до документів та вилучення майна.' ],
        [ 'question' => 'Чим може допомогти адвокат юридичній особі у кримінальному провадженні?', 'answer' => 'Захист прав, участь в обшуках, оскарження дій слідства та арештів майна.' ],
        [ 'question' => 'Чи будуть якісь наслідки для керівника чи працівників підприємства, у разі застосування заходів кримінально-правового характеру до юридичної особи?', 'answer' => 'Застосування заходів до юридичної особи не звільняє від відповідальності посадових осіб, які вчинили правопорушення.' ],
        [ 'question' => 'Скільки коштує консультація?', 'answer' => 'Вартість визначається індивідуально після першої розмови.' ],
        [ 'question' => 'Як швидко адвокат може приїхати на обшук?', 'answer' => 'Наші адвокати чергують цілодобово та виїжджають на обшук у найкоротші строки.' ],
    ];

    $home     = bires_demo_page( 'Головна', 'golovna' );
    $services = bires_demo_page( 'Послуги', 'poslugy', [
        'template' => 'page-templates/services-listing.php',
        'content'  => '<h2>Юридичні послуги для бізнесу та приватних клієнтів</h2><p>Юридична фірма Bires надає повний спектр юридичних послуг для бізнесу та фізичних осіб. Ми супроводжуємо компанії на всіх етапах — від реєстрації до вирішення складних судових спорів.</p><h3>Чому варто звернутися до нас</h3><p>Понад 20 років практики, 14 напрямів, конфіденційність та прозорі умови співпраці.</p>',
    ] );
    $cases    = bires_demo_page( 'Кейси', 'keisy', [ 'template' => 'page-templates/cases.php' ] );
    $about    = bires_demo_page( 'Про нас', 'pro-nas', [
        'template' => 'page-templates/about.php',
        'content'  => '<h2>Юридична фірма з 2013 року</h2><p>Bires Law Firm — команда юристів та адвокатів, що супроводжує бізнес і приватних клієнтів в Україні та за кордоном.</p><p>Ми поєднуємо глибоку експертизу у корпоративному, податковому, кримінальному та міграційному праві з розумінням комерційних задач клієнтів.</p>',
    ] );
    $contacts = bires_demo_page( 'Контакти', 'kontakty', [ 'template' => 'page-templates/contact.php' ] );
    $blog     = get_option( 'page_for_posts' ) ? (int) get_option( 'page_for_posts' ) : bires_demo_page( 'Блог', 'blog' );
    $sitemap  = bires_demo_page( 'Мапа сайту', 'mapa-saitu', [ 'template' => 'page-templates/sitemap.php' ] );
    $legal    = bires_demo_legal_texts();
    $privacy  = bires_demo_page( 'Політика конфіденційності', 'privacy-policy', [ 'content' => $legal['privacy'] ] );
    $terms    = bires_demo_page( 'Умови використання', 'terms-of-use', [ 'content' => $legal['terms'] ] );
    wp_update_post( [ 'ID' => $privacy, 'post_status' => 'publish' ] );
    // Англійська заготовка WordPress («Suggested text») і старі заглушки демо замінюються українським текстом;
    // текст, який ви вже відредагували, не чіпаємо.
    foreach ( [ $privacy => [ $legal['privacy'], 'Privacy Policy', 'Політика конфіденційності' ], $terms => [ $legal['terms'], 'Terms of use', 'Умови використання' ] ] as $legal_id => $legal_page ) {
        $legal_post = get_post( $legal_id );
        $update     = [ 'ID' => $legal_id ];
        if ( preg_match( '/Suggested text|Пропонований текст|Текст буде додано/u', $legal_post->post_content ) ) {
            $update['post_content'] = $legal_page[0];
        }
        if ( $legal_page[1] === $legal_post->post_title ) {
            $update['post_title'] = $legal_page[2];
        }
        if ( count( $update ) > 1 ) {
            wp_update_post( $update );
        }
    }

    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $home );
    update_option( 'page_for_posts', $blog );

    update_field( 'hero_title', 'Сучасний підхід до юридичної практики', $services );
    update_field( 'hero_text', 'Представляємо інтереси бізнесу і фізичних осіб незалежно від складності ситуації.', $services );
    update_field( 'faq_text', 'Знайдіть швидкі відповіді на запитання, що стосуються юридичних послуг.', $services );
    update_field( 'faq', $faq, $services );

    /* Послуги */
    $cats = [ 'launch' => 'Запуск бізнесу', 'support' => 'Юридичний супровід', 'tax' => 'Податки та фінанси', 'litigation' => 'Судові та кримінальні справи', 'assets' => 'Активи та нерухомість' ];
    foreach ( $cats as $slug => $name ) {
        if ( ! term_exists( $slug, 'service_category' ) ) {
            wp_insert_term( $name, 'service_category', [ 'slug' => $slug ] );
        }
    }
    $list = [
        [ 'Корпоративне право та супровід бізнесу', 'korporatyvne-pravo', 'tie', 'business', [ 'launch', 'support' ], 'Комплексний юридичний супровід для юридичних осіб та ФОП на постійній основі.' ],
        [ 'Державні процедури та публічне право', 'derzhavni-protsedury', 'scroll', 'business', [ 'litigation' ], 'Представництво інтересів клієнта в суді, підготовка процесуальних документів та супровід судових спорів.' ],
        [ 'Фінансова та податкова практика', 'podatkova-praktyka', 'wallet', 'business', [ 'tax' ], 'Юридична підтримка у митних спорах: коригування митної вартості, оскарження рішень митних органів.' ],
        [ 'Бізнес-реєстрація та ліцензування', 'reiestratsiia-biznesu', 'document', 'business', [ 'launch' ], 'Реєстрація підприємств, ліцензії, дозволи та декларації.' ],
        [ 'Кримінальне право', 'kryminalne-pravo', 'scales', 'business', [ 'litigation' ], 'Захист власників і топменеджерів компаній від кримінального переслідування.' ],
        [ 'Банкрутство юридичних осіб', 'bankrutstvo', 'banknotes', 'business', [ 'tax', 'litigation' ], 'Супровід процедур банкрутства та реструктуризації боргів.' ],
        [ 'Будівництво та майно', 'budivnytstvo', 'building', 'business', [ 'assets' ], 'Супровід будівельних проєктів та операцій з нерухомістю.' ],
        [ 'Розробка договорів', 'rozrobka-dogovoriv', 'folder', 'business', [ 'support' ], 'Підготовка та аналіз договорів для бізнесу.' ],
        [ 'Кадри та охорона праці', 'kadry', 'briefcase', 'business', [ 'support' ], 'Трудові відносини, перевірки Держпраці, HR-документи.' ],
        [ 'Інтелектуальне право', 'intelektualne-pravo', 'bulb', 'business', [ 'assets' ], 'Захист торговельних марок, авторських прав та IT-продуктів.' ],
        [ 'Сімейне право', 'simeine-pravo', 'home', 'personal', [], 'Розлучення, аліменти, поділ майна.' ],
        [ 'Міграційне право', 'migratsiine-pravo', 'globe', 'personal', [], 'Посвідки на проживання, громадянство, візи.' ],
        [ 'Кримінальне право (фізособи)', 'kryminalne-pravo-fizosoby', 'scales', 'personal', [], 'Захист у кримінальних провадженнях на всіх стадіях.' ],
        [ 'Стягнення заборгованості', 'stiagnennia-zaborgovanosti', 'money-bag', 'personal', [], 'Досудове та судове стягнення боргів.' ],
        [ 'Будівництво та майно (фізособи)', 'budivnytstvo-fizosoby', 'building', 'personal', [], 'Супровід угод з нерухомістю для приватних клієнтів.' ],
    ];
    // Переноси рядків у назвах карток, як у макеті.
    $breaks = [
        'Будівництво та майно'  => "Будівництво\nта майно",
        'Інтелектуальне право' => "Інтелектуальне\nправо",
    ];
    $ids = [];
    foreach ( $list as $i => $row ) {
        list( $title, $slug, $icon, $aud, $terms, $short ) = $row;
        $id = bires_demo_page( $title, $slug, [ 'path' => 'poslugy/' . $slug, 'parent' => $services, 'order' => $i ] );
        update_field( 'service_icon', $icon, $id );
        update_field( 'service_audience', $aud, $id );
        update_field( 'service_short', $short, $id );
        update_field( 'hero_text', $short, $id );
        $card = trim( preg_replace( '/\(.*\)/', '', $title ) );
        if ( isset( $breaks[ $card ] ) ) {
            $card = $breaks[ $card ];
        }
        update_field( 'service_card_title', $card === $title ? '' : $card, $id );
        wp_set_object_terms( $id, $terms, 'service_category' );
        $ids[ $slug ] = $id;
    }

    $crim = $ids['kryminalne-pravo'];
    wp_update_post( [ 'ID' => $crim, 'post_content' => '<h2>Як показує практика, під час кримінального провадження інтереси підприємств зазнають найбільших обмежень в результаті застосування таких заходів:</h2><ul><li>тимчасовий доступ до речей і документів;</li><li>тимчасове вилучення майна;</li><li>арешт майна.</li></ul><p>Ми допомагаємо мінімізувати ці ризики на кожному етапі провадження.</p>' ] );
    update_field( 'hero_text', 'Захист власників і топменеджерів компаній від кримінального переслідування при веденні господарської діяльності.', $crim );
    update_field( 'intro_text', 'Представництво інтересів на всіх стадіях кримінального переслідування в правоохоронних органах, органах прокуратури, суді, апеляційне та касаційне оскарження судових рішень та скасування арешту на майно.', $crim );
    update_field( 'steps_text', 'Знайдіть швидкі відповіді на запитання, як наша команда адвокатів надає наступні послуги.', $crim );
    update_field( 'steps', [
        [ 'icon' => 'chat', 'title' => 'Надання юридичних консультацій', 'text' => 'аналіз матеріалів справи та підготовка стратегії захисту' ],
        [ 'icon' => 'shield', 'title' => 'Захист власника, директора та інших співробітників компанії', 'text' => 'прийняття участі в обшуці та оскарження його результатів' ],
        [ 'icon' => 'file', 'title' => 'Оскарження накладення арешту', 'text' => "на рахунки та грошові кошти, рухоме і нерухоме майно до слідчого судді\nповернення майна клієнта в кримінальному провадженні" ],
    ], $crim );
    update_field( 'results_text', '<p>Кожна справа супроводжується індивідуальним підходом, чіткою правовою стратегією та повною відповідальністю за результат.</p><p>Ми уважно аналізуємо контекст, ризики й цілі клієнта, щоб пропонувати зважені рішення.</p>', $crim );
    update_field( 'results_numbers', [
        [ 'number' => '3.800', 'label' => 'успішних справ на користь клієнтів' ],
        [ 'number' => '20', 'label' => 'Років практичного досвіду' ],
        [ 'number' => '99%', 'label' => 'задоволених клієнтів' ],
        [ 'number' => '1.500', 'label' => 'консультацій за рік' ],
    ], $crim );
    update_field( 'benefits_text', 'Структурований підхід до захисту прав та інтересів клієнта.', $crim );
    update_field( 'benefits', [
        [ 'icon' => 'graduation', 'title' => 'Професійність наших адвокатів', 'text' => '20 років досвіду у захисті клієнтів у кримінальних провадженнях' ],
        [ 'icon' => 'city', 'title' => 'Адвокати компанії', 'text' => 'спеціалізуються на захисті бізнесу у справах економічного та корупційного характеру' ],
        [ 'icon' => 'route', 'title' => 'Ефективна тактика захисту', 'text' => 'підозрюваних та обвинувачених на всіх етапах кримінального провадження' ],
        [ 'icon' => 'lock', 'title' => 'Представництво та захист прав', 'text' => 'у межах кримінального провадження в судах усіх інстанцій' ],
    ], $crim );
    update_field( 'faq_text', 'Знайдіть швидкі відповіді на запитання, що стосуються кримінального права.', $crim );
    update_field( 'faq', $faq, $crim );

    /* Команда */
    $quote  = 'Ми об’єднали юристів та адвокатів із різним досвідом, щоб комплексно вирішувати питання клієнтів. Кожну справу у нас ведуть юристи з багаторічною практикою і реальним досвідом роботи.';
    $people = [
        [ 'Ігор Багрій', 'ihor-bahrii', 'Керуючий партнер • Адвокат', 'managing_partner', $quote ],
        [ 'Миколай Веретяк', 'mykolai-veretiak', 'Юрист з корпоративного права', 'partner', $quote ],
        [ 'Надія Багрій', 'nadiia-bahrii', 'Адвокат', 'practice_head', '' ],
        [ 'Олег Коваленко', 'oleh-kovalenko', 'Юрист з податкового права', 'practice_head', '' ],
        [ 'Аліна Романова', 'alina-romanova', 'Юрист з міжнародного права', 'practice_head', '' ],
    ];
    $photos = [ 'ihor-bahrii' => 'team-ihor.jpg', 'mykolai-veretiak' => 'team-mykolai.jpg', 'nadiia-bahrii' => 'team-nadiia.jpg', 'oleh-kovalenko' => 'team-oleh.jpg', 'alina-romanova' => 'team-alina.jpg' ];
    // «Ірина Шевчук» з попередньої версії демо в макеті відсутня.
    $extra = get_page_by_path( 'iryna-shevchuk', OBJECT, 'team' );
    if ( $extra && 0 === strpos( (string) get_post_field( 'post_name', get_post_thumbnail_id( $extra->ID ) ), 'bires-demo-' ) ) {
        wp_trash_post( $extra->ID );
    }
    // Попередня версія демо створювала «Юлію Романову» — у макеті це Аліна Романова.
    $old = get_page_by_path( 'yuliia-romanova', OBJECT, 'team' );
    if ( $old && ! get_page_by_path( 'alina-romanova', OBJECT, 'team' ) ) {
        wp_update_post( [ 'ID' => $old->ID, 'post_title' => 'Аліна Романова', 'post_name' => 'alina-romanova' ] );
    }
    $svc  = array_map( 'strval', [ $ids['bankrutstvo'], $ids['kryminalne-pravo'], $ids['intelektualne-pravo'], $ids['podatkova-praktyka'], $ids['stiagnennia-zaborgovanosti'] ] );
    $team = [];
    foreach ( $people as $i => $row ) {
        list( $name, $slug, $pos, $group, $q ) = $row;
        $first = explode( ' ', $name )[0];
        $id    = bires_demo_post( 'team', $name, $slug, [
            'menu_order'   => $i,
            'post_content' => '<p>' . $first . ' – юрист з багаторічною практикою, спеціалізується на захисті бізнесу та приватних клієнтів. Представляє інтереси клієнтів у судах усіх інстанцій.</p><p>Також надає правову допомогу бізнесу (B2B), зокрема у сфері інформаційних технологій.</p>',
        ] );
        bires_demo_thumb( $id, bires_demo_asset( $photos[ $slug ] ) );
        update_field( 'team_position', $pos, $id );
        update_field( 'team_group', $group, $id );
        update_field( 'team_quote', $q, $id );
        update_field( 'team_lead', 'Спеціалізується на кримінальному праві та захисті бізнесу.', $id );
        update_field( 'team_socials', [ [ 'url' => 'https://www.linkedin.com/' ] ], $id );
        update_field( 'team_related_services', $svc, $id );
        update_field( 'team_education', [ [ 'title' => 'КНУ ім. Т. Шевченка, магістр права', 'years' => '1999–2004' ] ], $id );
        $team[ $slug ] = $id;
    }
    update_field( 'team_hero_title', 'Наша сила — у людях та їхній експертизі', 'option' );
    update_field( 'team_hero_image', bires_demo_asset( 'team-card.jpg' ), 'option' );
    update_field( 'team_card1_image', bires_demo_asset( 'team-hero.jpg' ), 'option' );
    update_field( 'team_card1_text', 'Юридичний супровід команд, найму та внутрішніх процесів IT компаній.', 'option' );
    update_field( 'team_intro_text', 'Настав час вирішити свої юридичні питання? Почніть зараз.', 'option' );

    /* Налаштування сайту */
    $opts = [
        'contact_email'     => 'info@bires.com.ua',
        'contact_phone_1'   => '(+380) 44 334 75 04',
        'contact_phone_2'   => '(+380) 96 106 20 56',
        'contact_address_1' => 'вул. Воздвиженська 14, офіс 9',
        'contact_address_2' => 'Київ, 04-071',
        'social_telegram'   => 'https://t.me/+380961062056',
        'social_instagram'  => 'https://instagram.com/',
        'social_facebook'   => 'https://facebook.com/',
        'contact_page'      => $contacts,
        'sitemap_page'      => $sitemap,
        'privacy_page'      => $privacy,
        'terms_page'        => $terms,
    ];
    $manager = (int) get_field( 'contact_manager', 'option' );
    if ( ! $manager || $manager === $team['alina-romanova'] || 'yuliia-romanova' === get_post_field( 'post_name', $manager ) ) {
        update_field( 'contact_manager', $team['alina-romanova'], 'option' );
    }
    // Менеджер у блоках контактів — як у макеті (окремо від сторінки «Команда»)
    $opts['contact_manager_name']  = 'Юлія Романова';
    $opts['contact_manager_role']  = 'Менеджер по роботі з клієнтами';
    $opts['contact_manager_photo'] = bires_demo_asset( 'contact-manager.png' );
    foreach ( $opts as $key => $value ) {
        if ( ! get_field( $key, 'option' ) ) {
            update_field( $key, $value, 'option' );
        }
    }

    /* Статті */
    $body  = '<p>У судових справах з реєстрації податкових накладних суди в переважній більшості стають на бік платника податків.</p><p>Через це багато платників не сильно переймаються підготовкою якісних пояснень. <strong>Однак така позиція є хибною. Вона може призвести до майнових збитків та розриву господарських відносин з покупцями.</strong></p>'
        . '<h2>Перше і найважливіше правило – не ставитись до подання пояснень легковажно</h2><p>Подання пояснень та копій документів після зупинки реєстрації податкової накладної це основний етап всієї процедури.</p>'
        . '<h2>Друге важливе правило – своєчасно реагувати на повідомлення</h2><p>Порядок №520 не встановлює альтернативи.</p>'
        . '<h2>Третє правило – процесуальні строки</h2><ul><li>10 робочих днів — скарга</li><li>3 місяці — суд</li></ul>'
        . '<h2>Практичні рекомендації</h2><p>Радимо одразу запускати процес підготовки скарги або позову.</p>';
    $posts = [
        [ 'Держпраці та моббінг', 'derzhpratsi-ta-mobbinh', 'Трудове право', 'У жовтні 2025 року набувають чинності оновлені правила контролю від Держпраці. Що варто зробити бізнесу вже зараз?' ],
        [ 'Помилки в розблокуванні податкових накладних', 'pomylky-v-rozblokuvanni', 'Податкове право', 'Чому легковажні пояснення можуть коштувати бізнесу грошей і репутації? Дізнайтесь у статті далі.' ],
        [ 'Законопроєкт №13507 — ознаки наявності трудових відносин', 'oznaky-trudovykh-vidnosyn', 'Трудове право', 'Про що йдеться в законопроєкті №13507 і які ознаки трудових відносин він встановлює?' ],
        [ 'Як захистити бізнес під час обшуку', 'yak-zakhystyty-biznes-pid-chas-obshuku', 'Кримінальне право', 'Що робити, якщо до офісу прийшли з обшуком: покрокова інструкція для керівника.' ],
        [ 'Договори з IT-підрядниками', 'dohovory-z-it-pidriadnykamy', 'IT компанії', 'Які умови обов’язково варто прописати в договорі з розробником, щоб зберегти права на код.' ],
        [ 'Арешт майна у кримінальному провадженні', 'aresht-maina', 'Кримінальне право', 'Як оскаржити арешт рахунків і майна компанії та в які строки це потрібно зробити.' ],
    ];
    $related = array_map( 'strval', [ $ids['podatkova-praktyka'], $ids['korporatyvne-pravo'], $ids['derzhavni-protsedury'] ] );
    foreach ( $posts as $i => $row ) {
        list( $title, $slug, $cat, $excerpt ) = $row;
        $pid = bires_demo_post( 'post', $title, $slug, [
            'post_excerpt'  => $excerpt,
            'post_content'  => '<p>' . $excerpt . '</p>' . $body,
            'post_category' => [ wp_create_category( $cat ) ],
            'post_date'     => gmdate( 'Y-m-d H:i:s', time() - $i * DAY_IN_SECONDS ),
        ] );
        bires_demo_thumb( $pid, bires_demo_asset( 'post-' . ( $i + 1 ) . '.jpg' ) );
        // Порядок і заголовки як у макеті (демо-записи оновлюються при кожному запуску).
        wp_update_post( [ 'ID' => $pid, 'post_title' => $title, 'post_date' => gmdate( 'Y-m-d H:i:s', time() - $i * DAY_IN_SECONDS ), 'post_date_gmt' => gmdate( 'Y-m-d H:i:s', time() - $i * DAY_IN_SECONDS ) ] );
        update_field( 'post_team_author', $team['nadiia-bahrii'], $pid );
        // Для сторінки «Кримінальне право» — статті 1 і 3, як у макеті.
        $post_related = in_array( $i, [ 0, 2 ], true ) ? array_merge( $related, [ (string) $ids['kryminalne-pravo'] ] ) : $related;
        update_field( 'post_related_services', $post_related, $pid );
    }

    /* Кейси */
    $case_list = [
        [ 'UNDP', 'undp', 'case-undp.jpg', 'logo-undp-white.png', '' ],
        [ 'Dixi Group', 'dixi-group', 'case-dixi.jpg', 'logo-dixi-white.png', 'logo-dixi.png' ],
        [ 'Хвиля здоровʼя', 'khvylia-zdorovia', 'case-khvylia.jpg', 'logo-zdravo-white.png', 'logo-zdravo.png' ],
        [ 'ShipHawk', 'shiphawk', 'case-shiphawk.jpg', 'logo-shiphawk-white.png', '' ],
    ];
    foreach ( $case_list as $i => $row ) {
        list( $name, $slug, $bg, $logo, $logo_dark ) = $row;
        $id = bires_demo_post( 'case', $name, $slug, [ 'menu_order' => $i ] );
        bires_demo_thumb( $id, bires_demo_asset( $bg ) );
        if ( $logo ) {
            update_field( 'case_logo', bires_demo_asset( $logo ), $id );
        }
        if ( $logo_dark ) {
            update_field( 'case_logo_dark', bires_demo_asset( $logo_dark ), $id );
        }
        update_field( 'case_logo_large', 'khvylia-zdorovia' === $slug ? 1 : 0, $id );
        update_field( 'case_practice', 'Податкова практика', $id );
        update_field( 'case_intro', '<p>' . $name . ' — клієнт, якому ми допомогли після планової перевірки ДПС, за результатами якої було донараховано ПДВ на суму 4.2 млн грн.</p><p>Основною метою було оскаржити нарахування та захистити інтереси компанії в адміністративному і судовому порядку.</p>', $id );
        update_field( 'case_actions', array_map( function ( $t ) { return [ 'text' => $t ]; }, [ 'Провели правовий аналіз акта перевірки та первинної документації.', 'Підготували та подали заперечення на акт перевірки.', 'Сформували доказову базу: договори, накладні, платіжні доручення.', 'Представляли інтереси клієнта під час адміністративного оскарження в ДПС.', 'Підготували позовну заяву до адміністративного суду.' ] ), $id );
        update_field( 'case_expert', $team['nadiia-bahrii'], $id );
        update_field( 'case_expert_text', 'Юрист з багаторічним досвідом у податковому праві. Спеціалізується на спорах з ДПС та митними органами.', $id );
        update_field( 'case_results', array_map( function ( $t ) { return [ 'text' => $t ]; }, [ 'Судом першої інстанції податкове рішення скасовано в повному обсязі.', 'Зниження податкових ризиків та фінансових втрат.', 'Підвищення ефективності податкового планування.', 'Чітка структура податкових процесів.' ] ), $id );
        update_field( 'case_badges', array_map( function ( $t ) { return [ 'text' => $t ]; }, [ 'Галузь: енергетика', 'Тип справи: оскарження податкового рішення', 'Сума спору: 4.2 млн грн' ] ), $id );
    }
    update_field( 'hero_title', 'Наша практика у кожній галузі права', $cases );
    update_field( 'hero_text', 'Представляємо інтереси бізнесу і фізичних осіб незалежно від складності ситуації.', $cases );
    $results = [
        [ 'logo' => bires_demo_asset( 'logo-turk.png' ), 'name' => 'Turk Telekom', 'number' => '', 'text' => 'Зверталися за податковими консультаціями та юридичним супроводом договорів. Все зроблено чітко і вчасно, з розумінням специфіки туристичного бізнесу.' ],
        [ 'logo' => bires_demo_asset( 'logo-anex.png' ), 'name' => 'Anex Tour', 'number' => '99%', 'text' => 'справ завершено на користь клієнта в суді першої інстанції.' ],
        [ 'logo' => bires_demo_asset( 'logo-grinko.png' ), 'name' => 'Грінко', 'number' => '', 'text' => 'Зверталися з питанням реструктуризації боргових зобов\'язань перед кількома кредиторами. Юристи розібралися в ситуації швидко і запропонували реальне рішення, а не загальні рекомендації.' ],
    ];
    update_field( 'client_results', array_merge( $results, $results ), 'option' );
    update_field( 'client_results_text', 'Настав час вирішити свої юридичні питання? Почніть зараз.', 'option' );

    /* Контакти, Про нас */
    update_field( 'hero_title', 'Маєте юридичне питання?', $contacts );
    update_field( 'office_title', 'Manhattan City', $contacts );
    update_field( 'office_address', "Київ, Берестейський проспект 11, корпус 3\n27 поверх, офіс 323", $contacts );
    update_field( 'office_gallery', [
        [ 'image' => bires_demo_asset( 'office-1.jpg' ) ],
        [ 'image' => bires_demo_asset( 'office-2.jpg' ) ],
        [ 'image' => bires_demo_asset( 'office-3.jpg' ) ],
    ], $contacts );
    update_field( 'map_image', bires_demo_asset( 'map.jpg' ), $contacts );
    update_field( 'map_link', 'https://maps.google.com/?q=' . rawurlencode( 'Берестейський проспект 11, Київ' ), $contacts );
    update_field( 'contact_qr', bires_demo_asset( 'qr.png' ), $contacts );
    update_field( 'map_query', 'Берестейський проспект 11, Київ', $contacts );
    update_field( 'hero_text', 'Представляємо інтереси бізнесу і фізичних осіб незалежно від складності ситуації.', $about );
    bires_demo_thumb( $about, bires_demo_asset( 'about.jpg' ) );
    update_field( 'about_stats', [ [ 'number' => '12+', 'text' => 'років практики' ], [ 'number' => '500+', 'text' => 'успішно реалізованих кейсів' ], [ 'number' => '70%', 'text' => 'міжнародних клієнтів' ] ], $about );

    /* Головна */
    $names = [ 'RG', 'ZDRAVO', 'Genius Marketing', 'DIVAN.TV', 'Хвиля здоровʼя', 'Dixi Group', 'Anex Tour', 'ShipHawk', 'UNDP', 'Türk Telekom', 'Грінко', 'Укрнафта', 'BV', 'Logoplaste', 'Rijk Zwaan', 'LS group' ];
    $logos = [];
    foreach ( $names as $i => $n ) {
        $logos[] = [ 'image' => bires_demo_asset( sprintf( 'client-%02d.png', $i + 1 ) ), 'name' => $n ];
    }
    update_field( 'home_logos', $logos, $home );
    update_field( 'home_reviews', [
        [ 'name' => 'Руслан Савчук', 'role' => 'CEO компанії', 'logo' => bires_demo_asset( 'review-anex.png' ), 'badge' => 'Туризм', 'rating' => 5, 'text' => 'Співпраця з командою Bires була для нас ефективною та комфортною. Ми отримали чіткі податкові консультації та всебічний юридичний супровід. Договори були підготовлені оперативно та з урахуванням особливостей туристичної сфери. Рекомендуємо Bires як надійного та компетентного партнера.' ],
    ], $home );
    update_field( 'home_achievements', [
        [ 'title' => 'Юридичний супровід міжнародного SaaS-бізнесу', 'text' => 'Юридичний супровід SaaS-платформи на етапі розвитку продукту: підготовка договорів, політик конфіденційності, умов користування та правовий аудит бізнес-процесів.', 'tags' => 'SaaS & IT, B2B супровід', 'period' => '2025-2026', 'image' => bires_demo_asset( 'ach-1.jpg' ) ],
        [ 'title' => 'Захист інтересів у податковому спорі', 'text' => 'Оскарження податкового повідомлення-рішення на 4.2 млн грн.', 'tags' => 'Податки', 'period' => '2024', 'image' => bires_demo_asset( 'ach-2.jpg' ) ],
    ], $home );
    update_field( 'home_quote_person', $team['ihor-bahrii'], $home );
    update_field( 'home_quote_role', 'СEO компанії Bires', $home );
    update_field( 'home_quote_photo', bires_demo_asset( 'team-oleh.jpg' ), $home );

    /* Меню */
    $pg   = function ( $id, $title = '', $children = [] ) {
        return [ 'menu-item-object' => 'page', 'menu-item-object-id' => $id, 'menu-item-type' => 'post_type', 'menu-item-title' => $title, 'children' => $children ];
    };
    $link = function ( $title, $url, $children = [] ) {
        return [ 'menu-item-title' => $title, 'menu-item-url' => $url, 'children' => $children ];
    };
    bires_demo_menu( 'Головне', 'primary', [
        $pg( $services, '', [
            $link( 'Для бізнесу', '#', [
                $pg( $ids['korporatyvne-pravo'], '', [ $pg( $ids['reiestratsiia-biznesu'], 'Реєстрація підприємств' ), $pg( $ids['rozrobka-dogovoriv'], 'Юридичний супровід бізнесу' ) ] ),
                $pg( $ids['derzhavni-protsedury'] ),
                $pg( $ids['podatkova-praktyka'] ),
                $pg( $ids['reiestratsiia-biznesu'] ),
                $pg( $ids['kryminalne-pravo'] ),
                $pg( $ids['bankrutstvo'] ),
                $pg( $ids['budivnytstvo'] ),
                $pg( $ids['rozrobka-dogovoriv'] ),
                $pg( $ids['kadry'] ),
                $pg( $ids['intelektualne-pravo'] ),
            ] ),
            $link( 'Для фізичних осіб', '#', [
                $pg( $ids['simeine-pravo'] ),
                $pg( $ids['migratsiine-pravo'] ),
                $pg( $ids['kryminalne-pravo-fizosoby'], 'Кримінальне право' ),
                $pg( $ids['stiagnennia-zaborgovanosti'] ),
                $pg( $ids['budivnytstvo-fizosoby'], 'Будівництво та майно' ),
            ] ),
        ] ),
        $link( 'Команда', home_url( '/komanda/' ) ),
        $pg( $cases ),
        $pg( $blog, 'Новини & блог' ),
        $pg( $contacts ),
    ] );
    bires_demo_menu( 'Практики', 'footer_services', [
        $pg( $ids['korporatyvne-pravo'], 'Корпоративне' ),
        $pg( $ids['podatkova-praktyka'], 'Податкове' ),
        $pg( $ids['derzhavni-protsedury'], 'Судові спори' ),
        $pg( $ids['kryminalne-pravo'], 'Кримінальне' ),
        $pg( $ids['migratsiine-pravo'], 'Міграційне' ),
    ] );
    bires_demo_menu( 'Компанія', 'footer_company', [
        $pg( $about ),
        $link( 'Команда', home_url( '/komanda/' ) ),
        $pg( $blog, 'Блог & новини' ),
        $pg( $contacts ),
        $pg( $sitemap ),
    ] );

    if ( function_exists( 'bires_register_post_types' ) ) {
        bires_register_post_types();
    }
    flush_rewrite_rules();
}
