<?php

function bires_menu_tree( $location ) {
    $locations = get_nav_menu_locations();
    if ( empty( $locations[ $location ] ) ) {
        return [];
    }
    $items = wp_get_nav_menu_items( $locations[ $location ], [ 'update_post_term_cache' => false ] );
    if ( ! $items ) {
        return [];
    }
    _wp_menu_item_classes_by_context( $items );

    $by_parent = [];
    foreach ( $items as $item ) {
        $by_parent[ (int) $item->menu_item_parent ][] = $item;
    }
    $build = function ( $parent_id ) use ( &$build, $by_parent ) {
        $nodes = [];
        foreach ( $by_parent[ $parent_id ] ?? [] as $item ) {
            $item->children = $build( (int) $item->ID );
            $nodes[]        = $item;
        }
        return $nodes;
    };
    return $build( 0 );
}

function bires_menu_item_is_current( $item ) {
    if ( $item->current || $item->current_item_ancestor || $item->current_item_parent ) {
        return true;
    }
    foreach ( $item->children as $child ) {
        if ( bires_menu_item_is_current( $child ) ) {
            return true;
        }
    }
    return false;
}

function bires_menu_link_attrs( $item ) {
    $attrs = ' href="' . esc_url( $item->url ) . '"';
    if ( $item->current ) {
        $attrs .= ' aria-current="page"';
    }
    if ( $item->xfn ) {
        $attrs .= ' rel="' . esc_attr( $item->xfn ) . '"';
    }
    return $attrs;
}

function bires_render_mega_cards( $services ) {
    echo '<ul class="mega__cards">';
    foreach ( $services as $service ) {
        $has_sub = ! empty( $service->children );
        printf( '<li class="mega-card%s">', $has_sub ? ' mega-card--with-sub' : '' );
        printf(
            '<a class="mega-card__title"%s>%s<span class="mega-card__go" aria-hidden="true">%s</span></a>',
            bires_menu_link_attrs( $service ),
            esc_html( $service->title ),
            bires_icon( 'arrow-right', 24 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG
        );
        echo '<div class="mega-card__bottom">';
        if ( $has_sub ) {
            echo '<ul class="mega-card__sub">';
            foreach ( $service->children as $sub ) {
                printf( '<li><a%s>%s</a></li>', bires_menu_link_attrs( $sub ), esc_html( $sub->title ) );
            }
            echo '</ul>';
        }
        printf(
            '<a class="mega-card__arrow" href="%s" tabindex="-1" aria-hidden="true">%s</a>',
            esc_url( $service->url ),
            bires_icon( 'arrow-up-right', 24 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG
        );
        echo '</div></li>';
    }
    echo '</ul>';
}

function bires_render_primary_menu() {
    $tree = bires_menu_tree( 'primary' );
    if ( ! $tree ) {
        return;
    }

    echo '<ul class="site-nav__list">';
    foreach ( $tree as $index => $item ) {
        $is_mega = ! empty( $item->children );
        $classes = [ 'site-nav__item' ];
        if ( bires_menu_item_is_current( $item ) ) {
            $classes[] = 'is-current';
        }
        if ( $is_mega ) {
            $classes[] = 'has-mega';
        }

        printf( '<li class="%s">', esc_attr( implode( ' ', $classes ) ) );
        printf( '<a class="site-nav__link"%s>%s</a>', bires_menu_link_attrs( $item ), esc_html( $item->title ) );

        if ( $is_mega ) {
            $panel_id = 'mega-' . $index;
            printf(
                '<button type="button" class="site-nav__toggle" aria-expanded="false" aria-controls="%s"><span class="screen-reader-text">%s</span>%s</button>',
                esc_attr( $panel_id ),
                /* translators: %s: menu item title */
                esc_html( sprintf( __( 'Відкрити підменю «%s»', 'bires-theme' ), $item->title ) ),
                '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="m5 7.5 5 5 5-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'
            );

            $groups_are_tabs = count( array_filter( $item->children, function ( $child ) {
                return ! empty( $child->children );
            } ) ) === count( $item->children );

            printf( '<div class="mega" id="%s"><div class="mega__inner container container--wide">', esc_attr( $panel_id ) );
            if ( $groups_are_tabs ) {
                echo '<div class="mega__tabs" role="tablist">';
                foreach ( $item->children as $g => $group ) {
                    printf(
                        '<button type="button" class="mega__tab%s" role="tab" id="%s-tab-%d" aria-selected="%s" aria-controls="%s-panel-%d">%s</button>',
                        0 === $g ? ' is-active' : '',
                        esc_attr( $panel_id ),
                        (int) $g,
                        0 === $g ? 'true' : 'false',
                        esc_attr( $panel_id ),
                        (int) $g,
                        esc_html( $group->title )
                    );
                }
                echo '</div>';
                foreach ( $item->children as $g => $group ) {
                    printf(
                        '<div class="mega__panel" role="tabpanel" id="%1$s-panel-%2$d" aria-labelledby="%1$s-tab-%2$d"%3$s>',
                        esc_attr( $panel_id ),
                        (int) $g,
                        0 === $g ? '' : ' hidden'
                    );
                    bires_render_mega_cards( $group->children );
                    echo '</div>';
                }
            } else {
                echo '<div class="mega__panel">';
                bires_render_mega_cards( $item->children );
                echo '</div>';
            }
            echo '</div></div>';
        }
        echo '</li>';
    }
    echo '</ul>';
}

function bires_language_switcher() {
    $languages = apply_filters( 'wpml_active_languages', null, [ 'skip_missing' => 1, 'orderby' => 'custom' ] );
    if ( empty( $languages ) || count( $languages ) < 2 ) {
        return;
    }
    ?>
    <div class="lang-switcher">
        <button type="button" class="lang-switcher__toggle" aria-expanded="false" aria-controls="lang-list">
            <span class="screen-reader-text"><?php esc_html_e( 'Мова сайту', 'bires-theme' ); ?></span>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.5"/><path d="M3 12h18M12 3c2.5 2.5 3.6 5.6 3.6 9s-1.1 6.5-3.6 9c-2.5-2.5-3.6-5.6-3.6-9S9.5 5.5 12 3Z" stroke="currentColor" stroke-width="1.5"/></svg>
        </button>
        <ul class="lang-switcher__list" id="lang-list" hidden>
            <?php foreach ( $languages as $language ) : ?>
                <li>
                    <a href="<?php echo esc_url( $language['url'] ); ?>" hreflang="<?php echo esc_attr( $language['language_code'] ?? $language['code'] ); ?>" lang="<?php echo esc_attr( $language['language_code'] ?? $language['code'] ); ?>"<?php echo ! empty( $language['active'] ) ? ' aria-current="true" class="is-active"' : ''; ?>>
                        <?php echo esc_html( strtoupper( $language['language_code'] ?? $language['code'] ) ); ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php
}
