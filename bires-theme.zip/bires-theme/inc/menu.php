<?php

function bires_menu_tree( $location ) {
    $locations = get_nav_menu_locations();
    if ( empty( $locations[ $location ] ) ) {
        return [];
    }
    $items = wp_get_nav_menu_items( $locations[ $location ], [ 'update_post_term_cache' => false ] );
    if ( ! $items ) {
        return [];
    }
    _wp_menu_item_classes_by_context( $items );

    $by_parent = [];
    foreach ( $items as $item ) {
        $by_parent[ (int) $item->menu_item_parent ][] = $item;
    }
    $build = function ( $parent_id ) use ( &$build, $by_parent ) {
        $nodes = [];
        foreach ( $by_parent[ $parent_id ] ?? [] as $item ) {
            $item->children = $build( (int) $item->ID );
            $nodes[]        = $item;
        }
        return $nodes;
    };
    return $build( 0 );
}

function bires_menu_item_is_current( $item ) {
    if ( $item->current || $item->current_item_ancestor || $item->current_item_parent ) {
        return true;
    }
    foreach ( $item->children as $child ) {
        if ( bires_menu_item_is_current( $child ) ) {
            return true;
        }
    }
    return false;
}

function bires_menu_link_attrs( $item ) {
    $attrs = ' href="' . esc_url( $item->url ) . '"';
    if ( $item->current ) {
        $attrs .= ' aria-current="page"';
    }
    if ( $item->xfn ) {
        $attrs .= ' rel="' . esc_attr( $item->xfn ) . '"';
    }
    return $attrs;
}

/**
 * Адреса картки мегаменю: пункт групи зі старого сайту веде на каталог з якорем (/poslugy/#podatkova-praktyka) —
 * якщо в групи вже є своя сторінка напряму, ведемо на неї, як картки каталогу.
 */
function bires_mega_card_url( $item ) {
    $url      = (string) $item->url;
    $fragment = (string) wp_parse_url( $url, PHP_URL_FRAGMENT );
    if ( '' !== $fragment && function_exists( 'bires_group_page_id' ) ) {
        $term = get_term_by( 'slug', sanitize_title( rawurldecode( $fragment ) ), 'service_category' );
        if ( ! $term ) {
            $term = get_term_by( 'slug', rawurlencode( rawurldecode( $fragment ) ), 'service_category' );
        }
        $page = $term ? bires_group_page_id( $term ) : 0;
        if ( $page ) {
            return get_permalink( $page );
        }
    }
    return $url;
}

/** Картки мегаменю (як у макеті): рівна сітка, у картці лише назва напряму й стрілка; уся картка — посилання. */
function bires_render_mega_cards( $services ) {
    echo '<ul class="mega__grid">';
    foreach ( $services as $service ) {
        bires_render_mega_card( $service );
    }
    echo '</ul>';
}

function bires_render_mega_card( $service ) {
    $attrs = ' href="' . esc_url( bires_mega_card_url( $service ) ) . '"';
    if ( $service->current ) {
        $attrs .= ' aria-current="page"';
    }
    printf(
        '<li class="mega-card"><a class="mega-card__title"%s><span class="mega-card__name">%s</span><span class="mega-card__go" aria-hidden="true">%s</span><span class="mega-card__arrow" aria-hidden="true">%s</span></a></li>',
        $attrs, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above
        esc_html( $service->title ),
        bires_icon( 'arrow-right', 24 ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG
        bires_icon( 'arrow-up-right', 24 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG
    );
}

function bires_render_primary_menu() {
    $tree = bires_menu_tree( 'primary' );
    if ( ! $tree ) {
        return;
    }

    echo '<ul class="site-nav__list">';
    foreach ( $tree as $index => $item ) {
        $is_mega = ! empty( $item->children );
        $classes = [ 'site-nav__item' ];
        if ( bires_menu_item_is_current( $item ) ) {
            $classes[] = 'is-current';
        }
        if ( $is_mega ) {
            $classes[] = 'has-mega';
        }

        printf( '<li class="%s">', esc_attr( implode( ' ', $classes ) ) );
        printf( '<a class="site-nav__link"%s>%s</a>', bires_menu_link_attrs( $item ), esc_html( $item->title ) );

        if ( $is_mega ) {
            $panel_id = 'mega-' . $index;
            printf(
                '<button type="button" class="site-nav__toggle" aria-expanded="false" aria-controls="%s"><span class="screen-reader-text">%s</span>%s</button>',
                esc_attr( $panel_id ),
                /* translators: %s: menu item title */
                esc_html( sprintf( __( 'Відкрити підменю «%s»', 'bires-theme' ), $item->title ) ),
                '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="m5 7.5 5 5 5-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'
            );

            $groups_are_tabs = count( array_filter( $item->children, function ( $child ) {
                return ! empty( $child->children );
            } ) ) === count( $item->children );

            printf( '<div class="mega" id="%s"><div class="mega__inner container container--wide">', esc_attr( $panel_id ) );
            if ( $groups_are_tabs ) {
                echo '<div class="mega__tabs" role="tablist">';
                foreach ( $item->children as $g => $group ) {
                    printf(
                        '<button type="button" class="mega__tab%s" role="tab" id="%s-tab-%d" aria-selected="%s" aria-controls="%s-panel-%d">%s</button>',
                        0 === $g ? ' is-active' : '',
                        esc_attr( $panel_id ),
                        (int) $g,
                        0 === $g ? 'true' : 'false',
                        esc_attr( $panel_id ),
                        (int) $g,
                        esc_html( $group->title )
                    );
                }
                echo '</div>';
                // Напрями для бізнесу з позначкою «Також для фізичних осіб» (кримінальне право, стягнення, майно) —
                // і у вкладці фізичних осіб, як у каталозі: ті самі пункти, ті самі сторінки
                $shared = [];
                foreach ( $item->children as $g => $group ) {
                    if ( preg_match( '/бізн|бизн/iu', $group->title ) && function_exists( 'bires_service_for' ) ) {
                        foreach ( $group->children as $card ) {
                            if ( 'page' === $card->object && bires_service_for( (int) $card->object_id, 'personal' ) ) {
                                $shared[ (int) $card->object_id ] = $card;
                            }
                        }
                    }
                }
                foreach ( $item->children as $g => $group ) {
                    // Вкладка «Для фізичних осіб» (друга, якщо назва інша)
                    $personal = preg_match( '/фіз|физ/iu', $group->title ) || ( 1 === $g && ! preg_match( '/бізн|бизн/iu', $group->title ) );
                    if ( $personal && $shared ) {
                        $own = [];
                        foreach ( $group->children as $card ) {
                            $own[ (int) $card->object_id ] = true;
                        }
                        foreach ( $shared as $page_id => $card ) {
                            if ( empty( $own[ $page_id ] ) ) {
                                $group->children[] = $card;
                            }
                        }
                    }
                    printf(
                        '<div class="mega__panel%4$s" role="tabpanel" id="%1$s-panel-%2$d" aria-labelledby="%1$s-tab-%2$d"%3$s>',
                        esc_attr( $panel_id ),
                        (int) $g,
                        0 === $g ? '' : ' hidden',
                        $personal ? ' mega__panel--personal' : ''
                    );
                    bires_render_mega_cards( $group->children );
                    echo '</div>';
                }
            } else {
                echo '<div class="mega__panel">';
                bires_render_mega_cards( $item->children );
                echo '</div>';
            }
            echo '</div></div>';
        }
        echo '</li>';
    }
    echo '</ul>';
}

/**
 * Мови сайту для перемикача (глобус у шапці): з WPML, Polylang або TranslatePress — що встановлено.
 * Поки перекладів немає, у списку лише мова сайту; коли з'явиться плагін перекладу з кількома мовами,
 * вони з'являться тут самі. Кожна мова: code, label (UA, EN…), name, url, active.
 */
function bires_site_languages() {
    $label = function ( $code ) {
        $code = strtolower( substr( (string) $code, 0, 2 ) );
        return 'uk' === $code ? 'UA' : strtoupper( $code );
    };
    $list = [];
    $wpml = apply_filters( 'wpml_active_languages', null, [ 'skip_missing' => 1, 'orderby' => 'custom' ] );
    if ( is_array( $wpml ) && count( $wpml ) > 1 ) {
        foreach ( $wpml as $language ) {
            $code   = isset( $language['language_code'] ) ? $language['language_code'] : $language['code'];
            $list[] = [ 'code' => $code, 'label' => $label( $code ), 'name' => isset( $language['native_name'] ) ? $language['native_name'] : '', 'url' => $language['url'], 'active' => ! empty( $language['active'] ) ];
        }
        return $list;
    }
    if ( function_exists( 'pll_the_languages' ) ) {
        $pll = pll_the_languages( [ 'raw' => 1, 'hide_if_empty' => 0 ] );
        if ( is_array( $pll ) && count( $pll ) > 1 ) {
            foreach ( $pll as $language ) {
                $list[] = [ 'code' => $language['slug'], 'label' => $label( $language['slug'] ), 'name' => $language['name'], 'url' => $language['url'], 'active' => ! empty( $language['current_lang'] ) ];
            }
            return $list;
        }
    }
    if ( function_exists( 'trp_custom_language_switcher' ) ) {
        global $TRP_LANGUAGE;
        $trp = trp_custom_language_switcher();
        if ( is_array( $trp ) && count( $trp ) > 1 ) {
            foreach ( $trp as $language ) {
                $list[] = [ 'code' => $language['language_code'], 'label' => $label( $language['language_code'] ), 'name' => $language['language_name'], 'url' => $language['current_page_url'], 'active' => $TRP_LANGUAGE === $language['language_code'] ];
            }
            return $list;
        }
    }
    // Перекладів ще немає: сайт українською, незалежно від мови адмінки
    return [ [ 'code' => 'uk', 'label' => 'UA', 'name' => 'Українська', 'url' => is_singular() ? get_permalink() : home_url( '/' ), 'active' => true ] ];
}

function bires_language_switcher() {
    $languages = bires_site_languages();
    ?>
    <div class="lang-switcher">
        <button type="button" class="lang-switcher__toggle" aria-expanded="false" aria-controls="lang-list">
            <span class="screen-reader-text"><?php esc_html_e( 'Мова сайту', 'bires-theme' ); ?></span>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.5"/><path d="M3 12h18M12 3c2.5 2.5 3.6 5.6 3.6 9s-1.1 6.5-3.6 9c-2.5-2.5-3.6-5.6-3.6-9S9.5 5.5 12 3Z" stroke="currentColor" stroke-width="1.5"/></svg>
        </button>
        <ul class="lang-switcher__list" id="lang-list" hidden>
            <?php foreach ( $languages as $language ) : ?>
                <li>
                    <a href="<?php echo esc_url( $language['url'] ); ?>" hreflang="<?php echo esc_attr( $language['code'] ); ?>" lang="<?php echo esc_attr( $language['code'] ); ?>"<?php echo $language['active'] ? ' aria-current="true" class="is-active"' : ''; ?><?php echo $language['name'] ? ' title="' . esc_attr( $language['name'] ) . '"' : ''; ?>>
                        <?php echo esc_html( $language['label'] ); ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php
}
