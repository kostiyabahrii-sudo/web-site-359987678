<?php

function bires_print_json_ld( $data ) {
    echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n";
}

function bires_schema_faq() {
    if ( ! is_singular( 'page' ) ) {
        return;
    }

    $entities = [];
    foreach ( bires_rows( 'faq' ) as $row ) {
        if ( empty( $row['question'] ) || empty( $row['answer'] ) ) {
            continue;
        }
        $entities[] = [
            '@type'          => 'Question',
            'name'           => wp_strip_all_tags( $row['question'] ),
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text'  => trim( wp_strip_all_tags( $row['answer'] ) ),
            ],
        ];
    }

    if ( $entities ) {
        bires_print_json_ld( [
            '@context'   => 'https://schema.org',
            '@type'      => 'FAQPage',
            'mainEntity' => $entities,
        ] );
    }
}
add_action( 'wp_head', 'bires_schema_faq' );

function bires_schema_organization() {
    $logo = get_site_icon_url( 512 );
    $org  = [
        '@type' => 'Organization',
        'name'  => 'Bires Law Firm',
        'url'   => home_url( '/' ),
    ];
    if ( $logo ) {
        $org['logo'] = [ '@type' => 'ImageObject', 'url' => $logo ];
    }
    return $org;
}

function bires_first_sentence( $html ) {
    $text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( preg_replace( '/<[^>]+>/', ' ', strip_shortcodes( $html ) ) ) ) );
    if ( preg_match( '/^(.{20,300}?[.!?…])(\s|$)/u', $text, $m ) ) {
        return $m[1];
    }
    return wp_trim_words( $text, 30, '…' );
}

function bires_schema_article() {
    if ( ! is_singular( 'post' ) ) {
        return;
    }
    $post_id   = get_queried_object_id();
    $author_id = (int) bires_field( 'post_team_author', $post_id );

    $data = [
        '@context'         => 'https://schema.org',
        '@type'            => 'Article',
        'headline'         => wp_strip_all_tags( get_the_title( $post_id ) ),
        'description'      => bires_first_sentence( get_post_field( 'post_content', $post_id ) ),
        'publisher'        => bires_schema_organization(),
        'datePublished'    => get_the_date( 'c', $post_id ),
        'dateModified'     => get_the_modified_date( 'c', $post_id ),
        'mainEntityOfPage' => [ '@type' => 'WebPage', '@id' => get_permalink( $post_id ) ],
    ];

    $image = get_the_post_thumbnail_url( $post_id, 'full' );
    if ( $image ) {
        $data['image'] = [ $image ];
    }

    if ( $author_id && 'publish' === get_post_status( $author_id ) ) {
        $data['author'] = [
            '@type' => 'Person',
            'name'  => get_the_title( $author_id ),
            'url'   => get_permalink( $author_id ),
        ];
    } else {
        $data['author'] = bires_schema_organization();
    }

    bires_print_json_ld( $data );
}
add_action( 'wp_head', 'bires_schema_article' );

add_filter( 'wpseo_schema_needs_article', '__return_false' );

function bires_schema_person() {
    if ( ! is_singular( 'team' ) ) {
        return;
    }
    $member_id = get_queried_object_id();
    $url       = get_permalink( $member_id );
    $data      = [
        '@context'  => 'https://schema.org',
        '@type'     => 'Person',
        '@id'       => $url,
        'name'      => wp_strip_all_tags( get_the_title( $member_id ) ),
        'url'       => $url,
        'worksFor'  => [ '@type' => 'Organization', 'name' => 'Bires Law Firm' ],
    ];

    $image = get_the_post_thumbnail_url( $member_id, 'full' );
    if ( $image ) {
        $data['image'] = $image;
    }
    $position = bires_field( 'team_position', $member_id );
    if ( $position ) {
        $data['jobTitle'] = $position;
    }
    $lead = bires_field( 'team_lead', $member_id );
    $data['description'] = $lead ? $lead : bires_first_sentence( get_post_field( 'post_content', $member_id ) );

    $same_as = array_values( array_filter( wp_list_pluck( bires_rows( 'team_socials', $member_id ), 'url' ) ) );
    if ( $same_as ) {
        $data['sameAs'] = $same_as;
    }

    bires_print_json_ld( $data );
}
add_action( 'wp_head', 'bires_schema_person' );
