<?php
/**
 * Сайт перенесено зі старого разом із таблицями WPML, але сам плагін WPML ще не встановлено:
 * на сайті показуються лише записи основної мови, щоб російські сторінки не змішувалися з українськими.
 * Щойно WPML увімкнено, усе це вимикається — мови веде сам WPML.
 */

function bires_lang_table() {
    static $table = null;
    if ( null === $table ) {
        global $wpdb;
        $name  = $wpdb->prefix . 'icl_translations';
        $wpml  = defined( 'ICL_SITEPRESS_VERSION' ) || apply_filters( 'wpml_default_language', null );
        $table = ! $wpml && $name === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $name ) ) ? $name : '';
    }
    return $table;
}

function bires_lang_default() {
    $settings = get_option( 'icl_sitepress_settings' );
    return is_array( $settings ) && ! empty( $settings['default_language'] ) ? $settings['default_language'] : 'uk';
}

/**
 * Порожні дублікати старого сайту: лише російський заголовок, без тексту й без мови у WPML — тож вважалися б українськими.
 * Статті без тексту — усі такі; сторінки — ці (у кожної є повноцінна українська версія; у першої — копія
 * «Оскарження блокування податкових накладних»). ID — як на старому сайті, адреса — для перевірки.
 */
function bires_lang_stub_pages() {
    return [
        7602 => 'obzhalovanie-blokirovki-nalogovyh-nakladnyh',
        8958 => 'registracziya-ooo',
        9022 => 'yuridicheskoe-soprovozhdenie-predstavleniya-struktury-sobstvennosti',
        9044 => 'yuridicheskoe-soprovozhdenie-podgotovki-iskovogo-zayavleniya',
        9602 => 'otkrytie-proizvodstva-po-delu-o-bankrotstve',
        9606 => 'snyatie-aresta-so-schetov-dolzhnika',
        9610 => 'restrukturizacziya-dolgov-dolzhnika',
        9622 => 'priznanie-bankrotom-yuridicheskogo-licza',
    ];
}

/** ID записів і сторінок іншими мовами (і порожніх дублікатів без мови). */
function bires_lang_foreign_posts() {
    static $ids = null;
    if ( null === $ids ) {
        global $wpdb;
        $table = bires_lang_table();
        $ids   = $table ? array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT element_id FROM $table WHERE element_type LIKE %s AND language_code <> %s", $wpdb->esc_like( 'post_' ) . '%', bires_lang_default() ) ) ) : []; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name
        if ( $table ) {
            $pages = bires_lang_stub_pages();
            $stubs = $wpdb->get_results( "SELECT p.ID, p.post_type, p.post_name FROM {$wpdb->posts} p WHERE p.post_status = 'publish' AND ( ( p.post_type = 'post' AND p.post_content = '' ) OR ( p.post_type = 'page' AND p.ID IN ( " . implode( ',', array_map( 'intval', array_keys( $pages ) ) ) . " ) ) ) AND NOT EXISTS ( SELECT 1 FROM $table t WHERE t.element_id = p.ID AND t.element_type IN ( 'post_post', 'post_page' ) )" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name, integer IDs
            foreach ( $stubs as $stub ) {
                if ( 'post' === $stub->post_type || 0 === strpos( $stub->post_name, $pages[ (int) $stub->ID ] ) ) {
                    $ids[] = (int) $stub->ID;
                }
            }
        }
    }
    return $ids;
}

function bires_lang_filter_query( $query ) {
    if ( is_admin() || ! bires_lang_foreign_posts() ) {
        return;
    }
    $query->set( 'post__not_in', array_merge( (array) $query->get( 'post__not_in' ), bires_lang_foreign_posts() ) );
}
add_action( 'pre_get_posts', 'bires_lang_filter_query' );

function bires_lang_filter_pages( $pages ) {
    if ( is_admin() || ! bires_lang_foreign_posts() ) {
        return $pages;
    }
    $foreign = array_flip( bires_lang_foreign_posts() );
    return array_values( array_filter( $pages, function ( $page ) use ( $foreign ) {
        return ! isset( $foreign[ $page->ID ] );
    } ) );
}
add_filter( 'get_pages', 'bires_lang_filter_pages' );

function bires_lang_filter_terms( $clauses ) {
    $table = bires_lang_table();
    if ( is_admin() || ! $table ) {
        return $clauses;
    }
    global $wpdb;
    $clauses['where'] .= $wpdb->prepare( " AND tt.term_taxonomy_id NOT IN ( SELECT element_id FROM $table WHERE element_type LIKE %s AND language_code <> %s )", $wpdb->esc_like( 'tax_' ) . '%', bires_lang_default() ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name
    return $clauses;
}
add_filter( 'terms_clauses', 'bires_lang_filter_terms' );
