<?php
/**
 * Сайт перенесено зі старого разом із таблицями WPML, але сам плагін WPML ще не встановлено:
 * на сайті показуються лише записи основної мови, щоб російські сторінки не змішувалися з українськими.
 * Щойно WPML увімкнено, усе це вимикається — мови веде сам WPML.
 */

function bires_lang_table() {
    static $table = null;
    if ( null === $table ) {
        global $wpdb;
        $name  = $wpdb->prefix . 'icl_translations';
        $wpml  = defined( 'ICL_SITEPRESS_VERSION' ) || apply_filters( 'wpml_default_language', null );
        $table = ! $wpml && $name === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $name ) ) ? $name : '';
    }
    return $table;
}

function bires_lang_default() {
    $settings = get_option( 'icl_sitepress_settings' );
    return is_array( $settings ) && ! empty( $settings['default_language'] ) ? $settings['default_language'] : 'uk';
}

/**
 * Порожні дублікати старого сайту російською: лише заголовок (у «Обжалование блокировки…» — копія української
 * сторінки «Оскарження блокування податкових накладних»), у WPML без мови — тож вважалися б українськими.
 * У кожного є повноцінна українська версія. Адреса => заголовок: шукаємо за ними, бо номери записів на різних сайтах різні.
 */
function bires_lang_stubs() {
    return [
        'obzhalovanie-blokirovki-nalogovyh-nakladnyh'                                         => 'Обжалование блокировки налоговых накладных',
        'registracziya-ooo'                                                                   => 'Регистрация ООО',
        'yuridicheskoe-soprovozhdenie-predstavleniya-struktury-sobstvennosti-yuridicheskogo-licza' => 'Юридическое сопровождение представления структуры собственности юридического лица',
        'yuridicheskoe-soprovozhdenie-podgotovki-iskovogo-zayavleniya'                        => 'Юридическое сопровождение подготовки искового заявления',
        'otkrytie-proizvodstva-po-delu-o-bankrotstve'                                         => 'Открытие производства по делу о банкротстве',
        'snyatie-aresta-so-schetov-dolzhnika'                                                 => 'Снятие ареста со счетов должника',
        'restrukturizacziya-dolgov-dolzhnika'                                                 => 'Реструктуризация долгов должника',
        'priznanie-bankrotom-yuridicheskogo-licza'                                            => 'Признание банкротом юридического лица',
        'kakie-dejstviya-dolzhnika-mogut-svidetelstvovat'                                     => 'Какие действия должника могут свидетельствовать о преднамеренном доведении до банкротства? Субсидиарная ответственность по примерам.',
        'vedenie-kadrovogo-ucheta-v-elektronnom-vide'                                         => 'Ведение кадрового учета в электронном виде',
        'chto-novogo-dast-biznesu-ekonomicheskoe-bronirovanie'                                => 'Что нового даст бизнесу экономическое бронирование?',
        'kak-smenit-direktora-ooo'                                                            => 'Как сменить директора ООО',
        'vklad-v-podderzhku-trudoustrojstva-licz-s-invalidnostyu-vmesto-shtrafa'              => 'Вклад в поддержку трудоустройства лиц с инвалидностью вместо штрафа',
    ];
}

/** ID порожніх дублікатів на цьому сайті (з даним статусом): заголовок збігається, адреса починається так само. */
function bires_lang_stub_ids( $status = 'publish' ) {
    global $wpdb;
    $stubs  = bires_lang_stubs();
    $titles = array_values( $stubs );
    $rows   = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_name, post_title FROM {$wpdb->posts} WHERE post_type IN ( 'post', 'page' ) AND post_status = %s AND post_title IN ( " . implode( ',', array_fill( 0, count( $titles ), '%s' ) ) . ' )', array_merge( [ $status ], $titles ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- placeholders
    $ids    = [];
    foreach ( $rows as $row ) {
        foreach ( $stubs as $slug => $title ) {
            if ( $title === $row->post_title && 0 === strpos( $row->post_name, $slug ) ) {
                $ids[] = (int) $row->ID;
            }
        }
    }
    return $ids;
}

/** ID записів і сторінок іншими мовами (і порожніх дублікатів без мови). */
function bires_lang_foreign_posts() {
    static $ids = null;
    if ( null === $ids ) {
        global $wpdb;
        $table = bires_lang_table();
        $ids   = $table ? array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT element_id FROM $table WHERE element_type LIKE %s AND language_code <> %s", $wpdb->esc_like( 'post_' ) . '%', bires_lang_default() ) ) ) : []; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name
        // Статті без тексту й без мови у WPML — порожні дублікати
        if ( $table ) {
            $ids = array_merge( $ids, array_map( 'intval', $wpdb->get_col( "SELECT p.ID FROM {$wpdb->posts} p WHERE p.post_type = 'post' AND p.post_status = 'publish' AND p.post_content = '' AND NOT EXISTS ( SELECT 1 FROM $table t WHERE t.element_id = p.ID AND t.element_type = 'post_post' )" ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name
        }
        // Відомі порожні дублікати — на будь-якому сайті, і з таблицею мов, і без неї
        $ids = array_values( array_unique( array_merge( $ids, bires_lang_stub_ids() ) ) );
    }
    return $ids;
}

/** Сховане на сайті (інші мови, порожні дублікати) — і з карти сайту Yoast SEO. */
function bires_lang_sitemap_exclude( $ids ) {
    return array_merge( (array) $ids, bires_lang_foreign_posts() );
}
add_filter( 'wpseo_exclude_from_sitemap_by_post_ids', 'bires_lang_sitemap_exclude' );

function bires_lang_filter_query( $query ) {
    if ( is_admin() || ! bires_lang_foreign_posts() ) {
        return;
    }
    $query->set( 'post__not_in', array_merge( (array) $query->get( 'post__not_in' ), bires_lang_foreign_posts() ) );
}
add_action( 'pre_get_posts', 'bires_lang_filter_query' );

function bires_lang_filter_pages( $pages ) {
    if ( is_admin() || ! bires_lang_foreign_posts() ) {
        return $pages;
    }
    $foreign = array_flip( bires_lang_foreign_posts() );
    return array_values( array_filter( $pages, function ( $page ) use ( $foreign ) {
        return ! isset( $foreign[ $page->ID ] );
    } ) );
}
add_filter( 'get_pages', 'bires_lang_filter_pages' );

function bires_lang_filter_terms( $clauses ) {
    $table = bires_lang_table();
    if ( is_admin() || ! $table ) {
        return $clauses;
    }
    global $wpdb;
    $clauses['where'] .= $wpdb->prepare( " AND tt.term_taxonomy_id NOT IN ( SELECT element_id FROM $table WHERE element_type LIKE %s AND language_code <> %s )", $wpdb->esc_like( 'tax_' ) . '%', bires_lang_default() ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name
    return $clauses;
}
add_filter( 'terms_clauses', 'bires_lang_filter_terms' );
