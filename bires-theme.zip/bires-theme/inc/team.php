<?php

function bires_team_linkedin( $member_id ) {
    foreach ( bires_rows( 'team_socials', $member_id ) as $row ) {
        if ( ! empty( $row['url'] ) && false !== stripos( $row['url'], 'linkedin.com' ) ) {
            return $row['url'];
        }
    }
    return '';
}

function bires_team_members( $group = null ) {
    $args = [
        'suppress_filters' => false,
        'post_type'      => 'team',
        'posts_per_page' => -1,
        'orderby'        => [ 'menu_order' => 'ASC', 'title' => 'ASC' ],
    ];
    $members = get_posts( $args );
    if ( null === $group ) {
        return $members;
    }
    return array_values( array_filter( $members, function ( $member ) use ( $group ) {
        $member_group = bires_field( 'team_group', $member->ID );
        $member_group = $member_group ? $member_group : 'team';
        return $member_group === $group;
    } ) );
}

/** Прапори 48×48 (обрізаються в коло): статистика «Команди» і вибір коду країни у формах. */
function bires_flag_shapes() {
    return [
        'ua' => '<rect width="48" height="24" fill="#005BBB"/><rect y="24" width="48" height="24" fill="#FFD500"/>',
        'pl' => '<rect width="48" height="24" fill="#F7FCFF"/><rect y="24" width="48" height="24" fill="#C51918"/>',
        'lv' => '<rect width="48" height="48" fill="#C51918"/><rect y="19" width="48" height="10" fill="#F7FCFF"/>',
        'ee' => '<rect width="48" height="16" fill="#40A8FF"/><rect y="16" width="48" height="16" fill="#272727"/><rect y="32" width="48" height="16" fill="#F7FCFF"/>',
        'fr' => '<rect width="16" height="48" fill="#2E42A5"/><rect x="16" width="16" height="48" fill="#F7FCFF"/><rect x="32" width="16" height="48" fill="#F50100"/>',
        'de' => '<rect width="48" height="16" fill="#272727"/><rect y="16" width="48" height="16" fill="#E31D1C"/><rect y="32" width="48" height="16" fill="#FFD018"/>',
        'it' => '<rect width="16" height="48" fill="#009246"/><rect x="16" width="16" height="48" fill="#F7FCFF"/><rect x="32" width="16" height="48" fill="#CE2B37"/>',
        'nl' => '<rect width="48" height="16" fill="#C51918"/><rect y="16" width="48" height="16" fill="#F7FCFF"/><rect y="32" width="48" height="16" fill="#2E42A5"/>',
        'gb' => '<rect width="48" height="48" fill="#2E42A5"/><path d="M0 0l48 48M48 0 0 48" stroke="#F7FCFF" stroke-width="8"/><path d="M0 0l48 48M48 0 0 48" stroke="#F50100" stroke-width="3"/><path d="M24 0v48M0 24h48" stroke="#F7FCFF" stroke-width="12"/><path d="M24 0v48M0 24h48" stroke="#F50100" stroke-width="6"/>',
        'us' => '<rect width="48" height="48" fill="#F7FCFF"/><path d="M0 4h48M0 12h48M0 20h48M0 28h48M0 36h48M0 44h48" stroke="#E31D1C" stroke-width="4"/><rect width="24" height="24" fill="#2E42A5"/>',
        'cy' => '<rect width="48" height="48" fill="#F7FCFF"/><path d="M12 22c4-6 14-8 24-6-2 4-6 6-10 7-5 1-9 2-14-1Z" fill="#F57A01"/><path d="M16 32c4 2 12 2 16 0" stroke="#006B49" stroke-width="2"/>',
        'at' => '<rect width="48" height="48" fill="#E31D1C"/><rect y="16" width="48" height="16" fill="#F7FCFF"/>',
        'be' => '<rect width="16" height="48" fill="#272727"/><rect x="16" width="16" height="48" fill="#FFD018"/><rect x="32" width="16" height="48" fill="#E31D1C"/>',
        'bg' => '<rect width="48" height="16" fill="#F7FCFF"/><rect y="16" width="48" height="16" fill="#009A49"/><rect y="32" width="48" height="16" fill="#D62612"/>',
        'gr' => '<rect width="48" height="48" fill="#4564F9"/><path d="M0 8h48M0 18.7h48M0 29.3h48M0 40h48" stroke="#F7FCFF" stroke-width="5.3"/><rect width="26.7" height="26.7" fill="#4564F9"/><path d="M10.7 0h5.3v26.7h-5.3zM0 10.7h26.7v5.3H0z" fill="#F7FCFF"/>',
        'ge' => '<rect width="48" height="48" fill="#F7FCFF"/><path d="M20 0h8v48h-8zM0 20h48v8H0z" fill="#E31D1C"/><path d="M10 7v8M6 11h8M38 7v8M34 11h8M10 33v8M6 37h8M38 33v8M34 37h8" stroke="#E31D1C" stroke-width="2.5"/>',
        'dk' => '<rect width="48" height="48" fill="#C51918"/><path d="M15 0h7v48h-7zM0 20h48v7H0z" fill="#F7FCFF"/>',
        'il' => '<rect width="48" height="48" fill="#F7FCFF"/><path d="M0 8h48M0 40h48" stroke="#3D58DB" stroke-width="5"/><path d="M24 15l7.8 13.5H16.2ZM24 33l-7.8-13.5h15.6Z" fill="none" stroke="#3D58DB" stroke-width="2"/>',
        'ie' => '<rect width="16" height="48" fill="#009A49"/><rect x="16" width="16" height="48" fill="#F7FCFF"/><rect x="32" width="16" height="48" fill="#FF8A00"/>',
        'es' => '<rect width="48" height="48" fill="#C51918"/><rect y="12" width="48" height="24" fill="#FFD018"/>',
        'ca' => '<rect width="48" height="48" fill="#F7FCFF"/><rect width="12" height="48" fill="#E31D1C"/><rect x="36" width="12" height="48" fill="#E31D1C"/><path d="M24 12l2.5 5 3-1.5-1 7 4-3.5 1 2.5 3-.5-1.5 4.5 2 1-7 5 .5 2.5h-5.5V36h-2v-2.5H18l.5-2.5-7-5 2-1L12 20.5l3 .5 1-2.5 4 3.5-1-7 3 1.5Z" fill="#E31D1C"/>',
        'lt' => '<rect width="48" height="16" fill="#FDBA00"/><rect y="16" width="48" height="16" fill="#00764B"/><rect y="32" width="48" height="16" fill="#C51918"/>',
        'md' => '<rect width="16" height="48" fill="#2E42A5"/><rect x="16" width="16" height="48" fill="#FFD018"/><rect x="32" width="16" height="48" fill="#E31D1C"/><path d="M19 18h10v9c0 3-2.5 5-5 6-2.5-1-5-3-5-6Z" fill="#B47D3B"/>',
        'no' => '<rect width="48" height="48" fill="#E31D1C"/><path d="M13 0h12v48H13zM0 18h48v12H0z" fill="#F7FCFF"/><path d="M16 0h6v48h-6zM0 21h48v6H0z" fill="#2E42A5"/>',
        'ae' => '<rect width="48" height="48" fill="#F7FCFF"/><rect width="48" height="16" fill="#00732F"/><rect y="32" width="48" height="16" fill="#272727"/><rect width="14" height="48" fill="#E31D1C"/>',
        'pt' => '<rect width="48" height="48" fill="#E31D1C"/><rect width="19" height="48" fill="#00732F"/><circle cx="19" cy="24" r="8" fill="#FFD018"/><path d="M15 19h8v7c0 3-2 4-4 5-2-1-4-2-4-5Z" fill="#F7FCFF" stroke="#E31D1C" stroke-width="1.5"/>',
        'ro' => '<rect width="16" height="48" fill="#2E42A5"/><rect x="16" width="16" height="48" fill="#FFD018"/><rect x="32" width="16" height="48" fill="#E31D1C"/>',
        'sk' => '<rect width="48" height="16" fill="#F7FCFF"/><rect y="16" width="48" height="16" fill="#2E42A5"/><rect y="32" width="48" height="16" fill="#E31D1C"/><path d="M9 11h16v13c0 6-4 9-8 11-4-2-8-5-8-11Z" fill="#E31D1C" stroke="#F7FCFF" stroke-width="1.5"/><path d="M17 14v17M13 18h8M12 22h10" stroke="#F7FCFF" stroke-width="2"/><path d="M10.5 29c2-2 4.5-2 6.5 0 2-2 4.5-2 6.5 0L22 32h-10Z" fill="#2E42A5"/>',
        'tr' => '<rect width="48" height="48" fill="#E31D1C"/><circle cx="20" cy="24" r="10" fill="#F7FCFF"/><circle cx="23" cy="24" r="8" fill="#E31D1C"/><path d="m33 19 1.5 4.3H39l-3.6 2.6 1.4 4.3-3.8-2.7-3.6 2.6 1.4-4.2-3.6-2.6h4.4Z" fill="#F7FCFF"/>',
        'hu' => '<rect width="48" height="16" fill="#E31D1C"/><rect y="16" width="48" height="16" fill="#F7FCFF"/><rect y="32" width="48" height="16" fill="#3D8E33"/>',
        'fi' => '<rect width="48" height="48" fill="#F7FCFF"/><path d="M14 0h9v48h-9zM0 19h48v9H0z" fill="#2E42A5"/>',
        'cz' => '<rect width="48" height="24" fill="#F7FCFF"/><rect y="24" width="48" height="24" fill="#E31D1C"/><path d="M0 0l26 24L0 48Z" fill="#11457E"/>',
        'ch' => '<rect width="48" height="48" fill="#E31D1C"/><path d="M20 10h8v10h10v8H28v10h-8V28H10v-8h10Z" fill="#F7FCFF"/>',
        'se' => '<rect width="48" height="48" fill="#3D58DB"/><path d="M15 0h7v48h-7zM0 20h48v7H0z" fill="#FECA00"/>',
    ];
}

function bires_flag_svg( $code ) {
    $flags = bires_flag_shapes();
    $code = strtolower( trim( $code ) );
    if ( ! isset( $flags[ $code ] ) ) {
        return '';
    }
    return '<svg viewBox="0 0 48 48" width="48" height="48" aria-hidden="true" focusable="false"><clipPath id="flag-clip-' . esc_attr( $code ) . '"><circle cx="24" cy="24" r="24"/></clipPath><g clip-path="url(#flag-clip-' . esc_attr( $code ) . ')">' . $flags[ $code ] . '</g></svg>';
}
