<?php

function bires_team_linkedin( $member_id ) {
    foreach ( bires_rows( 'team_socials', $member_id ) as $row ) {
        if ( ! empty( $row['url'] ) && false !== stripos( $row['url'], 'linkedin.com' ) ) {
            return $row['url'];
        }
    }
    return '';
}

function bires_team_members( $group = null ) {
    $args = [
        'suppress_filters' => false,
        'post_type'      => 'team',
        'posts_per_page' => -1,
        'orderby'        => [ 'menu_order' => 'ASC', 'title' => 'ASC' ],
    ];
    $members = get_posts( $args );
    if ( null === $group ) {
        return $members;
    }
    return array_values( array_filter( $members, function ( $member ) use ( $group ) {
        $member_group = bires_field( 'team_group', $member->ID );
        $member_group = $member_group ? $member_group : 'team';
        return $member_group === $group;
    } ) );
}

function bires_flag_svg( $code ) {
    $flags = [
        'ua' => '<rect width="48" height="24" fill="#005BBB"/><rect y="24" width="48" height="24" fill="#FFD500"/>',
        'pl' => '<rect width="48" height="24" fill="#F7FCFF"/><rect y="24" width="48" height="24" fill="#C51918"/>',
        'lv' => '<rect width="48" height="48" fill="#C51918"/><rect y="19" width="48" height="10" fill="#F7FCFF"/>',
        'ee' => '<rect width="48" height="16" fill="#40A8FF"/><rect y="16" width="48" height="16" fill="#272727"/><rect y="32" width="48" height="16" fill="#F7FCFF"/>',
        'fr' => '<rect width="16" height="48" fill="#2E42A5"/><rect x="16" width="16" height="48" fill="#F7FCFF"/><rect x="32" width="16" height="48" fill="#F50100"/>',
        'de' => '<rect width="48" height="16" fill="#272727"/><rect y="16" width="48" height="16" fill="#E31D1C"/><rect y="32" width="48" height="16" fill="#FFD018"/>',
        'it' => '<rect width="16" height="48" fill="#009246"/><rect x="16" width="16" height="48" fill="#F7FCFF"/><rect x="32" width="16" height="48" fill="#CE2B37"/>',
        'nl' => '<rect width="48" height="16" fill="#C51918"/><rect y="16" width="48" height="16" fill="#F7FCFF"/><rect y="32" width="48" height="16" fill="#2E42A5"/>',
        'gb' => '<rect width="48" height="48" fill="#2E42A5"/><path d="M0 0l48 48M48 0 0 48" stroke="#F7FCFF" stroke-width="8"/><path d="M0 0l48 48M48 0 0 48" stroke="#F50100" stroke-width="3"/><path d="M24 0v48M0 24h48" stroke="#F7FCFF" stroke-width="12"/><path d="M24 0v48M0 24h48" stroke="#F50100" stroke-width="6"/>',
        'us' => '<rect width="48" height="48" fill="#F7FCFF"/><path d="M0 4h48M0 12h48M0 20h48M0 28h48M0 36h48M0 44h48" stroke="#E31D1C" stroke-width="4"/><rect width="24" height="24" fill="#2E42A5"/>',
        'cy' => '<rect width="48" height="48" fill="#F7FCFF"/><path d="M12 22c4-6 14-8 24-6-2 4-6 6-10 7-5 1-9 2-14-1Z" fill="#F57A01"/><path d="M16 32c4 2 12 2 16 0" stroke="#006B49" stroke-width="2"/>',
    ];
    $code = strtolower( trim( $code ) );
    if ( ! isset( $flags[ $code ] ) ) {
        return '';
    }
    return '<svg viewBox="0 0 48 48" width="48" height="48" aria-hidden="true" focusable="false"><clipPath id="flag-clip-' . esc_attr( $code ) . '"><circle cx="24" cy="24" r="24"/></clipPath><g clip-path="url(#flag-clip-' . esc_attr( $code ) . ')">' . $flags[ $code ] . '</g></svg>';
}
