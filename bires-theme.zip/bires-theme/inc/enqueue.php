<?php

function bires_enqueue_scripts() {
    $uri = get_template_directory_uri();

    wp_enqueue_style(
        'bires-fonts',
        'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;0,700;1,400&family=Manrope:wght@400;500;600;700&display=swap',
        [],
        null
    );

    wp_enqueue_style( 'bires-main', $uri . '/assets/css/main.css', [ 'bires-fonts' ], BIRES_VERSION );
    wp_enqueue_style( 'bires-header', $uri . '/assets/css/header.css', [ 'bires-main' ], BIRES_VERSION );
    wp_enqueue_style( 'bires-style', get_stylesheet_uri(), [ 'bires-main' ], BIRES_VERSION );
    wp_enqueue_style( 'bires-footer', $uri . '/assets/css/footer.css', [ 'bires-main' ], BIRES_VERSION );
    wp_enqueue_style( 'bires-components', $uri . '/assets/css/components.css', [ 'bires-main' ], BIRES_VERSION );

    wp_enqueue_script( 'bires-header', $uri . '/assets/js/header.js', [], BIRES_VERSION, true );

    if ( is_home() || is_category() || is_tag() || is_singular( 'post' ) ) {
        wp_enqueue_style( 'bires-blog', $uri . '/assets/css/blog.css', [ 'bires-components' ], BIRES_VERSION );
    }

    if ( is_singular( 'post' ) ) {
        wp_enqueue_style( 'bires-services', $uri . '/assets/css/services.css', [ 'bires-main' ], BIRES_VERSION );
        wp_enqueue_script( 'bires-article', $uri . '/assets/js/article.js', [], BIRES_VERSION, true );
    }

    if ( is_post_type_archive( 'team' ) || is_singular( 'team' ) ) {
        wp_enqueue_style( 'bires-services', $uri . '/assets/css/services.css', [ 'bires-main' ], BIRES_VERSION );
        wp_enqueue_style( 'bires-blog', $uri . '/assets/css/blog.css', [ 'bires-components' ], BIRES_VERSION );
        wp_enqueue_style( 'bires-team', $uri . '/assets/css/team.css', [ 'bires-components' ], BIRES_VERSION );
        wp_enqueue_script( 'bires-team', $uri . '/assets/js/team.js', [], BIRES_VERSION, true );
    }

    if ( is_page_template( 'page-templates/about.php' ) ) {
        wp_enqueue_style( 'bires-services', $uri . '/assets/css/services.css', [ 'bires-main' ], BIRES_VERSION );
        wp_enqueue_style( 'bires-faq', $uri . '/assets/css/faq.css', [ 'bires-main' ], BIRES_VERSION );
        wp_enqueue_style( 'bires-team', $uri . '/assets/css/team.css', [ 'bires-components' ], BIRES_VERSION );
        wp_enqueue_style( 'bires-cases', $uri . '/assets/css/cases.css', [ 'bires-main' ], BIRES_VERSION );
        wp_enqueue_style( 'bires-about', $uri . '/assets/css/about.css', [ 'bires-team' ], BIRES_VERSION );
        wp_enqueue_script( 'bires-cases', $uri . '/assets/js/cases.js', [], BIRES_VERSION, true );
    }

    if ( is_singular( 'post' ) || bires_is_service_page() || is_front_page() || is_post_type_archive( 'team' ) || is_page_template( [ 'page-templates/contact.php', 'page-templates/cases.php', 'page-templates/about.php' ] ) ) {
        wp_enqueue_script( 'bires-slider', $uri . '/assets/js/slider.js', [], BIRES_VERSION, true );
    }

    if ( is_page_template( BIRES_SERVICES_TEMPLATE ) || bires_is_service_page() ) {
        wp_enqueue_style( 'bires-services', $uri . '/assets/css/services.css', [ 'bires-main' ], BIRES_VERSION );
        wp_enqueue_style( 'bires-faq', $uri . '/assets/css/faq.css', [ 'bires-main' ], BIRES_VERSION );
        wp_enqueue_script( 'bires-faq', $uri . '/assets/js/faq.js', [], BIRES_VERSION, true );
    }

    if ( bires_is_service_page() ) {
        wp_enqueue_style( 'bires-service', $uri . '/assets/css/service.css', [ 'bires-services' ], BIRES_VERSION );
        wp_enqueue_script( 'bires-service', $uri . '/assets/js/service.js', [], BIRES_VERSION, true );
    }

    if ( is_page_template( 'page-templates/cases.php' ) ) {
        wp_enqueue_style( 'bires-services', $uri . '/assets/css/services.css', [ 'bires-main' ], BIRES_VERSION );
        wp_enqueue_style( 'bires-cases', $uri . '/assets/css/cases.css', [ 'bires-main' ], BIRES_VERSION );
        wp_enqueue_script( 'bires-cases', $uri . '/assets/js/cases.js', [], BIRES_VERSION, true );
    }

    if ( is_front_page() ) {
        wp_enqueue_style( 'bires-services', $uri . '/assets/css/services.css', [ 'bires-main' ], BIRES_VERSION );
        wp_enqueue_style( 'bires-home', $uri . '/assets/css/home.css', [ 'bires-components' ], BIRES_VERSION );
        wp_enqueue_script( 'bires-home', $uri . '/assets/js/home.js', [], BIRES_VERSION, true );
    }

    if ( is_page_template( 'page-templates/sitemap.php' ) ) {
        wp_enqueue_style( 'bires-blog', $uri . '/assets/css/blog.css', [ 'bires-components' ], BIRES_VERSION );
        wp_enqueue_style( 'bires-sitemap', $uri . '/assets/css/sitemap.css', [ 'bires-main' ], BIRES_VERSION );
    }

    if ( is_page_template( 'page-templates/contact.php' ) ) {
        wp_enqueue_style( 'bires-contact', $uri . '/assets/css/contact.css', [ 'bires-main' ], BIRES_VERSION );
    }

    if ( is_page_template( BIRES_SERVICES_TEMPLATE ) ) {
        wp_enqueue_script( 'bires-services', $uri . '/assets/js/services-filter.js', [], BIRES_VERSION, true );
    }
}
add_action( 'wp_enqueue_scripts', 'bires_enqueue_scripts' );

function bires_resource_hints( $urls, $relation ) {
    if ( 'preconnect' === $relation ) {
        $urls[] = 'https://fonts.googleapis.com';
        $urls[] = [ 'href' => 'https://fonts.gstatic.com', 'crossorigin' ];
    }
    return $urls;
}
add_filter( 'wp_resource_hints', 'bires_resource_hints', 10, 2 );
