<?php

function bires_handle_contact_form() {
    $back = wp_get_referer() ? wp_get_referer() : home_url( '/' );
    $back = remove_query_arg( 'bires_sent', $back );

    $valid_nonce = isset( $_POST['bires_contact_nonce'] )
        && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['bires_contact_nonce'] ) ), 'bires_contact' );

    if ( ! $valid_nonce || ! empty( $_POST['website'] ) ) {
        wp_safe_redirect( add_query_arg( 'bires_sent', 'error', $back ) . '#contact' );
        exit;
    }

    $name  = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
    $phone = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
    $email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
    $extra = [];
    foreach ( [ 'client_type' => __( 'Хто звертається', 'bires-theme' ), 'practice' => __( 'Галузь права', 'bires-theme' ) ] as $key => $label ) {
        if ( ! empty( $_POST[ $key ] ) ) {
            $extra[] = $label . ': ' . sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
        }
    }

    if ( '' === $name || '' === $phone ) {
        wp_safe_redirect( add_query_arg( 'bires_sent', 'error', $back ) . '#contact' );
        exit;
    }

    $to      = bires_option( 'contact_email', get_option( 'admin_email' ) );
    $subject = sprintf( '[%s] %s', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), __( 'Новий запит з сайту', 'bires-theme' ) );
    $lines   = array_merge(
        [
            __( 'Ім’я', 'bires-theme' ) . ': ' . $name,
            __( 'Телефон', 'bires-theme' ) . ': +380 ' . $phone,
            'Email: ' . ( $email ? $email : '—' ),
        ],
        $extra,
        [ __( 'Сторінка', 'bires-theme' ) . ': ' . esc_url_raw( $back ) ]
    );
    $headers = $email ? [ 'Reply-To: ' . $name . ' <' . $email . '>' ] : [];

    $sent = wp_mail( $to, $subject, implode( "\n", $lines ), $headers );

    wp_safe_redirect( add_query_arg( 'bires_sent', $sent ? 'ok' : 'error', $back ) . '#contact' );
    exit;
}
add_action( 'admin_post_nopriv_bires_contact', 'bires_handle_contact_form' );
add_action( 'admin_post_bires_contact', 'bires_handle_contact_form' );
