<?php

/** Коди країн для поля телефону: Україна першою, далі за абеткою, «Інша країна» — останньою. */
function bires_phone_countries() {
    return [
        'ua'    => [ __( 'Україна', 'bires-theme' ), '+380' ],
        'at'    => [ __( 'Австрія', 'bires-theme' ), '+43' ],
        'be'    => [ __( 'Бельгія', 'bires-theme' ), '+32' ],
        'bg'    => [ __( 'Болгарія', 'bires-theme' ), '+359' ],
        'gb'    => [ __( 'Велика Британія', 'bires-theme' ), '+44' ],
        'gr'    => [ __( 'Греція', 'bires-theme' ), '+30' ],
        'ge'    => [ __( 'Грузія', 'bires-theme' ), '+995' ],
        'dk'    => [ __( 'Данія', 'bires-theme' ), '+45' ],
        'ee'    => [ __( 'Естонія', 'bires-theme' ), '+372' ],
        'il'    => [ __( 'Ізраїль', 'bires-theme' ), '+972' ],
        'ie'    => [ __( 'Ірландія', 'bires-theme' ), '+353' ],
        'es'    => [ __( 'Іспанія', 'bires-theme' ), '+34' ],
        'it'    => [ __( 'Італія', 'bires-theme' ), '+39' ],
        'ca'    => [ __( 'Канада', 'bires-theme' ), '+1' ],
        'cy'    => [ __( 'Кіпр', 'bires-theme' ), '+357' ],
        'lv'    => [ __( 'Латвія', 'bires-theme' ), '+371' ],
        'lt'    => [ __( 'Литва', 'bires-theme' ), '+370' ],
        'md'    => [ __( 'Молдова', 'bires-theme' ), '+373' ],
        'nl'    => [ __( 'Нідерланди', 'bires-theme' ), '+31' ],
        'de'    => [ __( 'Німеччина', 'bires-theme' ), '+49' ],
        'no'    => [ __( 'Норвегія', 'bires-theme' ), '+47' ],
        'ae'    => [ __( 'ОАЕ', 'bires-theme' ), '+971' ],
        'pl'    => [ __( 'Польща', 'bires-theme' ), '+48' ],
        'pt'    => [ __( 'Португалія', 'bires-theme' ), '+351' ],
        'ro'    => [ __( 'Румунія', 'bires-theme' ), '+40' ],
        'sk'    => [ __( 'Словаччина', 'bires-theme' ), '+421' ],
        'us'    => [ __( 'США', 'bires-theme' ), '+1' ],
        'tr'    => [ __( 'Туреччина', 'bires-theme' ), '+90' ],
        'hu'    => [ __( 'Угорщина', 'bires-theme' ), '+36' ],
        'fi'    => [ __( 'Фінляндія', 'bires-theme' ), '+358' ],
        'fr'    => [ __( 'Франція', 'bires-theme' ), '+33' ],
        'cz'    => [ __( 'Чехія', 'bires-theme' ), '+420' ],
        'ch'    => [ __( 'Швейцарія', 'bires-theme' ), '+41' ],
        'se'    => [ __( 'Швеція', 'bires-theme' ), '+46' ],
        'other' => [ __( 'Інша країна', 'bires-theme' ), '+' ],
    ];
}

/** Круглий прапор 24px для списку кодів (коло — через CSS обгортки). */
function bires_flag_icon( $code ) {
    $flags = bires_flag_shapes();
    if ( isset( $flags[ $code ] ) ) {
        return '<svg viewBox="0 0 48 48" width="24" height="24" aria-hidden="true" focusable="false">' . $flags[ $code ] . '</svg>';
    }
    return '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.5"/><path d="M3 12h18M12 3c2.5 2.5 3.6 5.6 3.6 9s-1.1 6.5-3.6 9c-2.5-2.5-3.6-5.6-3.6-9S9.5 5.5 12 3Z" stroke="currentColor" stroke-width="1.5"/></svg>';
}

function bires_dd_chevron( $class, $size = 24 ) {
    return '<svg class="' . esc_attr( $class ) . '" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m6 9 6 6 6-6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
}

/**
 * Поле коду країни: нативний <select> (працює і без JS) + власний список з прапорами й пошуком.
 * $button_class — клас «пігулки» конкретної форми.
 */
function bires_phone_code_dropdown( $form_id, $button_class, $theme = 'light' ) {
    $countries = bires_phone_countries();
    $id        = $form_id . '-code';
    $current   = 'ua';
    ob_start();
    ?>
    <div class="dd dd--phone dd--<?php echo esc_attr( $theme ); ?>" data-dd>
        <select class="dd__native" id="<?php echo esc_attr( $id ); ?>" name="phone_code" aria-label="<?php esc_attr_e( 'Код країни', 'bires-theme' ); ?>">
            <?php foreach ( $countries as $code => $country ) : ?>
                <option value="<?php echo esc_attr( $code ); ?>"<?php selected( $code, $current ); ?>><?php echo esc_html( $country[0] . ' ' . $country[1] ); ?></option>
            <?php endforeach; ?>
        </select>
        <button type="button" class="dd__button <?php echo esc_attr( $button_class ); ?>" id="<?php echo esc_attr( $id ); ?>-btn" aria-haspopup="listbox" aria-expanded="false" aria-controls="<?php echo esc_attr( $id ); ?>-list">
            <span class="dd__flag"><?php echo bires_flag_icon( $current ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
            <span class="dd__value"><?php echo esc_html( $countries[ $current ][1] ); ?></span>
            <?php echo bires_dd_chevron( 'dd__chevron', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?>
        </button>
        <div class="dd__panel" hidden>
            <div class="dd__search-wrap">
                <svg class="dd__search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.5"/><path d="m20 20-4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                <input type="text" class="dd__search" role="combobox" aria-expanded="true" aria-autocomplete="list" placeholder="<?php esc_attr_e( 'Країна або код', 'bires-theme' ); ?>" aria-label="<?php esc_attr_e( 'Пошук країни або коду', 'bires-theme' ); ?>" aria-controls="<?php echo esc_attr( $id ); ?>-list" autocomplete="off" spellcheck="false">
            </div>
            <ul class="dd__list" id="<?php echo esc_attr( $id ); ?>-list" role="listbox" tabindex="-1" aria-label="<?php esc_attr_e( 'Код країни', 'bires-theme' ); ?>">
                <?php foreach ( $countries as $code => $country ) : ?>
                    <li class="dd__option" role="option" id="<?php echo esc_attr( $id . '-' . $code ); ?>" data-value="<?php echo esc_attr( $code ); ?>" data-dial="<?php echo esc_attr( $country[1] ); ?>" data-search="<?php echo esc_attr( mb_strtolower( $country[0] ) . ' ' . $country[1] . ' ' . ltrim( $country[1], '+' ) ); ?>" aria-selected="<?php echo $code === $current ? 'true' : 'false'; ?>">
                        <span class="dd__flag"><?php echo bires_flag_icon( $code ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?></span>
                        <span class="dd__name"><?php echo esc_html( $country[0] ); ?></span>
                        <span class="dd__dial"><?php echo esc_html( 'other' === $code ? '' : $country[1] ); ?></span>
                    </li>
                <?php endforeach; ?>
                <li class="dd__empty" role="presentation" hidden><?php esc_html_e( 'Нічого не знайдено', 'bires-theme' ); ?></li>
            </ul>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Звичайний випадний список у стилі сайту. $groups: [ [ 'label' => '', 'options' => [ value => label ] ], ... ].
 * Порожнє значення $placeholder показується, доки нічого не обрано.
 */
function bires_dropdown( $id, $name, $groups, $placeholder = '', $theme = 'dark' ) {
    $check = '<svg class="dd__check" width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    $first = '';
    foreach ( $groups as $group ) {
        foreach ( $group['options'] as $value => $label ) {
            $first = [ $value, $label ];
            break 2;
        }
    }
    $current_label = $placeholder ? $placeholder : ( $first ? $first[1] : '' );
    $n             = 0;
    ob_start();
    ?>
    <div class="dd dd--select dd--<?php echo esc_attr( $theme ); ?><?php echo $placeholder ? ' is-placeholder' : ''; ?>" data-dd<?php echo $placeholder ? ' data-placeholder="' . esc_attr( $placeholder ) . '"' : ''; ?>>
        <select class="dd__native" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>">
            <?php if ( $placeholder ) : ?>
                <option value=""><?php echo esc_html( $placeholder ); ?></option>
            <?php endif; ?>
            <?php foreach ( $groups as $group ) : ?>
                <?php if ( ! empty( $group['label'] ) ) : ?><optgroup label="<?php echo esc_attr( $group['label'] ); ?>"><?php endif; ?>
                <?php foreach ( $group['options'] as $value => $label ) : ?>
                    <option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
                <?php endforeach; ?>
                <?php if ( ! empty( $group['label'] ) ) : ?></optgroup><?php endif; ?>
            <?php endforeach; ?>
        </select>
        <button type="button" class="dd__button" id="<?php echo esc_attr( $id ); ?>-btn" aria-haspopup="listbox" aria-expanded="false" aria-controls="<?php echo esc_attr( $id ); ?>-list">
            <span class="dd__value"><?php echo esc_html( $current_label ); ?></span>
            <?php echo bires_dd_chevron( 'dd__chevron' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?>
        </button>
        <div class="dd__panel" hidden>
            <ul class="dd__list" id="<?php echo esc_attr( $id ); ?>-list" role="listbox" tabindex="-1">
                <?php foreach ( $groups as $g => $group ) : ?>
                    <?php if ( ! empty( $group['label'] ) ) : ?>
                        <li class="dd__group" role="presentation"><?php echo esc_html( $group['label'] ); ?></li>
                    <?php endif; ?>
                    <?php foreach ( $group['options'] as $value => $label ) : ?>
                        <li class="dd__option" role="option" id="<?php echo esc_attr( $id . '-' . ( ++$n ) ); ?>" data-value="<?php echo esc_attr( $value ); ?>" aria-selected="<?php echo ( ! $placeholder && $first && (string) $first[0] === (string) $value && 1 === $n ) ? 'true' : 'false'; ?>">
                            <span class="dd__name"><?php echo esc_html( $label ); ?></span>
                            <?php echo $check; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?>
                        </li>
                    <?php endforeach; ?>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

function bires_handle_contact_form() {
    $back = wp_get_referer() ? wp_get_referer() : home_url( '/' );
    $back = remove_query_arg( 'bires_sent', $back );

    $valid_nonce = isset( $_POST['bires_contact_nonce'] )
        && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['bires_contact_nonce'] ) ), 'bires_contact' );

    if ( ! $valid_nonce || ! empty( $_POST['website'] ) ) {
        wp_safe_redirect( add_query_arg( 'bires_sent', 'error', $back ) . '#contact' );
        exit;
    }

    $name  = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
    $phone = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
    $email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
    $codes = bires_phone_countries();
    $code  = isset( $_POST['phone_code'] ) ? sanitize_key( wp_unslash( $_POST['phone_code'] ) ) : 'ua';
    $code  = isset( $codes[ $code ] ) ? $code : 'ua';
    $extra = [];
    foreach ( [ 'client_type' => __( 'Хто звертається', 'bires-theme' ), 'practice' => __( 'Галузь права', 'bires-theme' ) ] as $key => $label ) {
        if ( ! empty( $_POST[ $key ] ) ) {
            $extra[] = $label . ': ' . sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
        }
    }

    if ( '' === $name || '' === $phone ) {
        wp_safe_redirect( add_query_arg( 'bires_sent', 'error', $back ) . '#contact' );
        exit;
    }

    $to      = bires_option( 'contact_email', get_option( 'admin_email' ) );
    $subject = sprintf( '[%s] %s', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), __( 'Новий запит з сайту', 'bires-theme' ) );
    $lines   = array_merge(
        [
            __( 'Ім’я', 'bires-theme' ) . ': ' . $name,
            __( 'Телефон', 'bires-theme' ) . ': ' . ( 'other' === $code ? $phone : $codes[ $code ][1] . ' ' . $phone ) . ' (' . $codes[ $code ][0] . ')',
            'Email: ' . ( $email ? $email : '—' ),
        ],
        $extra,
        [ __( 'Сторінка', 'bires-theme' ) . ': ' . esc_url_raw( $back ) ]
    );
    $headers = $email ? [ 'Reply-To: ' . $name . ' <' . $email . '>' ] : [];

    $sent = wp_mail( $to, $subject, implode( "\n", $lines ), $headers );

    wp_safe_redirect( add_query_arg( 'bires_sent', $sent ? 'ok' : 'error', $back ) . '#contact' );
    exit;
}
add_action( 'admin_post_nopriv_bires_contact', 'bires_handle_contact_form' );
add_action( 'admin_post_bires_contact', 'bires_handle_contact_form' );
