<?php

function bires_setup() {
    load_theme_textdomain( 'bires-theme', get_template_directory() . '/languages' );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'script',
        'style',
    ] );

    register_nav_menus( [
        'primary'         => __( 'Головне меню', 'bires-theme' ),
        'footer_services' => __( 'Футер: ТОП-5 послуг', 'bires-theme' ),
        'footer_company'  => __( 'Футер: Компанія', 'bires-theme' ),
    ] );
}
add_action( 'after_setup_theme', 'bires_setup' );
