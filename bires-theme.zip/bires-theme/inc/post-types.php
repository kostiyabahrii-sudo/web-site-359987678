<?php

function bires_register_post_types() {
    register_post_type( 'team', [
        'labels'       => [
            'name'          => __( 'Команда', 'bires-theme' ),
            'singular_name' => __( 'Член команди', 'bires-theme' ),
            'add_new_item'  => __( 'Додати члена команди', 'bires-theme' ),
            'edit_item'     => __( 'Редагувати члена команди', 'bires-theme' ),
            'all_items'     => __( 'Уся команда', 'bires-theme' ),
        ],
        'public'       => true,
        'has_archive'  => 'komanda',
        'rewrite'      => [ 'slug' => 'komanda', 'with_front' => false ],
        'menu_icon'    => 'dashicons-groups',
        'menu_position' => 21,
        'supports'     => [ 'title', 'editor', 'thumbnail', 'page-attributes' ],
        'show_in_rest' => true,
    ] );

    register_post_type( 'case', [
        'labels'             => [
            'name'          => __( 'Кейси', 'bires-theme' ),
            'singular_name' => __( 'Кейс', 'bires-theme' ),
            'add_new_item'  => __( 'Додати кейс', 'bires-theme' ),
            'edit_item'     => __( 'Редагувати кейс', 'bires-theme' ),
            'all_items'     => __( 'Усі кейси', 'bires-theme' ),
        ],
        'public'             => false,
        'show_ui'            => true,
        'show_in_nav_menus'  => false,
        'menu_icon'          => 'dashicons-portfolio',
        'menu_position'      => 22,
        'supports'           => [ 'title', 'thumbnail', 'page-attributes' ],
        'show_in_rest'       => true,
    ] );

    register_taxonomy( 'service_category', [ 'page' ], [
        'labels'            => [
            'name'          => __( 'Категорії послуг', 'bires-theme' ),
            'singular_name' => __( 'Категорія послуги', 'bires-theme' ),
        ],
        'public'            => false,
        'show_ui'           => true,
        'show_in_rest'      => true,
        'show_admin_column' => true,
        'hierarchical'      => true,
        'rewrite'           => false,
        'query_var'         => false,
    ] );
}
add_action( 'init', 'bires_register_post_types' );

function bires_team_archive_order( $query ) {
    if ( ! is_admin() && $query->is_main_query() && $query->is_post_type_archive( 'team' ) ) {
        $query->set( 'orderby', [ 'menu_order' => 'ASC', 'title' => 'ASC' ] );
        $query->set( 'posts_per_page', -1 );
    }
}
add_action( 'pre_get_posts', 'bires_team_archive_order' );

function bires_flush_rewrites_on_switch() {
    bires_register_post_types();
    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'bires_flush_rewrites_on_switch' );
