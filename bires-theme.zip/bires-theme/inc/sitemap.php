<?php

define( 'BIRES_SITEMAP_TEMPLATE', 'page-templates/sitemap.php' );
define( 'BIRES_SITEMAP_PER_PAGE', 150 );

function bires_sitemap_is_noindex( $post_id ) {
    return '1' === (string) get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true );
}

function bires_sitemap_page_items( $pages ) {
    $items  = [];
    $depths = [];
    foreach ( $pages as $page ) {
        $parent              = (int) $page->post_parent;
        $depths[ $page->ID ] = ( $parent && isset( $depths[ $parent ] ) ) ? $depths[ $parent ] + 1 : 0;
        if ( bires_sitemap_is_noindex( $page->ID ) ) {
            continue;
        }
        $items[] = [
            'title' => get_the_title( $page ),
            'url'   => get_permalink( $page ),
            'depth' => $depths[ $page->ID ],
        ];
    }
    return $items;
}

function bires_sitemap_groups() {
    $lang      = apply_filters( 'wpml_current_language', null );
    $cache_key = 'bires_sitemap_' . BIRES_VERSION . '_' . (int) get_option( 'bires_sitemap_version', 1 ) . '_' . ( $lang ? $lang : 'default' );
    $groups    = get_transient( $cache_key );
    if ( is_array( $groups ) ) {
        return $groups;
    }

    $groups      = [];
    $services_id = bires_services_listing_id();
    $sitemap_ids = wp_list_pluck( get_pages( [ 'meta_key' => '_wp_page_template', 'meta_value' => BIRES_SITEMAP_TEMPLATE ] ), 'ID' );
    $service_pages = [];
    foreach ( bires_top_services() as $top ) {
        $service_pages[] = $top;
        foreach ( bires_sub_services( $top->ID ) as $sub ) {
            $service_pages[] = $sub;
        }
    }
    $service_ids = wp_list_pluck( $service_pages, 'ID' );

    $pages = get_pages( [
        'sort_column' => 'menu_order,post_title',
        'exclude'     => array_merge( $sitemap_ids, $service_ids, [ $services_id ] ),
    ] );
    $main = bires_sitemap_page_items( $pages );
    if ( $main ) {
        $groups[] = [ 'title' => __( 'Сторінки', 'bires-theme' ), 'items' => $main ];
    }

    if ( $services_id || $service_pages ) {
        $services = bires_sitemap_page_items( array_merge( $services_id ? [ get_post( $services_id ) ] : [], $service_pages ) );
        if ( $services ) {
            $groups[] = [ 'title' => __( 'Послуги', 'bires-theme' ), 'items' => $services ];
        }
    }

    $members = get_posts( [
        'suppress_filters' => false,
        'post_type'        => 'team',
        'posts_per_page'   => -1,
        'orderby'          => [ 'menu_order' => 'ASC', 'title' => 'ASC' ],
    ] );
    $team = [];
    foreach ( $members as $member ) {
        if ( ! bires_sitemap_is_noindex( $member->ID ) ) {
            $team[] = [ 'title' => get_the_title( $member ), 'url' => get_permalink( $member ), 'depth' => 0 ];
        }
    }
    if ( $team ) {
        array_unshift( $team, [ 'title' => __( 'Уся команда', 'bires-theme' ), 'url' => get_post_type_archive_link( 'team' ), 'depth' => 0 ] );
        $groups[] = [ 'title' => __( 'Команда', 'bires-theme' ), 'items' => $team ];
    }

    $by_category = [];
    $posts       = get_posts( [
        'suppress_filters' => false,
        'post_type'        => 'post',
        'posts_per_page'   => -1,
        'orderby'          => 'date',
        'order'            => 'DESC',
    ] );
    foreach ( $posts as $post ) {
        if ( bires_sitemap_is_noindex( $post->ID ) ) {
            continue;
        }
        $categories = get_the_category( $post->ID );
        $category   = $categories ? $categories[0] : null;
        $key        = $category ? $category->term_id : 0;
        if ( ! isset( $by_category[ $key ] ) ) {
            $by_category[ $key ] = [
                'title' => $category ? sprintf( /* translators: %s: category name */ __( 'Блог: %s', 'bires-theme' ), $category->name ) : __( 'Блог', 'bires-theme' ),
                'items' => $category ? [ [ 'title' => $category->name, 'url' => get_category_link( $category ), 'depth' => 0 ] ] : [],
            ];
        }
        $by_category[ $key ]['items'][] = [ 'title' => get_the_title( $post ), 'url' => get_permalink( $post ), 'depth' => $category ? 1 : 0 ];
    }
    $groups = array_merge( $groups, array_values( $by_category ) );

    $groups = apply_filters( 'bires_sitemap_groups', $groups );
    set_transient( $cache_key, $groups, DAY_IN_SECONDS );
    return $groups;
}

function bires_sitemap_paginate( $groups, $page ) {
    $chunks  = [];
    $current = -1;
    $count   = BIRES_SITEMAP_PER_PAGE;
    foreach ( $groups as $group ) {
        $continued = false;
        foreach ( $group['items'] as $item ) {
            if ( $count >= BIRES_SITEMAP_PER_PAGE ) {
                $chunks[] = [];
                $current++;
                $count = 0;
                if ( $continued ) {
                    $chunks[ $current ][] = [ 'title' => $group['title'], 'continued' => true, 'items' => [] ];
                }
            }
            if ( ! $continued ) {
                $chunks[ $current ][] = [ 'title' => $group['title'], 'continued' => false, 'items' => [] ];
                $continued            = true;
            }
            $last                                  = count( $chunks[ $current ] ) - 1;
            $chunks[ $current ][ $last ]['items'][] = $item;
            $count++;
        }
    }

    $total = max( 1, count( $chunks ) );
    $page  = min( max( 1, (int) $page ), $total );
    return [ isset( $chunks[ $page - 1 ] ) ? $chunks[ $page - 1 ] : [], $page, $total ];
}

function bires_sitemap_flush() {
    update_option( 'bires_sitemap_version', (int) get_option( 'bires_sitemap_version', 1 ) + 1, false );
}
add_action( 'save_post', 'bires_sitemap_flush' );
add_action( 'deleted_post', 'bires_sitemap_flush' );
add_action( 'edited_term', 'bires_sitemap_flush' );

function bires_sitemap_allow_page_number( $handled, $query ) {
    $page = (int) get_query_var( 'page' );
    if ( $handled || $page < 2 || ! $query->is_page() || BIRES_SITEMAP_TEMPLATE !== get_page_template_slug( $query->get_queried_object_id() ) ) {
        return $handled;
    }
    list( , $current ) = bires_sitemap_paginate( bires_sitemap_groups(), $page );
    if ( $current !== $page ) {
        return $handled;
    }
    status_header( 200 );
    return true;
}
add_filter( 'pre_handle_404', 'bires_sitemap_allow_page_number', 10, 2 );
