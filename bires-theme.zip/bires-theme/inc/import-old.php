<?php
/**
 * Імпорт контенту старого сайту bires.com.ua у новий сайт (дані лежать у темі: import/old-site.json.gz).
 * Інструменти → «Імпорт зі старого сайту». Працює порціями: сторінки, статті, рубрики, SEO-поля Yoast,
 * картинки, потім розкладає сторінки Elementor по блоках теми (inc/migration.php) і будує меню.
 */

define( 'BIRES_IMPORT_FILE', get_template_directory() . '/import/old-site.json.gz' );
define( 'BIRES_OLD_SITE', 'https://bires.com.ua' );

function bires_import_data() {
    static $data = null;
    if ( null === $data ) {
        wp_raise_memory_limit( 'admin' );
        $raw  = is_readable( BIRES_IMPORT_FILE ) ? gzdecode( file_get_contents( BIRES_IMPORT_FILE ) ) : '';
        $data = $raw ? json_decode( $raw, true ) : [];
        $data = is_array( $data ) ? $data : [];
    }
    return $data;
}

function bires_import_wpml() {
    return has_action( 'wpml_set_element_language_details' ) && apply_filters( 'wpml_default_language', null );
}

function bires_import_state( $state = null ) {
    if ( null !== $state ) {
        update_option( 'bires_import_state', $state, false );
        return $state;
    }
    $state = get_option( 'bires_import_state' );
    return is_array( $state ) ? $state : [];
}

function bires_import_map( $map = null ) {
    if ( null !== $map ) {
        update_option( 'bires_import_map', $map, false );
        return $map;
    }
    $map = get_option( 'bires_import_map' );
    return is_array( $map ) ? $map : [ 'post' => [], 'att' => [] ];
}

/** Мова запису у WPML (з перекладом, якщо є оригінал). */
function bires_import_set_lang( $id, $type, $lang, $source_id = 0 ) {
    if ( ! bires_import_wpml() ) {
        return;
    }
    $element_type = 'post_' . $type;
    $trid         = $source_id ? apply_filters( 'wpml_element_trid', null, $source_id, $element_type ) : null;
    do_action( 'wpml_set_element_language_details', [
        'element_id'           => $id,
        'element_type'         => $element_type,
        'trid'                 => $trid ? $trid : false,
        'language_code'        => $lang,
        'source_language_code' => $trid ? apply_filters( 'wpml_default_language', null ) : null,
    ] );
}

/** Прибирає значення полів ACF (лишки демо) зі сторінки, яку перезаписуємо. */
function bires_import_clear_acf( $id ) {
    foreach ( get_post_meta( $id ) as $key => $values ) {
        if ( '_' !== $key[0] && 0 === strpos( (string) get_post_meta( $id, '_' . $key, true ), 'field_' ) ) {
            delete_post_meta( $id, $key );
            delete_post_meta( $id, '_' . $key );
        }
    }
}

function bires_import_common_meta( $id, $item ) {
    foreach ( (array) $item['yoast'] as $key => $value ) {
        update_post_meta( $id, $key, wp_slash( $value ) );
    }
    update_post_meta( $id, '_bires_old_lang', $item['lang'] );
    update_post_meta( $id, '_bires_old_link', BIRES_OLD_SITE . ( 'ru' === $item['lang'] ? '/ru' : '' ) . $item['path'] );
    update_post_meta( $id, '_bires_old_id', $item['id'] );
}

/** Після встановлення мови WPML дозволяє однакові адреси в різних мовах — повертаємо стару адресу. */
function bires_import_fix_slug( $id, $slug ) {
    if ( $slug && get_post_field( 'post_name', $id ) !== $slug ) {
        wp_update_post( [ 'ID' => $id, 'post_name' => $slug ] );
    }
}

function bires_import_dates( $id, $item ) {
    global $wpdb;
    $modified = $item['modified'] ? $item['modified'] : $item['date'];
    $wpdb->update( $wpdb->posts, [
        'post_date'         => $item['date'],
        'post_date_gmt'     => get_gmt_from_date( $item['date'] ),
        'post_modified'     => $modified,
        'post_modified_gmt' => get_gmt_from_date( $modified ),
    ], [ 'ID' => $id ] );
    clean_post_cache( $id );
}

/* ---------- Кроки ---------- */

function bires_import_terms() {
    $data = bires_import_data();
    foreach ( [ 'category', 'post_tag' ] as $tax ) {
        $terms = isset( $data['terms'][ $tax ] ) ? $data['terms'][ $tax ] : [];
        for ( $pass = 0; $pass < 3; $pass++ ) {
            foreach ( $terms as $slug => $term ) {
                if ( get_term_by( 'slug', $slug, $tax ) ) {
                    continue;
                }
                $parent = 0;
                if ( $term['parent'] ) {
                    $p = get_term_by( 'slug', $term['parent'], $tax );
                    if ( ! $p ) {
                        continue;
                    }
                    $parent = $p->term_id;
                }
                wp_insert_term( $term['name'], $tax, [ 'slug' => $slug, 'parent' => $parent ] );
            }
        }
    }
    return __( 'рубрики й мітки', 'bires-theme' );
}

/** Сторінки: батьківські перед дочірніми; існуючу сторінку з тією ж адресою (демо) перезаписуємо. */
function bires_import_pages( $offset, $limit ) {
    $wpml  = bires_import_wpml();
    $pages = array_values( array_filter( bires_import_data()['pages'], function ( $p ) use ( $wpml ) {
        return $wpml || 'uk' === $p['lang'];
    } ) );
    usort( $pages, function ( $a, $b ) {
        return [ substr_count( trim( $a['path'], '/' ), '/' ), 'ru' === $a['lang'], $a['id'] ] <=> [ substr_count( trim( $b['path'], '/' ), '/' ), 'ru' === $b['lang'], $b['id'] ];
    } );
    $map = bires_import_map();
    foreach ( array_slice( $pages, $offset, $limit ) as $item ) {
        $id = isset( $map['post'][ $item['id'] ] ) && get_post( $map['post'][ $item['id'] ] ) ? $map['post'][ $item['id'] ] : 0;
        if ( ! $id && 'uk' === $item['lang'] && '/' !== $item['path'] ) {
            $existing = get_page_by_path( trim( $item['path'], '/' ) );
            $id       = $existing ? $existing->ID : 0;
        }
        $postarr = [
            'post_type'    => 'page',
            'post_status'  => 'publish',
            'post_title'   => $item['title'],
            'post_name'    => $item['slug'],
            'post_parent'  => isset( $map['post'][ $item['parent'] ] ) ? $map['post'][ $item['parent'] ] : 0,
            'menu_order'   => $item['order'],
            'post_content' => $item['content'],
        ];
        if ( $id ) {
            $postarr['ID'] = $id;
            bires_import_clear_acf( $id );
        }
        $id = wp_insert_post( wp_slash( $postarr ), true );
        if ( is_wp_error( $id ) ) {
            continue;
        }
        $map['post'][ $item['id'] ] = $id;
        update_post_meta( $id, '_wp_page_template', 'default' );
        foreach ( [ '_bires_migrated', '_bires_old_backup', '_bires_old_elementor_data', '_bires_old_content', '_bires_mig_run', '_bires_mig_kind', '_bires_mig_listed' ] as $key ) {
            delete_post_meta( $id, $key );
        }
        if ( $item['elementor'] ) {
            update_post_meta( $id, '_elementor_data', wp_slash( wp_json_encode( $item['elementor'], JSON_UNESCAPED_UNICODE ) ) );
        } else {
            delete_post_meta( $id, '_elementor_data' );
        }
        bires_import_common_meta( $id, $item );
        bires_import_set_lang( $id, 'page', $item['lang'], $item['tr'] && isset( $map['post'][ $item['tr'] ] ) ? $map['post'][ $item['tr'] ] : 0 );
        bires_import_fix_slug( $id, $item['slug'] );
        bires_import_dates( $id, $item );
    }
    bires_import_map( $map );
    return [ count( $pages ), __( 'сторінки', 'bires-theme' ) ];
}

function bires_import_posts( $offset, $limit ) {
    $wpml  = bires_import_wpml();
    $posts = array_values( array_filter( bires_import_data()['posts'], function ( $p ) use ( $wpml ) {
        return $wpml || 'uk' === $p['lang'];
    } ) );
    usort( $posts, function ( $a, $b ) {
        return [ 'ru' === $a['lang'], $a['id'] ] <=> [ 'ru' === $b['lang'], $b['id'] ];
    } );
    $map = bires_import_map();
    foreach ( array_slice( $posts, $offset, $limit ) as $item ) {
        $id = isset( $map['post'][ $item['id'] ] ) && get_post( $map['post'][ $item['id'] ] ) ? $map['post'][ $item['id'] ] : 0;
        if ( ! $id && 'uk' === $item['lang'] ) {
            $existing = get_page_by_path( $item['slug'], OBJECT, 'post' );
            $id       = $existing ? $existing->ID : 0;
        }
        $cat_ids = [];
        foreach ( $item['cats'] as $slug ) {
            $term = get_term_by( 'slug', $slug, 'category' );
            if ( $term ) {
                $cat_ids[] = $term->term_id;
            }
        }
        $postarr = [
            'post_type'     => 'post',
            'post_status'   => 'publish',
            'post_title'    => $item['title'],
            'post_name'     => $item['slug'],
            'post_content'  => $item['content'],
            'post_excerpt'  => $item['excerpt'],
            'post_category' => $cat_ids,
        ];
        if ( $id ) {
            $postarr['ID'] = $id;
        }
        $id = wp_insert_post( wp_slash( $postarr ), true );
        if ( is_wp_error( $id ) ) {
            continue;
        }
        $map['post'][ $item['id'] ] = $id;
        wp_set_post_tags( $id, $item['tags'] ? array_map( function ( $slug ) {
            $term = get_term_by( 'slug', $slug, 'post_tag' );
            return $term ? $term->name : $slug;
        }, $item['tags'] ) : [] );
        bires_import_common_meta( $id, $item );
        $primary = $item['primary_cat'] ? get_term_by( 'slug', $item['primary_cat'], 'category' ) : null;
        if ( $primary ) {
            update_post_meta( $id, '_yoast_wpseo_primary_category', $primary->term_id );
        }
        bires_import_set_lang( $id, 'post', $item['lang'], $item['tr'] && isset( $map['post'][ $item['tr'] ] ) ? $map['post'][ $item['tr'] ] : 0 );
        bires_import_fix_slug( $id, $item['slug'] );
        bires_import_dates( $id, $item );
    }
    bires_import_map( $map );
    return [ count( $posts ), __( 'статті', 'bires-theme' ) ];
}

/** Без WPML російські статті на сайті не потрібні: якщо вони потрапили сюди раніше як українські — у кошик. */
function bires_import_trash_foreign() {
    if ( bires_import_wpml() ) {
        return 0;
    }
    $map     = bires_import_map();
    $trashed = 0;
    foreach ( bires_import_data()['posts'] as $item ) {
        $id = isset( $map['post'][ $item['id'] ] ) ? (int) $map['post'][ $item['id'] ] : 0;
        if ( 'ru' === $item['lang'] && $id && 'publish' === get_post_status( $id ) ) {
            wp_trash_post( $id );
            $trashed++;
        }
    }
    return $trashed;
}

/** Демо-контент: сторінки й статті, яких не було на старому сайті (крім «Про нас», «Кейси»), — у кошик. */
function bires_import_cleanup() {
    $removed = 0;
    $keep    = [ 'page-templates/about.php', 'page-templates/cases.php' ];
    foreach ( get_posts( [ 'post_type' => [ 'page', 'post' ], 'post_status' => 'any', 'posts_per_page' => -1, 'suppress_filters' => true ] ) as $post ) {
        if ( get_post_meta( $post->ID, '_bires_old_link', true ) || in_array( get_page_template_slug( $post->ID ), $keep, true ) ) {
            continue;
        }
        wp_trash_post( $post->ID );
        $removed++;
    }
    foreach ( [ 'Головне', 'Практики', 'Компанія' ] as $name ) {
        $menu = wp_get_nav_menu_object( $name );
        if ( $menu ) {
            wp_delete_nav_menu( $menu->term_id );
        }
    }
    /* translators: %d: number of demo pages and posts */
    return sprintf( __( 'демо-сторінок і статей у кошик: %d', 'bires-theme' ), $removed );
}

/** Картинки й файли — у ту саму папку uploads, що й на старому сайті (адреси в текстах не ламаються). */
function bires_import_upload_path( $relative ) {
    $relative = ltrim( str_replace( [ '\\', '..' ], [ '/', '' ], rawurldecode( $relative ) ), '/' );
    return trailingslashit( wp_upload_dir()['basedir'] ) . $relative;
}

function bires_import_files( $offset, $limit, &$state ) {
    $uploads = bires_import_data()['uploads'];
    foreach ( array_slice( $uploads, $offset, $limit ) as $relative ) {
        $file = bires_import_upload_path( $relative );
        if ( file_exists( $file ) ) {
            continue;
        }
        if ( ! empty( $state['blocked'] ) ) {
            $state['missing'][] = $relative;
            update_option( 'bires_old_media', 1, false );
            continue;
        }
        $response = wp_remote_get( BIRES_OLD_SITE . '/wp-content/uploads/' . $relative, [
            'timeout'    => 20,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
        ] );
        $code = wp_remote_retrieve_response_code( $response );
        $type = (string) wp_remote_retrieve_header( $response, 'content-type' );
        if ( 200 !== (int) $code || false !== strpos( $type, 'text/html' ) ) {
            $state['missing'][] = $relative;
            update_option( 'bires_old_media', 1, false ); // поки файлів немає, картинки показуються зі старого сайту (inc/old-media.php)
            $state['fails']     = isset( $state['fails'] ) ? $state['fails'] + 1 : 1;
            // Старий сайт не віддає файли серверу (захист Cloudflare) — далі не пробуємо, картинки підвантажимо через браузер
            if ( $state['fails'] >= 5 && empty( $state['saved'] ) ) {
                $state['blocked'] = true;
            }
            continue;
        }
        wp_mkdir_p( dirname( $file ) );
        file_put_contents( $file, wp_remote_retrieve_body( $response ) );
        $state['saved'] = isset( $state['saved'] ) ? $state['saved'] + 1 : 1;
    }
    return [ count( $uploads ), __( 'картинки', 'bires-theme' ) ];
}

/** Записи медіатеки для головних фото статей і логотипів, головні фото — до статей. */
function bires_import_attachments( $offset, $limit ) {
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $data = bires_import_data();
    $urls = [];
    foreach ( array_merge( $data['pages'], $data['posts'] ) as $item ) {
        if ( $item['thumb'] ) {
            $urls[ $item['thumb'] ] = true;
        }
    }
    foreach ( $data['media'] as $url ) {
        $urls[ $url ] = true;
    }
    $urls = array_keys( $urls );
    $map  = bires_import_map();
    foreach ( array_slice( $urls, $offset, $limit ) as $url ) {
        if ( ! empty( $map['att'][ $url ] ) && get_post( $map['att'][ $url ] ) ) {
            continue;
        }
        $relative = preg_replace( '#^https?://(www\.)?bires\.com\.ua/wp-content/uploads/#', '', $url );
        $file     = bires_import_upload_path( $relative );
        $exists   = file_exists( $file );
        if ( $relative === $url || ( ! $exists && ! get_option( 'bires_old_media' ) ) ) {
            continue;
        }
        $type = wp_check_filetype( $file );
        $att  = wp_insert_attachment( [
            'post_mime_type' => $type['type'] ? $type['type'] : 'image/jpeg',
            'post_title'     => preg_replace( '/\.[^.]+$/', '', wp_basename( $file ) ),
            'post_status'    => 'inherit',
        ], $file );
        if ( ! $att || is_wp_error( $att ) ) {
            continue;
        }
        update_post_meta( $att, '_wp_attached_file', ltrim( rawurldecode( $relative ), '/' ) );
        if ( $exists ) {
            wp_update_attachment_metadata( $att, wp_generate_attachment_metadata( $att, $file ) );
        }
        $map['att'][ $url ] = $att;
    }
    bires_import_map( $map );
    return [ count( $urls ), __( 'медіатека', 'bires-theme' ) ];
}

function bires_import_thumbnails() {
    $data = bires_import_data();
    $map  = bires_import_map();
    $set  = 0;
    foreach ( array_merge( $data['pages'], $data['posts'] ) as $item ) {
        if ( $item['thumb'] && ! empty( $map['att'][ $item['thumb'] ] ) && ! empty( $map['post'][ $item['id'] ] ) ) {
            set_post_thumbnail( $map['post'][ $item['id'] ], $map['att'][ $item['thumb'] ] );
            $set++;
        }
    }
    /* translators: %d: number of featured images */
    return sprintf( __( 'головних фото: %d', 'bires-theme' ), $set );
}

/** Після завантаження картинок — логотипи клієнтів і відгуки на головній ще раз (тепер є файли). */
function bires_import_refresh_home() {
    foreach ( get_posts( [ 'post_type' => 'page', 'posts_per_page' => -1, 'suppress_filters' => true, 'meta_key' => '_bires_mig_kind', 'meta_value' => 'home' ] ) as $page ) {
        bires_mig_convert_home( $page, bires_mig_data( $page->ID ) );
    }
    bires_migrated_after_import();
}

/** Старі ID картинок у даних Elementor (логотипи клієнтів, відгуки) → нові записи медіатеки. */
function bires_import_attachment_filter( $id ) {
    $map = bires_import_map();
    if ( empty( $map['att'] ) ) {
        return $id; // імпорту не було (перенесення на копії старого сайту) — ID ті самі
    }
    $data = bires_import_data();
    $url  = isset( $data['media'][ (string) $id ] ) ? $data['media'][ (string) $id ] : '';
    return $url && ! empty( $map['att'][ $url ] ) ? (int) $map['att'][ $url ] : 0;
}

function bires_import_finish() {
    $map = bires_import_map();
    global $wp_rewrite;
    $wp_rewrite->set_permalink_structure( '/%category%/%postname%/' );
    // Головна сторінка старого сайту — головна й тут (ID 50 — «Головна сторінка»)
    foreach ( bires_import_data()['pages'] as $item ) {
        if ( '/' === $item['path'] && 'uk' === $item['lang'] && ! empty( $map['post'][ $item['id'] ] ) ) {
            update_option( 'show_on_front', 'page' );
            update_option( 'page_on_front', $map['post'][ $item['id'] ] );
        }
    }
    $wp_rewrite->flush_rules( false );
    bires_import_trash_foreign();
    // Головна й налаштування як у макеті: п’ять практик для фізичних осіб, логотипи, досягнення, службові сторінки
    bires_migrated_after_import();
    if ( function_exists( 'bires_sitemap_flush' ) ) {
        bires_sitemap_flush();
    }
    return __( 'адреси сторінок як на старому сайті', 'bires-theme' );
}

/**
 * Один крок імпорту. Повертає стан; $state['done'] — усе завершено.
 */
function bires_import_step( $state ) {
    if ( function_exists( 'set_time_limit' ) ) {
        set_time_limit( 300 );
    }
    $steps  = [ 'terms', 'pages', 'posts', 'cleanup', 'files', 'attachments', 'thumbnails', 'convert', 'finish' ];
    $step   = isset( $state['step'] ) ? $state['step'] : 'terms';
    $offset = isset( $state['offset'] ) ? (int) $state['offset'] : 0;
    $next   = function () use ( &$state, $steps, $step ) {
        $i               = array_search( $step, $steps, true );
        $state['step']   = isset( $steps[ $i + 1 ] ) ? $steps[ $i + 1 ] : 'done';
        $state['offset'] = 0;
    };
    $batch = function ( $result, $limit ) use ( &$state, $offset, $next ) {
        list( $total, $label ) = $result;
        $state['offset']       = $offset + $limit;
        $state['label']        = sprintf( '%s: %d / %d', $label, min( $total, $offset + $limit ), $total );
        if ( $offset + $limit >= $total ) {
            $next();
        }
    };

    switch ( $step ) {
        case 'terms':
            $state['log'][] = bires_import_terms();
            $next();
            break;
        case 'pages':
            $batch( bires_import_pages( $offset, 25 ), 25 );
            break;
        case 'posts':
            $batch( bires_import_posts( $offset, 30 ), 30 );
            break;
        case 'cleanup':
            if ( ! empty( $state['cleanup'] ) ) {
                $state['log'][] = bires_import_cleanup();
            }
            $next();
            break;
        case 'files':
            $batch( bires_import_files( $offset, 15, $state ), 15 );
            break;
        case 'attachments':
            $batch( bires_import_attachments( $offset, 8 ), 8 );
            break;
        case 'thumbnails':
            $state['log'][] = bires_import_thumbnails();
            $next();
            break;
        case 'convert':
            update_option( 'bires_mig_force_menus', 1, false );
            list( $log, $remaining ) = bires_migration_run( false, 20, isset( $state['run'] ) ? $state['run'] : '' );
            foreach ( $log as $row ) {
                if ( in_array( $row[2], [ 'note', 'menu' ], true ) ) {
                    $state['notes'][] = $row;
                }
            }
            $state['converted'] = ( isset( $state['converted'] ) ? $state['converted'] : 0 ) + count( $log );
            /* translators: %d: pages done */
            $state['label'] = sprintf( __( 'розкладаю сторінки по блоках дизайну: %d', 'bires-theme' ), $state['converted'] );
            if ( ! $remaining ) {
                delete_option( 'bires_mig_force_menus' );
                $next();
            }
            break;
        case 'finish':
            $state['log'][] = bires_import_finish();
            $state['step']  = 'done';
            break;
    }
    $state['done'] = 'done' === $state['step'];
    return $state;
}

add_filter( 'bires_mig_attachment', 'bires_import_attachment_filter' );

/* ---------- Сторінка в адмінці ---------- */

function bires_import_menu() {
    add_management_page( __( 'Імпорт зі старого сайту', 'bires-theme' ), __( 'Імпорт зі старого сайту', 'bires-theme' ), 'manage_options', 'bires-import', 'bires_import_screen' );
}
add_action( 'admin_menu', 'bires_import_menu' );

/** Архіви з картинками, завантажені вручну (якщо старий сайт не віддав їх серверу). */
function bires_import_unzip_images() {
    if ( empty( $_FILES['images']['tmp_name'] ) || ! class_exists( 'ZipArchive' ) ) {
        return 0;
    }
    $count = 0;
    foreach ( (array) $_FILES['images']['tmp_name'] as $tmp ) {
        $zip = new ZipArchive();
        if ( ! $tmp || true !== $zip->open( $tmp ) ) {
            continue;
        }
        for ( $i = 0; $i < $zip->numFiles; $i++ ) {
            $name = $zip->getNameIndex( $i );
            if ( 0 !== strpos( $name, 'uploads/' ) || false !== strpos( $name, '..' ) || ! preg_match( '/\.(jpe?g|png|gif|webp|pdf|docx?|xlsx?)$/i', $name ) ) {
                continue;
            }
            $file = bires_import_upload_path( substr( $name, strlen( 'uploads/' ) ) );
            wp_mkdir_p( dirname( $file ) );
            file_put_contents( $file, $zip->getFromIndex( $i ) );
            $count++;
        }
        $zip->close();
    }
    return $count;
}

function bires_import_screen() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $state    = bires_import_state();
    $message  = '';
    $continue = false;
    if ( isset( $_POST['bires_import_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['bires_import_nonce'] ), 'bires_import' ) ) {
        $action = isset( $_POST['bires_action'] ) ? sanitize_key( $_POST['bires_action'] ) : '';
        if ( 'start' === $action ) {
            $state = [ 'step' => 'terms', 'offset' => 0, 'cleanup' => ! empty( $_POST['cleanup'] ), 'run' => (string) time(), 'log' => [], 'notes' => [], 'missing' => [] ];
        } elseif ( 'images' === $action ) {
            $count   = bires_import_unzip_images();
            /* translators: %d: number of files */
            $message = sprintf( __( 'Розпаковано файлів: %d. Тепер картинки підключаються до статей і сторінок.', 'bires-theme' ), $count );
            $state   = array_merge( $state, [ 'step' => 'attachments', 'offset' => 0, 'images_only' => true, 'done' => false ] );
        }
        if ( in_array( $action, [ 'start', 'next', 'images' ], true ) && empty( $state['done'] ) ) {
            $state = bires_import_step( $state );
            if ( ! empty( $state['images_only'] ) && 'convert' === $state['step'] ) {
                bires_import_refresh_home();
                $state['step'] = 'done';
                $state['done'] = true;
            }
            bires_import_state( $state );
            $continue = empty( $state['done'] );
        }
    }
    $data = bires_import_data();
    $acf  = function_exists( 'update_field' );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Імпорт зі старого сайту', 'bires-theme' ); ?></h1>
        <?php if ( $message ) : ?>
            <div class="notice notice-success"><p><?php echo esc_html( $message ); ?></p></div>
        <?php endif; ?>
        <?php if ( ! $acf ) : ?>
            <div class="notice notice-error"><p><?php esc_html_e( 'Спочатку встановіть і активуйте ACF PRO або Secure Custom Fields.', 'bires-theme' ); ?></p></div>
        <?php endif; ?>

        <?php if ( $continue ) : ?>
            <p><strong><?php esc_html_e( 'Імпортую… Не закривайте вкладку.', 'bires-theme' ); ?></strong></p>
            <p><?php echo esc_html( isset( $state['label'] ) ? $state['label'] : '' ); ?></p>
            <form method="post" id="bires-import-next">
                <?php wp_nonce_field( 'bires_import', 'bires_import_nonce' ); ?>
                <input type="hidden" name="bires_action" value="next">
                <noscript><button type="submit" class="button button-primary"><?php esc_html_e( 'Продовжити', 'bires-theme' ); ?></button></noscript>
            </form>
            <script>document.getElementById('bires-import-next').submit();</script>
        <?php else : ?>
            <?php if ( ! empty( $state['done'] ) ) : ?>
                <div class="notice notice-success"><p><strong><?php esc_html_e( 'Готово! Контент старого сайту перенесено.', 'bires-theme' ); ?></strong> <a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank"><?php esc_html_e( 'Відкрити сайт', 'bires-theme' ); ?></a></p></div>
                <?php if ( ! empty( $state['log'] ) ) : ?>
                    <ul style="list-style:disc;padding-left:20px">
                        <?php foreach ( $state['log'] as $line ) : ?>
                            <li><?php echo esc_html( $line ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                <?php $missing = array_values( array_unique( isset( $state['missing'] ) ? $state['missing'] : [] ) ); ?>
                <?php if ( $missing ) : ?>
                    <div class="notice notice-warning inline" style="padding:12px 16px">
                        <h2 style="margin-top:0"><?php esc_html_e( 'Картинки: ще один крок', 'bires-theme' ); ?></h2>
                        <p>
                            <?php
                            /* translators: %d: number of files */
                            echo esc_html( sprintf( __( 'Старий сайт захищений Cloudflare і не віддав серверу %d картинок. Заберіть їх через свій браузер:', 'bires-theme' ), count( $missing ) ) );
                            ?>
                        </p>
                        <ol>
                            <li><?php esc_html_e( 'Відкрийте https://bires.com.ua у Chrome на комп’ютері й дочекайтесь, поки завантажиться сайт.', 'bires-theme' ); ?></li>
                            <li><?php esc_html_e( 'Натисніть Ctrl+Shift+J (консоль). Якщо Chrome попросить — наберіть allow pasting і Enter.', 'bires-theme' ); ?></li>
                            <li><?php esc_html_e( 'Скопіюйте весь код з поля нижче, вставте в консоль і натисніть Enter. Браузер завантажить один або кілька архівів bires-images-N.zip.', 'bires-theme' ); ?></li>
                            <li><?php esc_html_e( 'Поверніться сюди й завантажте всі архіви у форму нижче.', 'bires-theme' ); ?></li>
                        </ol>
                        <textarea readonly rows="6" style="width:100%;font-family:monospace;font-size:12px" onclick="this.select()"><?php echo esc_textarea( bires_import_browser_script( $missing ) ); ?></textarea>
                        <form method="post" enctype="multipart/form-data" style="margin-top:12px">
                            <?php wp_nonce_field( 'bires_import', 'bires_import_nonce' ); ?>
                            <input type="hidden" name="bires_action" value="images">
                            <input type="file" name="images[]" accept=".zip" multiple required>
                            <button type="submit" class="button button-primary"><?php esc_html_e( 'Завантажити архіви з картинками', 'bires-theme' ); ?></button>
                            <?php /* translators: %s: max upload size */ ?>
                            <p class="description"><?php echo esc_html( sprintf( __( 'Максимальний розмір файлу на цьому хостингу: %s.', 'bires-theme' ), size_format( wp_max_upload_size() ) ) ); ?></p>
                        </form>
                    </div>
                <?php endif; ?>
                <?php if ( ! empty( $state['notes'] ) ) : ?>
                    <h2><?php esc_html_e( 'Що варто перевірити', 'bires-theme' ); ?></h2>
                    <table class="widefat striped">
                        <tbody>
                            <?php foreach ( $state['notes'] as $row ) : ?>
                                <tr>
                                    <td><?php echo $row[0] ? '<a href="' . esc_url( get_edit_post_link( $row[0] ) ) . '">' . esc_html( $row[1] ) . '</a>' : esc_html( $row[1] ); ?></td>
                                    <td><?php echo esc_html( $row[3] ); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                <hr>
            <?php endif; ?>

            <p>
                <?php
                /* translators: 1: pages, 2: posts, 3: files */
                echo esc_html( sprintf( __( 'Дані старого сайту в темі: сторінок — %1$d, статей — %2$d, картинок і файлів — %3$d.', 'bires-theme' ), count( isset( $data['pages'] ) ? $data['pages'] : [] ), count( isset( $data['posts'] ) ? $data['posts'] : [] ), count( isset( $data['uploads'] ) ? $data['uploads'] : [] ) ) );
                ?>
            </p>
            <p><?php esc_html_e( 'Імпорт створить усі сторінки послуг, статті блогу з рубриками, головну, каталог послуг, контакти, політики й карту сайту з адресами як на старому сайті, перенесе SEO-заголовки та описи (Yoast), FAQ, відгуки й логотипи клієнтів, розкладе тексти по блоках нового дизайну і збудує меню з послугами.', 'bires-theme' ); ?></p>
            <?php if ( ! bires_import_wpml() ) : ?>
                <p><em><?php esc_html_e( 'Плагін WPML не активний — переноситься лише українська версія. Щоб перенести й російську (/ru/), спершу встановіть WPML, потім запустіть імпорт.', 'bires-theme' ); ?></em></p>
            <?php endif; ?>
            <form method="post" onsubmit="var b=this.querySelector('button');if(b.disabled){return false;}b.disabled=true;">
                <?php wp_nonce_field( 'bires_import', 'bires_import_nonce' ); ?>
                <input type="hidden" name="bires_action" value="start">
                <p><label><input type="checkbox" name="cleanup" value="1" checked> <?php esc_html_e( 'Прибрати демо-контент (демо-сторінки й демо-статті — у кошик; «Про нас», «Кейси» і команда лишаються)', 'bires-theme' ); ?></label></p>
                <p><button type="submit" class="button button-primary button-hero" <?php disabled( ! $acf ); ?>><?php echo empty( $state['done'] ) ? esc_html__( 'Імпортувати контент старого сайту', 'bires-theme' ) : esc_html__( 'Імпортувати ще раз', 'bires-theme' ); ?></button></p>
            </form>
        <?php endif; ?>
    </div>
    <?php
}

/** Скрипт для консолі браузера на старому сайті: завантажує потрібні файли в архіви bires-images-N.zip. */
function bires_import_browser_script( $files ) {
    $limit = (int) min( 40 * MB_IN_BYTES, max( 2 * MB_IN_BYTES, wp_max_upload_size() * 0.9 ) );
    return '(async()=>{const F=' . wp_json_encode( array_values( $files ) ) . ',L=' . $limit . ';'
        . 'const box=document.createElement("div");box.style.cssText="position:fixed;z-index:2147483647;left:16px;bottom:16px;padding:14px 18px;border-radius:10px;background:#111;color:#fff;font:15px system-ui;white-space:pre-line";document.body.appendChild(box);'
        . 'const enc=new TextEncoder(),T=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;T[n]=c>>>0}'
        . 'const crc=d=>{let c=0xffffffff;for(let j=0;j<d.length;j++)c=T[(c^d[j])&255]^(c>>>8);return(c^0xffffffff)>>>0};'
        . 'const zip=(E,n)=>{const P=[],C=[];let o=0;for(const e of E){const nm=enc.encode(e.n),c=crc(e.d),s=e.d.length,h=new DataView(new ArrayBuffer(30));h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x0800,true);h.setUint32(14,c,true);h.setUint32(18,s,true);h.setUint32(22,s,true);h.setUint16(26,nm.length,true);P.push(h.buffer,nm,e.d);const x=new DataView(new ArrayBuffer(46));x.setUint32(0,0x02014b50,true);x.setUint16(4,20,true);x.setUint16(6,20,true);x.setUint16(8,0x0800,true);x.setUint32(16,c,true);x.setUint32(20,s,true);x.setUint32(24,s,true);x.setUint16(28,nm.length,true);x.setUint32(42,o,true);C.push(x.buffer,nm);o+=30+nm.length+s}'
        . 'const cs=C.reduce((a,p)=>a+p.byteLength,0),z=new DataView(new ArrayBuffer(22));z.setUint32(0,0x06054b50,true);z.setUint16(8,E.length,true);z.setUint16(10,E.length,true);z.setUint32(12,cs,true);z.setUint32(16,o,true);'
        . 'const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([...P,...C,z.buffer],{type:"application/zip"}));a.download="bires-images-"+n+".zip";document.body.appendChild(a);a.click()};'
        . 'let E=[],size=0,part=1,ok=0,bad=0;for(let i=0;i<F.length;i++){box.textContent="Картинки: "+(i+1)+" з "+F.length+"\nАрхів №"+part;'
        . 'try{const r=await fetch("/wp-content/uploads/"+F[i],{credentials:"include"});if(!r.ok)throw 0;const d=new Uint8Array(await r.arrayBuffer());'
        . 'if(size+d.length>L&&E.length){zip(E,part++);E=[];size=0;await new Promise(r=>setTimeout(r,1500))}E.push({n:"uploads/"+F[i],d});size+=d.length;ok++}catch(e){bad++}}'
        . 'if(E.length)zip(E,part);box.textContent="Готово ✓\nКартинок: "+ok+(bad?" (не вдалося: "+bad+")":"")+"\nАрхівів: "+part+" — вони в «Завантаженнях».\nЯкщо Chrome спитає про кілька завантажень — дозвольте."})();';
}

/* ---------- Сумісність зі старими адресами ---------- */

/**
 * Тексти зі старого сайту посилаються на https://bires.com.ua/… Поки новий сайт на іншому домені,
 * посилання й картинки показуємо з нього; після переїзду на bires.com.ua заміна не потрібна.
 */
function bires_old_urls( $html ) {
    if ( ! is_string( $html ) || false === strpos( $html, 'bires.com.ua' ) ) {
        return $html;
    }
    $home = untrailingslashit( (string) get_option( 'home' ) );
    if ( preg_match( '#^https?://(www\.)?bires\.com\.ua$#', $home ) ) {
        return $html;
    }
    $html = preg_replace( '#https?://(www\.)?bires\.com\.ua/wp-content/uploads/#', trailingslashit( wp_upload_dir()['baseurl'] ), $html );
    return preg_replace( '#https?://(www\.)?bires\.com\.ua(?=[/"\'\s<]|$)#', $home, $html );
}
add_filter( 'the_content', 'bires_old_urls', 20 );
add_filter( 'acf/format_value', 'bires_old_urls', 20 );
