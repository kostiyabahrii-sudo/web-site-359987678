<?php
/*
 * ACF field groups are registered in code so they ship with the theme.
 * Requires ACF PRO (Repeater, Relationship, Options page).
 */

function bires_acf_options_page() {
    if ( ! function_exists( 'acf_add_options_page' ) ) {
        return;
    }
    acf_add_options_page( [
        'page_title' => __( 'Налаштування сайту', 'bires-theme' ),
        'menu_title' => __( 'Налаштування сайту', 'bires-theme' ),
        'menu_slug'  => 'bires-settings',
        'capability' => 'edit_pages',
        'icon_url'   => 'dashicons-admin-generic',
        'position'   => 59,
    ] );
}
add_action( 'acf/init', 'bires_acf_options_page' );

function bires_acf_field_groups() {
    if ( ! function_exists( 'acf_add_local_field_group' ) ) {
        return;
    }

    acf_add_local_field_group( [
        'key'      => 'group_bires_settings',
        'title'    => __( 'Контакти та налаштування', 'bires-theme' ),
        'fields'   => [
            [ 'key' => 'field_bires_tab_contacts', 'label' => __( 'Контакти', 'bires-theme' ), 'type' => 'tab' ],
            [ 'key' => 'field_bires_phone_1', 'name' => 'contact_phone_1', 'label' => __( 'Телефон 1', 'bires-theme' ), 'type' => 'text', 'default_value' => '(+380) 44 334 75 04' ],
            [ 'key' => 'field_bires_phone_2', 'name' => 'contact_phone_2', 'label' => __( 'Телефон 2', 'bires-theme' ), 'type' => 'text', 'default_value' => '(+380) 96 106 20 56' ],
            [ 'key' => 'field_bires_email', 'name' => 'contact_email', 'label' => 'Email', 'type' => 'email', 'default_value' => 'info@bires.com.ua' ],
            [ 'key' => 'field_bires_address_1', 'name' => 'contact_address_1', 'label' => __( 'Адреса (рядок 1)', 'bires-theme' ), 'type' => 'text', 'default_value' => 'вул. Воздвиженська 14, офіс 9' ],
            [ 'key' => 'field_bires_address_2', 'name' => 'contact_address_2', 'label' => __( 'Адреса (рядок 2)', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Київ, 04-071' ],
            [ 'key' => 'field_bires_telegram', 'name' => 'social_telegram', 'label' => 'Telegram', 'type' => 'url' ],
            [ 'key' => 'field_bires_instagram', 'name' => 'social_instagram', 'label' => 'Instagram', 'type' => 'url' ],
            [ 'key' => 'field_bires_facebook', 'name' => 'social_facebook', 'label' => 'Facebook', 'type' => 'url' ],

            [ 'key' => 'field_bires_tab_pages', 'label' => __( 'Службові сторінки', 'bires-theme' ), 'type' => 'tab' ],
            [ 'key' => 'field_bires_contact_page', 'name' => 'contact_page', 'label' => __( 'Сторінка «Контакти»', 'bires-theme' ), 'type' => 'post_object', 'post_type' => [ 'page' ], 'return_format' => 'id', 'allow_null' => 1 ],
            [ 'key' => 'field_bires_sitemap_page', 'name' => 'sitemap_page', 'label' => __( 'Сторінка HTML-мапи сайту', 'bires-theme' ), 'type' => 'post_object', 'post_type' => [ 'page' ], 'return_format' => 'id', 'allow_null' => 1 ],
            [ 'key' => 'field_bires_privacy_page', 'name' => 'privacy_page', 'label' => 'Privacy Policy', 'type' => 'post_object', 'post_type' => [ 'page' ], 'return_format' => 'id', 'allow_null' => 1 ],
            [ 'key' => 'field_bires_terms_page', 'name' => 'terms_page', 'label' => 'Terms of use', 'type' => 'post_object', 'post_type' => [ 'page' ], 'return_format' => 'id', 'allow_null' => 1 ],

            [ 'key' => 'field_bires_tab_team', 'label' => __( 'Сторінка «Команда»', 'bires-theme' ), 'type' => 'tab' ],
            [ 'key' => 'field_bires_team_h1', 'name' => 'team_hero_title', 'label' => __( 'Заголовок H1', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Наша команда' ],
            [ 'key' => 'field_bires_team_hero_img', 'name' => 'team_hero_image', 'label' => __( 'Фото на першому екрані', 'bires-theme' ), 'type' => 'image', 'return_format' => 'id' ],
            [ 'key' => 'field_bires_team_intro_title', 'name' => 'team_intro_title', 'label' => __( 'Блок «Про нас»: заголовок', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Різні підходи. Одна команда' ],
            [ 'key' => 'field_bires_team_intro_text', 'name' => 'team_intro_text', 'label' => __( 'Блок «Про нас»: підзаголовок', 'bires-theme' ), 'type' => 'text' ],
            [ 'key' => 'field_bires_team_card1_img', 'name' => 'team_card1_image', 'label' => __( 'Картка 1: фото', 'bires-theme' ), 'type' => 'image', 'return_format' => 'id' ],
            [ 'key' => 'field_bires_team_card1_title', 'name' => 'team_card1_title', 'label' => __( 'Картка 1: заголовок', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Трудове та HR право' ],
            [ 'key' => 'field_bires_team_card1_text', 'name' => 'team_card1_text', 'label' => __( 'Картка 1: текст', 'bires-theme' ), 'type' => 'text' ],
            [ 'key' => 'field_bires_team_card2_title', 'name' => 'team_card2_title', 'label' => __( 'Картка 2: заголовок', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Міжнародні клієнти' ],
            [ 'key' => 'field_bires_team_card2_number', 'name' => 'team_card2_number', 'label' => __( 'Картка 2: число', 'bires-theme' ), 'type' => 'text', 'default_value' => '70%' ],
            [ 'key' => 'field_bires_team_card2_flags', 'name' => 'team_card2_flags', 'label' => __( 'Картка 2: прапори (коди країн через кому, напр. ee,gb,cy,pl,fr)', 'bires-theme' ), 'type' => 'text', 'default_value' => 'lv,ee,gb,cy,pl,us,fr' ],
            [ 'key' => 'field_bires_team_card2_text', 'name' => 'team_card2_text', 'label' => __( 'Картка 2: підпис', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Супроводжуємо бізнес та приватні справи по всьому світу.' ],
            [ 'key' => 'field_bires_team_card3_number', 'name' => 'team_card3_number', 'label' => __( 'Картка 3: число', 'bires-theme' ), 'type' => 'text', 'default_value' => '500+' ],
            [ 'key' => 'field_bires_team_card3_text', 'name' => 'team_card3_text', 'label' => __( 'Картка 3: текст', 'bires-theme' ), 'type' => 'text', 'default_value' => 'успішно реалізованих кейсів у різних галузях права.' ],
            [ 'key' => 'field_bires_team_heads_text', 'name' => 'team_heads_text', 'label' => __( 'Підзаголовок «Керівники практик»', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Наша команда, що представляє інтереси власників бізнесу та приватних клієнтів.' ],

            [ 'key' => 'field_bires_tab_results', 'label' => __( 'Результати клієнтів', 'bires-theme' ), 'type' => 'tab' ],
            [ 'key' => 'field_bires_results_label', 'name' => 'client_results_label', 'label' => __( 'Мітка секції', 'bires-theme' ), 'type' => 'text', 'default_value' => 'наші клієнти' ],
            [ 'key' => 'field_bires_results_title', 'name' => 'client_results_title', 'label' => __( 'Заголовок', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Результати наших клієнтів' ],
            [ 'key' => 'field_bires_results_text', 'name' => 'client_results_text', 'label' => __( 'Підзаголовок', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Настав час вирішити свої юридичні питання? Почніть зараз.' ],
            [ 'key' => 'field_bires_results', 'name' => 'client_results', 'label' => __( 'Картки', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'block', 'button_label' => __( 'Додати картку', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_result_logo', 'name' => 'logo', 'label' => __( 'Логотип клієнта', 'bires-theme' ), 'type' => 'image', 'return_format' => 'id' ],
                [ 'key' => 'field_bires_result_name', 'name' => 'name', 'label' => __( 'Назва клієнта (alt)', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_result_number', 'name' => 'number', 'label' => __( 'Велике число (напр. 99%) — якщо порожньо, виводиться відгук', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_result_text', 'name' => 'text', 'label' => __( 'Текст', 'bires-theme' ), 'type' => 'textarea', 'rows' => 3 ],
            ] ],

            [ 'key' => 'field_bires_tab_form', 'label' => __( 'Форма зв’язку', 'bires-theme' ), 'type' => 'tab' ],
            [ 'key' => 'field_bires_form_shortcode', 'name' => 'form_shortcode', 'label' => __( 'Шорткод форми (напр. Contact Form 7)', 'bires-theme' ), 'type' => 'text', 'instructions' => __( 'Якщо порожньо — виводиться вбудована форма теми.', 'bires-theme' ) ],
            [ 'key' => 'field_bires_manager', 'name' => 'contact_manager', 'label' => __( 'Менеджер у блоці контактів', 'bires-theme' ), 'type' => 'post_object', 'post_type' => [ 'team' ], 'return_format' => 'id', 'allow_null' => 1 ],
            [ 'key' => 'field_bires_manager_name', 'name' => 'contact_manager_name', 'label' => __( 'Ім’я в блоці «Чи маєте ще питання?»', 'bires-theme' ), 'type' => 'text', 'instructions' => __( 'Якщо порожньо — береться з картки співробітника. На сторінці «Контакти» завжди показуються ім’я та посада з картки.', 'bires-theme' ) ],
            [ 'key' => 'field_bires_manager_role', 'name' => 'contact_manager_role', 'label' => __( 'Посада в блоці «Чи маєте ще питання?»', 'bires-theme' ), 'type' => 'text', 'instructions' => __( 'Якщо порожньо — береться з картки співробітника.', 'bires-theme' ) ],
            [ 'key' => 'field_bires_manager_photo', 'name' => 'contact_manager_photo', 'label' => __( 'Фото менеджера (PNG без фону) — для обох блоків', 'bires-theme' ), 'type' => 'image', 'return_format' => 'id', 'instructions' => __( 'Вирізаний портрет до пояса, вертикальний 2:3 — як у макеті: голова виходить за зелене коло. Якщо порожньо — фото з картки співробітника.', 'bires-theme' ) ],
            [ 'key' => 'field_bires_clients_count', 'name' => 'clients_count_text', 'label' => __( 'Підпис під кнопками', 'bires-theme' ), 'type' => 'text', 'default_value' => '1,000+ клієнтів обрали нашу юридичну команду' ],
            [ 'key' => 'field_bires_tab_fonts', 'label' => __( 'Шрифт', 'bires-theme' ), 'type' => 'tab' ],
            [ 'key' => 'field_bires_adobe_kit', 'name' => 'adobe_fonts_kit', 'label' => __( 'Adobe Fonts: ID веб-проєкту', 'bires-theme' ), 'type' => 'text', 'placeholder' => 'abc1def', 'instructions' => __( 'Для шрифту Proxima Nova з Adobe Fonts. ID — це частина посилання https://use.typekit.net/<b>abc1def</b>.css з коду вбудовування.', 'bires-theme' ) ],
        ],
        'location' => [ [ [ 'param' => 'options_page', 'operator' => '==', 'value' => 'bires-settings' ] ] ],
    ] );

    acf_add_local_field_group( [
        'key'      => 'group_bires_page_hero',
        'title'    => __( 'Перший екран сторінки', 'bires-theme' ),
        'position' => 'acf_after_title',
        'fields'   => [
            [ 'key' => 'field_bires_hero_title', 'name' => 'hero_title', 'label' => __( 'Заголовок H1', 'bires-theme' ), 'type' => 'text', 'instructions' => __( 'Якщо порожньо — використовується назва сторінки.', 'bires-theme' ) ],
            [ 'key' => 'field_bires_hero_text', 'name' => 'hero_text', 'label' => __( 'Підзаголовок', 'bires-theme' ), 'type' => 'textarea', 'rows' => 3 ],
        ],
        'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'page' ] ] ],
    ] );

    acf_add_local_field_group( [
        'key'      => 'group_bires_service',
        'title'    => __( 'Картка послуги', 'bires-theme' ),
        'position' => 'side',
        'fields'   => [
            [ 'key' => 'field_bires_service_audience', 'name' => 'service_audience', 'label' => __( 'Для кого', 'bires-theme' ), 'type' => 'select', 'choices' => [ 'business' => __( 'Бізнес', 'bires-theme' ), 'personal' => __( 'Фізичні особи', 'bires-theme' ) ], 'default_value' => 'business' ],
            [ 'key' => 'field_bires_service_icon', 'name' => 'service_icon', 'label' => __( 'Іконка', 'bires-theme' ), 'type' => 'select', 'choices' => bires_icon_choices(), 'allow_null' => 1 ],
            [ 'key' => 'field_bires_service_card_title', 'name' => 'service_card_title', 'label' => __( 'Назва на картці', 'bires-theme' ), 'type' => 'textarea', 'rows' => 2, 'new_lines' => '', 'instructions' => __( 'Якщо порожньо — назва сторінки. Перенос рядка (Enter) працює лише на десктопі.', 'bires-theme' ) ],
            [ 'key' => 'field_bires_service_short', 'name' => 'service_short', 'label' => __( 'Короткий опис (для блоку «Пов’язані послуги»)', 'bires-theme' ), 'type' => 'textarea', 'rows' => 3 ],
        ],
        'location' => [
            [ [ 'param' => 'page_template', 'operator' => '==', 'value' => BIRES_SERVICE_TEMPLATE ] ],
            [
                [ 'param' => 'post_type', 'operator' => '==', 'value' => 'page' ],
                [ 'param' => 'page_type', 'operator' => '==', 'value' => 'child' ],
            ],
        ],
    ] );

    $feature_icons = bires_feature_icon_choices();

    acf_add_local_field_group( [
        'key'        => 'group_bires_service_page',
        'title'      => __( 'Блоки сторінки послуги', 'bires-theme' ),
        'menu_order' => 10,
        'fields'     => [
            [ 'key' => 'field_bires_sp_tab_intro', 'label' => __( 'Практика', 'bires-theme' ), 'type' => 'tab' ],
            [ 'key' => 'field_bires_sp_intro_title', 'name' => 'intro_title', 'label' => __( 'Заголовок', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Практика' ],
            [ 'key' => 'field_bires_sp_intro_text', 'name' => 'intro_text', 'label' => __( 'Текст', 'bires-theme' ), 'type' => 'textarea', 'rows' => 4 ],
            [ 'key' => 'field_bires_sp_card_title', 'name' => 'intro_card_title', 'label' => __( 'Картка: заголовок', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Вартість та строки' ],
            [ 'key' => 'field_bires_sp_card_text', 'name' => 'intro_card_text', 'label' => __( 'Картка: підпис', 'bires-theme' ), 'type' => 'textarea', 'rows' => 2, 'default_value' => 'залежать від складності послуги та узгоджуються індивідуально' ],
            [ 'key' => 'field_bires_sp_ticket_title', 'name' => 'ticket_title', 'label' => __( 'Квиток: заголовок', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Оцінка справи' ],
            [ 'key' => 'field_bires_sp_ticket_rows', 'name' => 'ticket_rows', 'label' => __( 'Квиток: рядки', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'table', 'max' => 6, 'button_label' => __( 'Додати рядок', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_sp_ticket_label', 'name' => 'label', 'label' => __( 'Назва', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_sp_ticket_value', 'name' => 'value', 'label' => __( 'Значення', 'bires-theme' ), 'type' => 'text' ],
            ] ],

            [ 'key' => 'field_bires_sp_tab_steps', 'label' => __( 'Етапи співпраці', 'bires-theme' ), 'type' => 'tab' ],
            [ 'key' => 'field_bires_sp_steps_title', 'name' => 'steps_title', 'label' => __( 'Заголовок', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Як ми працюємо' ],
            [ 'key' => 'field_bires_sp_steps_text', 'name' => 'steps_text', 'label' => __( 'Підзаголовок', 'bires-theme' ), 'type' => 'textarea', 'rows' => 2 ],
            [ 'key' => 'field_bires_sp_steps', 'name' => 'steps', 'label' => __( 'Етапи', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'block', 'button_label' => __( 'Додати етап', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_sp_step_icon', 'name' => 'icon', 'label' => __( 'Іконка', 'bires-theme' ), 'type' => 'select', 'choices' => $feature_icons ],
                [ 'key' => 'field_bires_sp_step_title', 'name' => 'title', 'label' => __( 'Заголовок', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_sp_step_text', 'name' => 'text', 'label' => __( 'Опис', 'bires-theme' ), 'type' => 'textarea', 'rows' => 2 ],
            ] ],

            [ 'key' => 'field_bires_sp_tab_results', 'label' => __( 'Результати', 'bires-theme' ), 'type' => 'tab' ],
            [ 'key' => 'field_bires_sp_results_title', 'name' => 'results_title', 'label' => __( 'Заголовок', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Результати нашої юридичної експертизи' ],
            [ 'key' => 'field_bires_sp_results_text', 'name' => 'results_text', 'label' => __( 'Текст', 'bires-theme' ), 'type' => 'textarea', 'rows' => 4, 'new_lines' => 'wpautop' ],
            [ 'key' => 'field_bires_sp_results', 'name' => 'results_numbers', 'label' => __( 'Цифри', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'table', 'max' => 4, 'button_label' => __( 'Додати', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_sp_result_number', 'name' => 'number', 'label' => __( 'Число', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_sp_result_label', 'name' => 'label', 'label' => __( 'Підпис', 'bires-theme' ), 'type' => 'text' ],
            ] ],

            [ 'key' => 'field_bires_sp_tab_benefits', 'label' => __( 'Наш підхід', 'bires-theme' ), 'type' => 'tab' ],
            [ 'key' => 'field_bires_sp_benefits_title', 'name' => 'benefits_title', 'label' => __( 'Заголовок', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Що ви отримаєте' ],
            [ 'key' => 'field_bires_sp_benefits_text', 'name' => 'benefits_text', 'label' => __( 'Підзаголовок', 'bires-theme' ), 'type' => 'textarea', 'rows' => 2 ],
            [ 'key' => 'field_bires_sp_benefits', 'name' => 'benefits', 'label' => __( 'Переваги', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'block', 'max' => 8, 'button_label' => __( 'Додати', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_sp_benefit_icon', 'name' => 'icon', 'label' => __( 'Іконка', 'bires-theme' ), 'type' => 'select', 'choices' => $feature_icons ],
                [ 'key' => 'field_bires_sp_benefit_title', 'name' => 'title', 'label' => __( 'Заголовок', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_sp_benefit_text', 'name' => 'text', 'label' => __( 'Опис', 'bires-theme' ), 'type' => 'textarea', 'rows' => 2 ],
            ] ],

            [ 'key' => 'field_bires_sp_tab_related', 'label' => __( 'Пов’язані послуги', 'bires-theme' ), 'type' => 'tab' ],
            [ 'key' => 'field_bires_sp_related', 'name' => 'related_services', 'label' => __( 'Послуги', 'bires-theme' ), 'type' => 'relationship', 'post_type' => [ 'page' ], 'filters' => [ 'search' ], 'return_format' => 'id', 'instructions' => __( 'Якщо порожньо — виводяться сусідні послуги цього розділу.', 'bires-theme' ) ],
        ],
        'location'   => [
            [ [ 'param' => 'page_template', 'operator' => '==', 'value' => BIRES_SERVICE_TEMPLATE ] ],
            [
                [ 'param' => 'post_type', 'operator' => '==', 'value' => 'page' ],
                [ 'param' => 'page_type', 'operator' => '==', 'value' => 'child' ],
            ],
        ],
    ] );

    acf_add_local_field_group( [
        'key'      => 'group_bires_contact_page',
        'title'    => __( 'Сторінка «Контакти»', 'bires-theme' ),
        'fields'   => [
            [ 'key' => 'field_bires_cp_form_title', 'name' => 'contact_form_title', 'label' => __( 'Заголовок форми', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Зв’яжіться з нами' ],
            [ 'key' => 'field_bires_cp_form_text', 'name' => 'contact_form_text', 'label' => __( 'Текст перед email', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Заповніть форму або пишіть на:' ],
            [ 'key' => 'field_bires_cp_qr', 'name' => 'contact_qr', 'label' => __( 'QR-код Телеграм', 'bires-theme' ), 'type' => 'image', 'return_format' => 'id' ],
            [ 'key' => 'field_bires_cp_office_label', 'name' => 'office_label', 'label' => __( 'Офіс: мітка секції', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Офіс' ],
            [ 'key' => 'field_bires_cp_office_title', 'name' => 'office_title', 'label' => __( 'Офіс: назва', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Manhattan City' ],
            [ 'key' => 'field_bires_cp_office_address', 'name' => 'office_address', 'label' => __( 'Офіс: адреса', 'bires-theme' ), 'type' => 'textarea', 'rows' => 2, 'new_lines' => '', 'default_value' => "Київ, Берестейський проспект 11, корпус 3\n27 поверх, офіс 323" ],
            [ 'key' => 'field_bires_cp_office_gallery', 'name' => 'office_gallery', 'label' => __( 'Офіс: фото', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'table', 'button_label' => __( 'Додати фото', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_cp_office_image', 'name' => 'image', 'label' => __( 'Фото', 'bires-theme' ), 'type' => 'image', 'return_format' => 'id' ],
            ] ],
            [ 'key' => 'field_bires_cp_map_query', 'name' => 'map_query', 'label' => __( 'Мапа: адреса для Google Maps', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Берестейський проспект 11, Київ', 'instructions' => __( 'За цією адресою показується жива мапа Google і будується маршрут. Якщо порожньо — показується зображення нижче.', 'bires-theme' ) ],
            [ 'key' => 'field_bires_cp_map_image', 'name' => 'map_image', 'label' => __( 'Мапа: зображення (замість живої мапи)', 'bires-theme' ), 'type' => 'image', 'return_format' => 'id', 'instructions' => __( 'Показується лише тоді, коли поле адреси вище порожнє.', 'bires-theme' ) ],
            [ 'key' => 'field_bires_cp_map_link', 'name' => 'map_link', 'label' => __( 'Мапа: посилання', 'bires-theme' ), 'type' => 'url' ],
        ],
        'location' => [ [ [ 'param' => 'page_template', 'operator' => '==', 'value' => 'page-templates/contact.php' ] ] ],
    ] );

    $tab = function ( $key, $label ) {
        return [ 'key' => 'field_bires_home_tab_' . $key, 'label' => $label, 'type' => 'tab' ];
    };
    $txt = function ( $name, $label, $default = '', $type = 'text' ) {
        $field = [ 'key' => 'field_bires_' . $name, 'name' => $name, 'label' => $label, 'type' => $type, 'default_value' => $default ];
        if ( 'textarea' === $type ) {
            $field['rows'] = 3;
        }
        return $field;
    };
    $img = function ( $name, $label ) {
        return [ 'key' => 'field_bires_' . $name, 'name' => $name, 'label' => $label, 'type' => 'image', 'return_format' => 'id' ];
    };
    $services_field = function ( $name, $label ) {
        return [ 'key' => 'field_bires_' . $name, 'name' => $name, 'label' => $label, 'type' => 'relationship', 'post_type' => [ 'page' ], 'filters' => [ 'search' ], 'return_format' => 'id', 'max' => 10, 'instructions' => __( 'Якщо порожньо — виводяться послуги відповідної аудиторії.', 'bires-theme' ) ];
    };

    acf_add_local_field_group( [
        'key'        => 'group_bires_home',
        'title'      => __( 'Головна сторінка', 'bires-theme' ),
        'menu_order' => 5,
        'fields'     => [
            $tab( 'hero', __( 'Перший екран', 'bires-theme' ) ),
            $img( 'home_hero_image', __( 'Фото', 'bires-theme' ) ),
            $txt( 'home_hero_button', __( 'Текст кнопки', 'bires-theme' ), 'Отримайте консультацію' ),

            $tab( 'business', __( 'Послуги для бізнесу', 'bires-theme' ) ),
            $txt( 'home_biz_label', __( 'Мітка секції', 'bires-theme' ), 'Наші послуги' ),
            $txt( 'home_biz_title', __( 'Заголовок', 'bires-theme' ), 'Для бізнесу — правова підтримка, коли вона потрібна.', 'textarea' ),
            $services_field( 'home_biz_services', __( 'Послуги', 'bires-theme' ) ),

            $tab( 'personal', __( 'Послуги для фізичних осіб', 'bires-theme' ) ),
            $txt( 'home_personal_title', __( 'Заголовок', 'bires-theme' ), 'Для фізичних осіб.' ),
            $txt( 'home_personal_text', __( 'Текст', 'bires-theme' ), 'Ми надаємо професійну правову підтримку у справах, що стосуються приватних клієнтів. Забезпечуємо комплексний юридичний супровід у справах сімейного, міграційного, кримінального, а також у питаннях та захисту прав фізичних осіб.', 'textarea' ),
            $services_field( 'home_personal_services', __( 'Послуги', 'bires-theme' ) ),

            $tab( 'approach', __( 'Наш підхід', 'bires-theme' ) ),
            $txt( 'home_approach_label', __( 'Мітка секції', 'bires-theme' ), 'Наш підхід' ),
            $img( 'home_approach_image', __( 'Фото', 'bires-theme' ) ),
            $txt( 'home_approach_title', __( 'Заголовок', 'bires-theme' ), 'Чому клієнти обирають компанію Bires?' ),
            $txt( 'home_approach_text', __( 'Текст', 'bires-theme' ), 'Ми маємо унікальний практичний досвід представництва та захисту інтересів українських та іноземних клієнтів у судах, арбітражних установах і органах державної влади.', 'textarea' ),
            [ 'key' => 'field_bires_home_approach_points', 'name' => 'home_approach_points', 'label' => __( 'Переваги', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'table', 'button_label' => __( 'Додати', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_home_approach_point', 'name' => 'text', 'label' => __( 'Текст', 'bires-theme' ), 'type' => 'text' ],
            ] ],

            $tab( 'stats', __( 'Цифри', 'bires-theme' ) ),
            $txt( 'home_quote', __( 'Цитата', 'bires-theme' ), 'Готові працювати з командою, яка ставить клієнта в центр рішень?', 'textarea' ),
            [ 'key' => 'field_bires_home_quote_person', 'name' => 'home_quote_person', 'label' => __( 'Автор цитати', 'bires-theme' ), 'type' => 'post_object', 'post_type' => [ 'team' ], 'return_format' => 'id', 'allow_null' => 1 ],
            [ 'key' => 'field_bires_home_quote_photo', 'name' => 'home_quote_photo', 'label' => __( 'Фото для цитати', 'bires-theme' ), 'type' => 'image', 'return_format' => 'id', 'preview_size' => 'thumbnail', 'instructions' => __( 'Якщо порожньо — фото з профілю автора.', 'bires-theme' ) ],
            $txt( 'home_quote_role', __( 'Підпис автора (якщо відрізняється від посади)', 'bires-theme' ), 'СEO компанії Bires' ),
            [ 'key' => 'field_bires_home_stats', 'name' => 'home_stats', 'label' => __( 'Цифри', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'table', 'max' => 4, 'button_label' => __( 'Додати', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_home_stat_label', 'name' => 'label', 'label' => __( 'Назва', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_home_stat_number', 'name' => 'number', 'label' => __( 'Число', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_home_stat_caption', 'name' => 'caption', 'label' => __( 'Підпис', 'bires-theme' ), 'type' => 'text' ],
            ] ],

            $tab( 'reviews', __( 'Відгуки та клієнти', 'bires-theme' ) ),
            $txt( 'home_reviews_label', __( 'Мітка секції', 'bires-theme' ), 'наші клієнти' ),
            $txt( 'home_reviews_title', __( 'Заголовок', 'bires-theme' ), 'Що наші клієнти говорять про нас?' ),
            $txt( 'home_reviews_text', __( 'Підзаголовок', 'bires-theme' ), 'Настав час вирішити свої юридичні питання? Почніть зараз.' ),
            [ 'key' => 'field_bires_home_reviews', 'name' => 'home_reviews', 'label' => __( 'Відгуки', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'block', 'button_label' => __( 'Додати відгук', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_home_review_name', 'name' => 'name', 'label' => __( 'Ім’я', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_home_review_role', 'name' => 'role', 'label' => __( 'Посада', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_home_review_logo', 'name' => 'logo', 'label' => __( 'Логотип компанії', 'bires-theme' ), 'type' => 'image', 'return_format' => 'id' ],
                [ 'key' => 'field_bires_home_review_badge', 'name' => 'badge', 'label' => __( 'Галузь', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_home_review_rating', 'name' => 'rating', 'label' => __( 'Оцінка (1–5)', 'bires-theme' ), 'type' => 'number', 'min' => 1, 'max' => 5, 'default_value' => 5 ],
                [ 'key' => 'field_bires_home_review_text', 'name' => 'text', 'label' => __( 'Відгук', 'bires-theme' ), 'type' => 'textarea', 'rows' => 4 ],
            ] ],
            [ 'key' => 'field_bires_home_logos', 'name' => 'home_logos', 'label' => __( 'Логотипи клієнтів (до 16)', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'table', 'max' => 16, 'button_label' => __( 'Додати логотип', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_home_logo_image', 'name' => 'image', 'label' => __( 'Логотип', 'bires-theme' ), 'type' => 'image', 'return_format' => 'id' ],
                [ 'key' => 'field_bires_home_logo_name', 'name' => 'name', 'label' => __( 'Назва', 'bires-theme' ), 'type' => 'text' ],
            ] ],

            $tab( 'achievements', __( 'Наші досягнення', 'bires-theme' ) ),
            $txt( 'home_achievements_label', __( 'Мітка секції', 'bires-theme' ), 'Наші досягнення' ),
            [ 'key' => 'field_bires_home_achievements', 'name' => 'home_achievements', 'label' => __( 'Слайди', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'block', 'button_label' => __( 'Додати слайд', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_home_ach_title', 'name' => 'title', 'label' => __( 'Заголовок', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_home_ach_text', 'name' => 'text', 'label' => __( 'Опис', 'bires-theme' ), 'type' => 'textarea', 'rows' => 3 ],
                [ 'key' => 'field_bires_home_ach_tags', 'name' => 'tags', 'label' => __( 'Мітки (через кому)', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_home_ach_period', 'name' => 'period', 'label' => __( 'Період', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_home_ach_image', 'name' => 'image', 'label' => __( 'Фото', 'bires-theme' ), 'type' => 'image', 'return_format' => 'id' ],
            ] ],

            $tab( 'blog', __( 'Блог', 'bires-theme' ) ),
            [ 'key' => 'field_bires_home_posts', 'name' => 'home_posts', 'label' => __( 'Статті (3)', 'bires-theme' ), 'type' => 'relationship', 'post_type' => [ 'post' ], 'filters' => [ 'search', 'taxonomy' ], 'return_format' => 'id', 'max' => 3, 'instructions' => __( 'Якщо порожньо — три останні статті.', 'bires-theme' ) ],
        ],
        'location'   => [ [ [ 'param' => 'page_type', 'operator' => '==', 'value' => 'front_page' ] ] ],
        'hide_on_screen' => [ 'the_content' ],
    ] );

    acf_add_local_field_group( [
        'key'      => 'group_bires_about_page',
        'title'    => __( 'Сторінка «Про нас»', 'bires-theme' ),
        'fields'   => [
            [ 'key' => 'field_bires_about_stats', 'name' => 'about_stats', 'label' => __( 'Цифри', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'table', 'max' => 6, 'button_label' => __( 'Додати', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_about_stat_number', 'name' => 'number', 'label' => __( 'Число', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_about_stat_text', 'name' => 'text', 'label' => __( 'Підпис', 'bires-theme' ), 'type' => 'text' ],
            ] ],
        ],
        'location' => [ [ [ 'param' => 'page_template', 'operator' => '==', 'value' => 'page-templates/about.php' ] ] ],
    ] );

    acf_add_local_field_group( [
        'key'      => 'group_bires_case',
        'title'    => __( 'Кейс', 'bires-theme' ),
        'fields'   => [
            [ 'key' => 'field_bires_case_note', 'label' => '', 'name' => '', 'type' => 'message', 'message' => __( 'Назва запису — назва клієнта. Зображення запису — фон картки та шапки.', 'bires-theme' ) ],
            [ 'key' => 'field_bires_case_logo', 'name' => 'case_logo', 'label' => __( 'Логотип на картці (світлий)', 'bires-theme' ), 'type' => 'image', 'return_format' => 'id' ],
            [ 'key' => 'field_bires_case_logo_large', 'name' => 'case_logo_large', 'label' => __( 'Не зменшувати логотип на мобільному', 'bires-theme' ), 'type' => 'true_false', 'ui' => 1, 'instructions' => __( 'Для «легких» логотипів (як у «Хвилі здоровʼя»): на телефоні логотип лишається 96px заввишки, а не 64px.', 'bires-theme' ) ],
            [ 'key' => 'field_bires_case_logo_dark', 'name' => 'case_logo_dark', 'label' => __( 'Логотип у вікні кейсу (кольоровий)', 'bires-theme' ), 'type' => 'image', 'return_format' => 'id' ],
            [ 'key' => 'field_bires_case_practice', 'name' => 'case_practice', 'label' => __( 'Заголовок (практика)', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Податкова практика' ],
            [ 'key' => 'field_bires_case_intro', 'name' => 'case_intro', 'label' => __( 'Інтро', 'bires-theme' ), 'type' => 'wysiwyg', 'tabs' => 'all', 'toolbar' => 'basic', 'media_upload' => 0 ],
            [ 'key' => 'field_bires_case_actions', 'name' => 'case_actions', 'label' => __( 'Що ми зробили', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'table', 'button_label' => __( 'Додати пункт', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_case_action', 'name' => 'text', 'label' => __( 'Пункт', 'bires-theme' ), 'type' => 'text' ],
            ] ],
            [ 'key' => 'field_bires_case_expert', 'name' => 'case_expert', 'label' => __( 'Наш експерт', 'bires-theme' ), 'type' => 'post_object', 'post_type' => [ 'team' ], 'return_format' => 'id', 'allow_null' => 1 ],
            [ 'key' => 'field_bires_case_expert_text', 'name' => 'case_expert_text', 'label' => __( 'Про експерта', 'bires-theme' ), 'type' => 'textarea', 'rows' => 4 ],
            [ 'key' => 'field_bires_case_results', 'name' => 'case_results', 'label' => __( 'Результати', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'table', 'button_label' => __( 'Додати результат', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_case_result', 'name' => 'text', 'label' => __( 'Результат', 'bires-theme' ), 'type' => 'text' ],
            ] ],
            [ 'key' => 'field_bires_case_badges', 'name' => 'case_badges', 'label' => __( 'Мітки (галузь, тип справи, сума)', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'table', 'button_label' => __( 'Додати мітку', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_case_badge', 'name' => 'text', 'label' => __( 'Мітка', 'bires-theme' ), 'type' => 'text' ],
            ] ],
        ],
        'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'case' ] ] ],
    ] );

    acf_add_local_field_group( [
        'key'        => 'group_bires_faq',
        'title'      => __( 'FAQ (поширені запитання)', 'bires-theme' ),
        'menu_order' => 20,
        'fields'     => [
            [ 'key' => 'field_bires_faq_title', 'name' => 'faq_title', 'label' => __( 'Заголовок блоку', 'bires-theme' ), 'type' => 'text', 'default_value' => 'Відповіді на поширені запитання' ],
            [ 'key' => 'field_bires_faq_text', 'name' => 'faq_text', 'label' => __( 'Підзаголовок', 'bires-theme' ), 'type' => 'textarea', 'rows' => 2 ],
            [
                'key'          => 'field_bires_faq',
                'name'         => 'faq',
                'label'        => __( 'Питання', 'bires-theme' ),
                'type'         => 'repeater',
                'layout'       => 'block',
                'button_label' => __( 'Додати питання', 'bires-theme' ),
                'sub_fields'   => [
                    [ 'key' => 'field_bires_faq_q', 'name' => 'question', 'label' => __( 'Питання', 'bires-theme' ), 'type' => 'text', 'required' => 1 ],
                    [ 'key' => 'field_bires_faq_a', 'name' => 'answer', 'label' => __( 'Відповідь', 'bires-theme' ), 'type' => 'wysiwyg', 'media_upload' => 0, 'required' => 1 ],
                ],
            ],
        ],
        'location'   => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'page' ] ] ],
    ] );

    acf_add_local_field_group( [
        'key'      => 'group_bires_team',
        'title'    => __( 'Профіль члена команди', 'bires-theme' ),
        'position' => 'acf_after_title',
        'fields'   => [
            [ 'key' => 'field_bires_team_position', 'name' => 'team_position', 'label' => __( 'Посада', 'bires-theme' ), 'type' => 'text', 'required' => 1 ],
            [ 'key' => 'field_bires_team_group', 'name' => 'team_group', 'label' => __( 'Блок на сторінці «Команда»', 'bires-theme' ), 'type' => 'select', 'choices' => [ 'managing_partner' => __( 'Керуючий партнер', 'bires-theme' ), 'partner' => __( 'Партнер', 'bires-theme' ), 'practice_head' => __( 'Керівники практик', 'bires-theme' ), 'team' => __( 'Команда', 'bires-theme' ) ], 'default_value' => 'team' ],
            [ 'key' => 'field_bires_team_quote', 'name' => 'team_quote', 'label' => __( 'Цитата (для партнерів)', 'bires-theme' ), 'type' => 'textarea', 'rows' => 3 ],
            [ 'key' => 'field_bires_team_practice', 'name' => 'team_practice', 'label' => __( 'Практика / спеціалізація', 'bires-theme' ), 'type' => 'text' ],
            [ 'key' => 'field_bires_team_lead', 'name' => 'team_lead', 'label' => __( 'Короткий опис', 'bires-theme' ), 'type' => 'textarea', 'rows' => 3, 'instructions' => __( 'Використовується в картці та мікророзмітці. Повна біографія — в основному редакторі.', 'bires-theme' ) ],
            [ 'key' => 'field_bires_team_email', 'name' => 'team_email', 'label' => 'Email', 'type' => 'email' ],
            [ 'key' => 'field_bires_team_phone', 'name' => 'team_phone', 'label' => __( 'Телефон', 'bires-theme' ), 'type' => 'text' ],
            [ 'key' => 'field_bires_team_education', 'name' => 'team_education', 'label' => __( 'Освіта', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'table', 'button_label' => __( 'Додати', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_team_edu_title', 'name' => 'title', 'label' => __( 'Заклад / ступінь', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_team_edu_years', 'name' => 'years', 'label' => __( 'Роки', 'bires-theme' ), 'type' => 'text' ],
            ] ],
            [ 'key' => 'field_bires_team_publications', 'name' => 'team_publications', 'label' => __( 'Публікації', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'table', 'button_label' => __( 'Додати публікацію', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_team_pub_title', 'name' => 'title', 'label' => __( 'Назва', 'bires-theme' ), 'type' => 'text' ],
                [ 'key' => 'field_bires_team_pub_url', 'name' => 'url', 'label' => __( 'Посилання', 'bires-theme' ), 'type' => 'url' ],
                [ 'key' => 'field_bires_team_pub_source', 'name' => 'source', 'label' => __( 'Видання', 'bires-theme' ), 'type' => 'text' ],
            ] ],
            [ 'key' => 'field_bires_team_services', 'name' => 'team_related_services', 'label' => __( 'Пов’язані послуги', 'bires-theme' ), 'type' => 'relationship', 'post_type' => [ 'page' ], 'filters' => [ 'search' ], 'return_format' => 'id' ],
            [ 'key' => 'field_bires_team_socials', 'name' => 'team_socials', 'label' => __( 'Соцмережі (для sameAs)', 'bires-theme' ), 'type' => 'repeater', 'layout' => 'table', 'button_label' => __( 'Додати', 'bires-theme' ), 'sub_fields' => [
                [ 'key' => 'field_bires_team_social_url', 'name' => 'url', 'label' => 'URL', 'type' => 'url' ],
            ] ],
        ],
        'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'team' ] ] ],
    ] );

    acf_add_local_field_group( [
        'key'      => 'group_bires_post',
        'title'    => __( 'Налаштування статті', 'bires-theme' ),
        'fields'   => [
            [ 'key' => 'field_bires_post_author', 'name' => 'post_team_author', 'label' => __( 'Автор (член команди)', 'bires-theme' ), 'type' => 'post_object', 'post_type' => [ 'team' ], 'return_format' => 'id', 'allow_null' => 1 ],
            [ 'key' => 'field_bires_post_related', 'name' => 'post_related_posts', 'label' => __( 'Схожі статті', 'bires-theme' ), 'type' => 'relationship', 'post_type' => [ 'post' ], 'filters' => [ 'search', 'taxonomy' ], 'max' => 5, 'return_format' => 'id', 'instructions' => __( 'Якщо не вибрано — підбираються автоматично за категорією/тегами.', 'bires-theme' ) ],
            [ 'key' => 'field_bires_post_cta', 'name' => 'post_cta_title', 'label' => __( 'Текст CTA-блоку в статті', 'bires-theme' ), 'type' => 'text', 'instructions' => __( 'Блок вставляється автоматично посередині статті. Щоб поставити його в конкретне місце — додайте шорткод [bires_cta].', 'bires-theme' ) ],
            [ 'key' => 'field_bires_post_services', 'name' => 'post_related_services', 'label' => __( 'Пов’язані послуги', 'bires-theme' ), 'type' => 'relationship', 'post_type' => [ 'page' ], 'filters' => [ 'search' ], 'return_format' => 'id' ],
        ],
        'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'post' ] ] ],
    ] );
}
add_action( 'acf/init', 'bires_acf_field_groups' );
