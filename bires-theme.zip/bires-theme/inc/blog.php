<?php

define( 'BIRES_POSTS_PER_PAGE', 11 );

function bires_blog_query( $query ) {
    if ( is_admin() || ! $query->is_main_query() ) {
        return;
    }
    if ( $query->is_home() || $query->is_category() || $query->is_tag() ) {
        $query->set( 'posts_per_page', BIRES_POSTS_PER_PAGE );
    }
}
add_action( 'pre_get_posts', 'bires_blog_query' );

function bires_reading_time( $post_id = null ) {
    $words = count( preg_split( '/\s+/u', trim( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ) ) ) );
    return max( 1, (int) ceil( $words / 200 ) );
}

/**
 * Adds stable ids to <h2> headings and returns [ content, toc items ].
 */
function bires_prepare_toc( $content ) {
    $items = [];
    $used  = [];
    $content = preg_replace_callback(
        '#<h2(\s[^>]*)?>(.*?)</h2>#is',
        function ( $m ) use ( &$items, &$used ) {
            $attrs = isset( $m[1] ) ? $m[1] : '';
            $text  = trim( wp_strip_all_tags( $m[2] ) );
            if ( '' === $text ) {
                return $m[0];
            }
            if ( preg_match( '/\sid=(["\'])(.*?)\1/i', $attrs, $id_match ) ) {
                $id = $id_match[2];
            } else {
                $base = sanitize_title( $text );
                $base = $base ? $base : 'section';
                $id   = $base;
                $n    = 2;
                while ( isset( $used[ $id ] ) ) {
                    $id = $base . '-' . $n++;
                }
                $attrs .= ' id="' . esc_attr( $id ) . '"';
            }
            $used[ $id ] = true;
            $items[]     = [ 'id' => $id, 'title' => $text ];
            return '<h2' . $attrs . '>' . $m[2] . '</h2>';
        },
        $content
    );
    return [ $content, $items ];
}

function bires_cta_markup() {
    $title = bires_field( 'post_cta_title' );
    $title = $title ? $title : __( 'Маєте питання щодо вашої ситуації? Отримайте консультацію юриста.', 'bires-theme' );
    ob_start();
    ?>
    <aside class="article-cta">
        <div class="article-cta__top">
            <p class="article-cta__text"><?php echo esc_html( $title ); ?></p>
            <span class="article-cta__logo" aria-hidden="true">BIRES</span>
        </div>
        <a class="article-cta__btn" href="<?php echo esc_url( bires_contact_url() ); ?>"><?php esc_html_e( 'Записатись на консультацію', 'bires-theme' ); ?></a>
    </aside>
    <?php
    return ob_get_clean();
}
add_shortcode( 'bires_cta', 'bires_cta_markup' );

function bires_insert_cta( $content ) {
    if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() || has_shortcode( get_post_field( 'post_content' ), 'bires_cta' ) ) {
        return $content;
    }
    $parts = preg_split( '#(?=<h2[\s>])#i', $content );
    if ( count( $parts ) >= 4 ) {
        $at = (int) floor( count( $parts ) / 2 ) + 1;
        array_splice( $parts, $at, 0, bires_cta_markup() );
        return implode( '', $parts );
    }
    return $content . bires_cta_markup();
}
add_filter( 'the_content', 'bires_insert_cta', 20 );

function bires_related_posts( $post_id, $count = 5 ) {
    $manual = array_filter( (array) bires_field( 'post_related_posts', $post_id ) );
    if ( $manual ) {
        return get_posts( [ 'suppress_filters' => false, 'post__in' => array_map( 'intval', $manual ), 'orderby' => 'post__in', 'posts_per_page' => $count ] );
    }

    $args = [
        'suppress_filters' => false,
        'post__not_in'        => [ $post_id ],
        'posts_per_page'      => $count,
        'ignore_sticky_posts' => true,
        'tax_query'           => [ 'relation' => 'OR' ],
    ];
    $cats = wp_get_post_categories( $post_id );
    $tags = wp_get_post_tags( $post_id, [ 'fields' => 'ids' ] );
    if ( $cats ) {
        $args['tax_query'][] = [ 'taxonomy' => 'category', 'terms' => $cats ];
    }
    if ( $tags ) {
        $args['tax_query'][] = [ 'taxonomy' => 'post_tag', 'terms' => $tags ];
    }
    $posts = count( $args['tax_query'] ) > 1 ? get_posts( $args ) : [];

    if ( count( $posts ) < $count ) {
        $posts = array_merge( $posts, get_posts( [
            'suppress_filters' => false,
            'post__not_in'   => array_merge( [ $post_id ], wp_list_pluck( $posts, 'ID' ) ),
            'posts_per_page' => $count - count( $posts ),
        ] ) );
    }
    return $posts;
}

function bires_strip_blank_targets( $content ) {
    return preg_replace( '#\s+target=(["\'])_blank\1#i', '', $content );
}
add_filter( 'the_content', 'bires_strip_blank_targets', 30 );
