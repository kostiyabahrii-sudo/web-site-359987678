<?php
/**
 * Сайт, перенесений зі старого (bires.com.ua): разові правки головної під макет. Застосовуються самі
 * при першому відкритті адмінки після оновлення теми; потім усе редагується як завжди (Сторінки → Головна).
 * - «Для фізичних осіб»: п’ять практик, як у макеті (на старому сайті в цьому розділі було лише дві).
 * - «Наші клієнти»: логотипи з макета, якщо логотипів старого сайту немає в медіатеці цього сайту.
 */

define( 'BIRES_MIGRATED_FIXES', '1' );

/** Практики для фізичних осіб у макеті — адреси сторінок старого сайту (українська версія). */
function bires_migrated_personal_slugs() {
    return [ 'cimejne-pravo', 'otrymannya-dozvolu-na-immigracziyu-v-ukrayinu', 'kryminalne-pravo', 'ctyagnennya-zaborgovanosti-2', 'budivnycztvo-i-majno' ];
}

function bires_migrated_page_lang( $id ) {
    $details = apply_filters( 'wpml_post_language_details', null, $id );
    if ( is_array( $details ) && ! empty( $details['language_code'] ) ) {
        return $details['language_code'];
    }
    return in_array( $id, function_exists( 'bires_lang_foreign_posts' ) ? bires_lang_foreign_posts() : [], true ) ? 'ru' : 'uk';
}

function bires_migrated_uk_page( $slug ) {
    foreach ( get_posts( [ 'post_type' => 'page', 'name' => $slug, 'post_status' => 'publish', 'posts_per_page' => -1, 'suppress_filters' => true ] ) as $page ) {
        if ( 'uk' === bires_migrated_page_lang( $page->ID ) ) {
            return $page->ID;
        }
    }
    return 0;
}

/** Чи є файл хоча б одного логотипу в медіатеці цього сайту. */
function bires_migrated_logos_present( $home ) {
    $count = (int) get_post_meta( $home, 'home_logos', true );
    for ( $i = 0; $i < $count; $i++ ) {
        $file = get_attached_file( (int) get_post_meta( $home, 'home_logos_' . $i . '_image', true ) );
        if ( $file && file_exists( $file ) ) {
            return true;
        }
    }
    return false;
}

function bires_migrated_fixes() {
    if ( ! get_option( 'bires_old_media' ) || ! function_exists( 'update_field' ) ) {
        return;
    }
    $done = (array) get_option( 'bires_migrated_fixes', [] );
    $home = (int) get_option( 'page_on_front' );
    if ( ! $home ) {
        return;
    }
    $homes = [ 'uk' => $home ];
    // Російська головна — лише з WPML (без нього російські сторінки приховано)
    if ( apply_filters( 'wpml_default_language', null ) ) {
        $ru = (int) apply_filters( 'wpml_object_id', $home, 'page', false, 'ru' );
        if ( $ru ) {
            $homes['ru'] = $ru;
        }
    }
    $personal = array_filter( array_map( 'bires_migrated_uk_page', bires_migrated_personal_slugs() ) );

    foreach ( $homes as $lang => $page_id ) {
        if ( ( $done[ $lang ] ?? '' ) === BIRES_MIGRATED_FIXES ) {
            continue;
        }
        if ( $personal && ! get_post_meta( $page_id, 'home_personal_services', true ) ) {
            $ids = 'uk' === $lang ? $personal : array_filter( array_map( function ( $id ) use ( $lang ) {
                return (int) apply_filters( 'wpml_object_id', $id, 'page', false, $lang );
            }, $personal ) );
            update_field( 'home_personal_services', array_map( 'strval', array_values( $ids ) ), $page_id );
        }
        if ( ! bires_migrated_logos_present( $page_id ) ) {
            update_field( 'home_logos', bires_demo_logos(), $page_id );
        }
        $done[ $lang ] = BIRES_MIGRATED_FIXES;
    }
    update_option( 'bires_migrated_fixes', $done, false );
}
add_action( 'admin_init', 'bires_migrated_fixes', 30 );
