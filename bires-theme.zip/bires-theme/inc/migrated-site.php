<?php
/**
 * Сайт, перенесений зі старого (bires.com.ua): правки головної й налаштувань під макет.
 * Після імпорту (inc/import-old.php) застосовуються одразу; на сайті, перенесеному архівом All-in-One WP Migration, —
 * самі при першому відкритті адмінки. Далі все редагується як завжди (Сторінки → Головна, Налаштування сайту).
 * - «Для фізичних осіб»: п’ять практик, як у макеті (на старому сайті в цьому розділі було лише дві).
 * - «Наші клієнти»: логотипи з макета.
 * - «Наші досягнення» і цитата: як у демо, якщо порожньо (на старому сайті їх не було).
 * - Налаштування сайту: сторінки контактів, мапи сайту й політик — перенесені, соцмережі — старого сайту.
 */

define( 'BIRES_MIGRATED_FIXES', '1' );

/** Практики для фізичних осіб у макеті — адреси сторінок старого сайту (українська версія). */
function bires_migrated_personal_slugs() {
    return [ 'cimejne-pravo', 'otrymannya-dozvolu-na-immigracziyu-v-ukrayinu', 'kryminalne-pravo', 'ctyagnennya-zaborgovanosti-2', 'budivnycztvo-i-majno' ];
}

function bires_migrated_page_lang( $id ) {
    $details = apply_filters( 'wpml_post_language_details', null, $id );
    if ( is_array( $details ) && ! empty( $details['language_code'] ) ) {
        return $details['language_code'];
    }
    return in_array( $id, function_exists( 'bires_lang_foreign_posts' ) ? bires_lang_foreign_posts() : [], true ) ? 'ru' : 'uk';
}

function bires_migrated_uk_page( $slug ) {
    foreach ( get_posts( [ 'post_type' => 'page', 'name' => $slug, 'post_status' => 'publish', 'posts_per_page' => -1, 'suppress_filters' => true ] ) as $page ) {
        if ( 'uk' === bires_migrated_page_lang( $page->ID ) ) {
            return $page->ID;
        }
    }
    return 0;
}

/** Чи є файл хоча б одного логотипу в медіатеці цього сайту. */
function bires_migrated_logos_present( $home ) {
    $count = (int) get_post_meta( $home, 'home_logos', true );
    for ( $i = 0; $i < $count; $i++ ) {
        $file = get_attached_file( (int) get_post_meta( $home, 'home_logos_' . $i . '_image', true ) );
        if ( $file && file_exists( $file ) ) {
            return true;
        }
    }
    return false;
}

/** Головні сторінки сайту: українська й, з WPML, російська. */
function bires_migrated_homes() {
    $home = (int) get_option( 'page_on_front' );
    if ( ! $home ) {
        return [];
    }
    $homes = [ 'uk' => $home ];
    // Російська головна — лише з WPML (без нього російські сторінки приховано)
    if ( apply_filters( 'wpml_default_language', null ) ) {
        $ru = (int) apply_filters( 'wpml_object_id', $home, 'page', false, 'ru' );
        if ( $ru && $ru !== $home ) {
            $homes['ru'] = $ru;
        }
    }
    return $homes;
}

/** «Для фізичних осіб» і логотипи клієнтів на головній мовою $lang. */
function bires_migrated_home_design( $page_id, $lang, $replace_logos ) {
    $personal = array_filter( array_map( 'bires_migrated_uk_page', bires_migrated_personal_slugs() ) );
    if ( $personal && ! get_post_meta( $page_id, 'home_personal_services', true ) ) {
        $ids = 'uk' === $lang ? $personal : array_filter( array_map( function ( $id ) use ( $lang ) {
            return (int) apply_filters( 'wpml_object_id', $id, 'page', false, $lang );
        }, $personal ) );
        update_field( 'home_personal_services', array_map( 'strval', array_values( $ids ) ), $page_id );
    }
    if ( $replace_logos || ! bires_migrated_logos_present( $page_id ) ) {
        update_field( 'home_logos', bires_demo_logos(), $page_id );
    }
}

/** «Наші досягнення» і цитата керівника — з демо, якщо на головній їх немає. */
function bires_migrated_home_extras( $home ) {
    if ( ! get_field( 'home_achievements', $home ) ) {
        update_field( 'home_achievements', [
            [ 'title' => 'Юридичний супровід міжнародного SaaS-бізнесу', 'text' => 'Юридичний супровід SaaS-платформи на етапі розвитку продукту: підготовка договорів, політик конфіденційності, умов користування та правовий аудит бізнес-процесів.', 'tags' => 'SaaS & IT, B2B супровід', 'period' => '2025-2026', 'image' => bires_demo_asset( 'ach-1.jpg' ) ],
            [ 'title' => 'Захист інтересів у податковому спорі', 'text' => 'Оскарження податкового повідомлення-рішення на 4.2 млн грн.', 'tags' => 'Податки', 'period' => '2024', 'image' => bires_demo_asset( 'ach-2.jpg' ) ],
        ], $home );
    }
    $person = get_page_by_path( 'ihor-bahrii', OBJECT, 'team' );
    if ( $person && ! get_field( 'home_quote_person', $home ) ) {
        update_field( 'home_quote_person', $person->ID, $home );
        update_field( 'home_quote_role', 'СEO компанії Bires', $home );
        update_field( 'home_quote_photo', bires_demo_asset( 'team-oleh.jpg' ), $home );
    }
}

/** Налаштування сайту: службові сторінки — перенесені (демо-сторінки після імпорту в кошику), соцмережі старого сайту. */
function bires_migrated_site_settings() {
    $pages = [
        'contact_page' => 'kontakty-2',
        'sitemap_page' => 'karta-sajtu',
        'privacy_page' => 'polityka-konfidenczijnosti',
        'terms_page'   => 'polityka-po-roboti-z-personalnymy-danymy',
    ];
    foreach ( $pages as $key => $slug ) {
        $current = (int) get_field( $key, 'option', false );
        $page    = bires_migrated_uk_page( $slug );
        if ( $page && ( ! $current || 'publish' !== get_post_status( $current ) ) ) {
            update_field( $key, $page, 'option' );
        }
    }
    $socials = [
        'social_telegram'  => 'https://t.me/+380961062056',
        'social_instagram' => 'https://www.instagram.com/bires_law_firm/',
        'social_facebook'  => 'https://www.facebook.com/BiresLawFirm',
    ];
    foreach ( $socials as $key => $url ) {
        $current = (string) get_field( $key, 'option', false );
        // Порожньо або заглушка демо (https://instagram.com/ без сторінки)
        if ( '' === $current || preg_match( '#^https?://(www\.)?(instagram|facebook)\.com/?$#', $current ) ) {
            update_field( $key, $url, 'option' );
        }
    }
}

/** Одразу після імпорту зі старого сайту. */
function bires_migrated_after_import() {
    if ( ! function_exists( 'update_field' ) ) {
        return;
    }
    $done = [];
    foreach ( bires_migrated_homes() as $lang => $page_id ) {
        bires_migrated_home_design( $page_id, $lang, true );
        if ( 'uk' === $lang ) {
            bires_migrated_home_extras( $page_id );
        }
        $done[ $lang ] = BIRES_MIGRATED_FIXES;
    }
    bires_migrated_site_settings();
    update_option( 'bires_migrated_fixes', $done, false );
}

/** Сайт, перенесений архівом: разово при першому відкритті адмінки. */
function bires_migrated_fixes() {
    if ( ! get_option( 'bires_old_media' ) || ! function_exists( 'update_field' ) ) {
        return;
    }
    $done = (array) get_option( 'bires_migrated_fixes', [] );
    foreach ( bires_migrated_homes() as $lang => $page_id ) {
        if ( ( $done[ $lang ] ?? '' ) === BIRES_MIGRATED_FIXES ) {
            continue;
        }
        bires_migrated_home_design( $page_id, $lang, false );
        $done[ $lang ] = BIRES_MIGRATED_FIXES;
    }
    update_option( 'bires_migrated_fixes', $done, false );
}
add_action( 'admin_init', 'bires_migrated_fixes', 30 );
