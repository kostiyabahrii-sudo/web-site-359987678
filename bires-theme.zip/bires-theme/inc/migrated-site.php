<?php
/**
 * Сайт, перенесений зі старого (bires.com.ua): правки головної й налаштувань під макет.
 * Після імпорту (inc/import-old.php) застосовуються одразу; на сайті, перенесеному архівом All-in-One WP Migration, —
 * самі при першому відкритті адмінки. Далі все редагується як завжди (Сторінки → Головна, Налаштування сайту).
 * - «Для фізичних осіб»: п’ять практик, як у макеті (на старому сайті в цьому розділі було лише дві).
 * - «Наші клієнти»: логотипи з макета.
 * - «Наші досягнення» і цитата: як у демо, якщо порожньо (на старому сайті їх не було).
 * - Налаштування сайту: сторінки контактів, мапи сайту й політик — перенесені, соцмережі — старого сайту.
 * - «Контакти», блок «Офіс»: офіс Manhattan City з фото й мапою, як у макеті (на старому сайті — лише адреса).
 * - Головна, «Правові інсайти»: три статті старого сайту з макета, з фото з макета.
 * - Порожні дублікати російською (5 статей, 8 сторінок) — у чернетки.
 */

define( 'BIRES_MIGRATED_FIXES', '3' );

/** Практики для фізичних осіб у макеті — адреси сторінок старого сайту (українська версія). */
function bires_migrated_personal_slugs() {
    return [ 'cimejne-pravo', 'otrymannya-dozvolu-na-immigracziyu-v-ukrayinu', 'kryminalne-pravo', 'ctyagnennya-zaborgovanosti-2', 'budivnycztvo-i-majno' ];
}

function bires_migrated_page_lang( $id ) {
    $details = apply_filters( 'wpml_post_language_details', null, $id );
    if ( is_array( $details ) && ! empty( $details['language_code'] ) ) {
        return $details['language_code'];
    }
    return in_array( $id, function_exists( 'bires_lang_foreign_posts' ) ? bires_lang_foreign_posts() : [], true ) ? 'ru' : 'uk';
}

function bires_migrated_uk_page( $slug ) {
    foreach ( get_posts( [ 'post_type' => 'page', 'name' => $slug, 'post_status' => 'publish', 'posts_per_page' => -1, 'suppress_filters' => true ] ) as $page ) {
        if ( 'uk' === bires_migrated_page_lang( $page->ID ) ) {
            return $page->ID;
        }
    }
    return 0;
}

/** Чи є файл хоча б одного логотипу в медіатеці цього сайту. */
function bires_migrated_logos_present( $home ) {
    $count = (int) get_post_meta( $home, 'home_logos', true );
    for ( $i = 0; $i < $count; $i++ ) {
        $file = get_attached_file( (int) get_post_meta( $home, 'home_logos_' . $i . '_image', true ) );
        if ( $file && file_exists( $file ) ) {
            return true;
        }
    }
    return false;
}

/** Головні сторінки сайту: українська й, з WPML, російська. */
function bires_migrated_homes() {
    $home = (int) get_option( 'page_on_front' );
    if ( ! $home ) {
        return [];
    }
    $homes = [ 'uk' => $home ];
    // Російська головна — лише з WPML (без нього російські сторінки приховано)
    if ( apply_filters( 'wpml_default_language', null ) ) {
        $ru = (int) apply_filters( 'wpml_object_id', $home, 'page', false, 'ru' );
        if ( $ru && $ru !== $home ) {
            $homes['ru'] = $ru;
        }
    }
    return $homes;
}

/** «Для фізичних осіб» і логотипи клієнтів на головній мовою $lang. */
function bires_migrated_home_design( $page_id, $lang, $replace_logos ) {
    $personal = array_filter( array_map( 'bires_migrated_uk_page', bires_migrated_personal_slugs() ) );
    if ( $personal && ! get_post_meta( $page_id, 'home_personal_services', true ) ) {
        $ids = 'uk' === $lang ? $personal : array_filter( array_map( function ( $id ) use ( $lang ) {
            return (int) apply_filters( 'wpml_object_id', $id, 'page', false, $lang );
        }, $personal ) );
        update_field( 'home_personal_services', array_map( 'strval', array_values( $ids ) ), $page_id );
    }
    if ( $replace_logos || ! bires_migrated_logos_present( $page_id ) ) {
        update_field( 'home_logos', bires_demo_logos(), $page_id );
    }
}

/** «Наші досягнення» і цитата керівника — з демо, якщо на головній їх немає. */
function bires_migrated_home_extras( $home ) {
    if ( ! get_field( 'home_achievements', $home ) ) {
        update_field( 'home_achievements', [
            [ 'title' => 'Юридичний супровід міжнародного SaaS-бізнесу', 'text' => 'Юридичний супровід SaaS-платформи на етапі розвитку продукту: підготовка договорів, політик конфіденційності, умов користування та правовий аудит бізнес-процесів.', 'tags' => 'SaaS & IT, B2B супровід', 'period' => '2025-2026', 'image' => bires_demo_asset( 'ach-1.jpg' ) ],
            [ 'title' => 'Захист інтересів у податковому спорі', 'text' => 'Оскарження податкового повідомлення-рішення на 4.2 млн грн.', 'tags' => 'Податки', 'period' => '2024', 'image' => bires_demo_asset( 'ach-2.jpg' ) ],
        ], $home );
    }
    $person = get_page_by_path( 'ihor-bahrii', OBJECT, 'team' );
    if ( $person && ! get_field( 'home_quote_person', $home ) ) {
        update_field( 'home_quote_person', $person->ID, $home );
        update_field( 'home_quote_role', 'СEO компанії Bires', $home );
        update_field( 'home_quote_photo', bires_demo_asset( 'team-oleh.jpg' ), $home );
    }
}

/** Налаштування сайту: службові сторінки — перенесені (демо-сторінки після імпорту в кошику), соцмережі старого сайту. */
function bires_migrated_site_settings() {
    // Адреси старого сайту («kontakty-2» — так адресу контактів змінює копія бази без WPML)
    $pages = [
        'contact_page' => [ 'kontakty', 'kontakty-2' ],
        'sitemap_page' => [ 'karta-sajtu' ],
        'privacy_page' => [ 'polityka-konfidenczijnosti' ],
        'terms_page'   => [ 'polityka-po-roboti-z-personalnymy-danymy' ],
    ];
    foreach ( $pages as $key => $slugs ) {
        $current = (int) get_field( $key, 'option', false );
        $page    = 0;
        foreach ( $slugs as $slug ) {
            $page = $page ? $page : bires_migrated_uk_page( $slug );
        }
        if ( $page && ( ! $current || 'publish' !== get_post_status( $current ) ) ) {
            update_field( $key, $page, 'option' );
        }
    }
    $socials = [
        'social_telegram'  => 'https://t.me/+380961062056',
        'social_instagram' => 'https://www.instagram.com/bires_law_firm/',
        'social_facebook'  => 'https://www.facebook.com/BiresLawFirm',
    ];
    foreach ( $socials as $key => $url ) {
        $current = (string) get_field( $key, 'option', false );
        // Порожньо або заглушка демо (https://instagram.com/ без сторінки)
        if ( '' === $current || preg_match( '#^https?://(www\.)?(instagram|facebook)\.com/?$#', $current ) ) {
            update_field( $key, $url, 'option' );
        }
    }
}

/**
 * «Контакти», блок «Офіс» — як у макеті: Manhattan City, адреса, три фото (з теми) і мапа до офісу.
 * Лише якщо блок ще такий, яким його переніс імпорт (назва «Bires Law Firm» або порожня, без фото), — правки в адмінці не чіпаємо.
 */
function bires_migrated_contacts_office() {
    $pages = get_posts( [ 'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => -1, 'suppress_filters' => true, 'meta_key' => '_wp_page_template', 'meta_value' => 'page-templates/contact.php' ] );
    foreach ( $pages as $page ) {
        $title = (string) get_field( 'office_title', $page->ID );
        if ( ( '' !== $title && 'Bires Law Firm' !== $title ) || get_field( 'office_gallery', $page->ID ) ) {
            continue;
        }
        update_field( 'office_title', 'Manhattan City', $page->ID );
        update_field( 'office_gallery', [
            [ 'image' => bires_demo_asset( 'office-1.jpg' ) ],
            [ 'image' => bires_demo_asset( 'office-2.jpg' ) ],
            [ 'image' => bires_demo_asset( 'office-3.jpg' ) ],
        ], $page->ID );
        update_field( 'map_query', 'Берестейський проспект 11, Київ', $page->ID );
        update_field( 'map_link', 'https://maps.google.com/?q=' . rawurlencode( 'Берестейський проспект 11, Київ' ), $page->ID );
    }
}

/** Статті блоку «Правові інсайти» в макеті — адреси статей старого сайту й фото з макета (assets/demo). */
function bires_migrated_insight_posts() {
    return [
        'derzhpraczi-ta-mobing-novi-pravyla-perevirok-z-zhovtnya-2025-roku'          => 'post-1.jpg',
        'pomylky-pry-rozblokuvanni-podatkovykh-nakladnykh'                           => 'post-2.jpg',
        'zakonoproekt-13507-9-oznak-trudovykh-vidnosyn-ta-shtrafy-dlia-robotodavtsiv' => 'post-3.jpg',
    ];
}

/**
 * Головна, «Правові інсайти» — як у макеті: ці три статті, обкладинки — фото з макета (попередня обкладинка
 * лишається в медіатеці, її id — у _bires_old_thumb). Якщо статті на головній вже вибрано вручну — не чіпаємо.
 */
function bires_migrated_home_insights( $home ) {
    if ( get_field( 'home_posts', $home, false ) ) {
        return;
    }
    $ids = [];
    foreach ( bires_migrated_insight_posts() as $slug => $photo ) {
        foreach ( get_posts( [ 'post_type' => 'post', 'name' => $slug, 'post_status' => 'publish', 'posts_per_page' => -1, 'suppress_filters' => true ] ) as $post ) {
            if ( 'uk' !== bires_migrated_page_lang( $post->ID ) ) {
                continue;
            }
            if ( '' === get_post_meta( $post->ID, '_bires_old_thumb', true ) ) {
                update_post_meta( $post->ID, '_bires_old_thumb', (int) get_post_thumbnail_id( $post->ID ) );
                set_post_thumbnail( $post->ID, bires_demo_asset( $photo ) );
            }
            $ids[] = (string) $post->ID;
            break;
        }
    }
    if ( $ids ) {
        update_field( 'home_posts', $ids, $home );
    }
}

/** Одразу після імпорту зі старого сайту. */
function bires_migrated_after_import() {
    if ( ! function_exists( 'update_field' ) ) {
        return;
    }
    $done = [];
    foreach ( bires_migrated_homes() as $lang => $page_id ) {
        bires_migrated_home_design( $page_id, $lang, true );
        if ( 'uk' === $lang ) {
            bires_migrated_home_extras( $page_id );
            bires_migrated_home_insights( $page_id );
        }
        $done[ $lang ] = BIRES_MIGRATED_FIXES;
    }
    bires_migrated_site_settings();
    bires_migrated_contacts_office();
    update_option( 'bires_migrated_fixes', $done, false );
}

/** Сайт, перенесений архівом: разово при першому відкритті адмінки. */
/**
 * Порожні дублікати російською (inc/languages.php → bires_lang_stubs): на сайті вони й так сховані, тут — у чернетки
 * з позначкою. Через wp_update_post, щоб SEO-плагін (карта сайту Yoast) теж дізнався. Не видаляємо.
 */
function bires_migrated_hide_stubs() {
    foreach ( bires_lang_stub_ids() as $id ) {
        wp_update_post( [ 'ID' => $id, 'post_status' => 'draft' ] );
        update_post_meta( $id, '_bires_hidden_stub', __( 'Порожній дублікат російською — є українська версія', 'bires-theme' ) );
    }
}

/** Кейси UNDP і ShipHawk з макета: кольорові логотипи для вікна кейсу (у попередніх версіях їх не було). Разово. */
function bires_case_dark_logos_once() {
    if ( get_option( 'bires_case_dark_logos' ) || ! function_exists( 'update_field' ) || ! function_exists( 'bires_demo_asset' ) ) {
        return;
    }
    foreach ( [ 'undp' => 'logo-undp.png', 'shiphawk' => 'logo-shiphawk.png' ] as $slug => $file ) {
        $case = get_page_by_path( $slug, OBJECT, 'case' );
        if ( $case && ! get_field( 'case_logo_dark', $case->ID, false ) ) {
            update_field( 'case_logo_dark', bires_demo_asset( $file ), $case->ID );
        }
    }
    update_option( 'bires_case_dark_logos', 1, false );
}
add_action( 'admin_init', 'bires_case_dark_logos_once', 30 );

/**
 * Логотипи клієнтів із теми — кольорові оригінали замість сірих знімків: сітка «Наші клієнти» (client-01…16)
 * і логотипи у вікнах кейсів (logo-*.png). Файл замінюється на місці: вкладення, його адреса й вибір у полях
 * лишаються ті самі; замінюються лише файли, що змінилися в темі. Разово для кожної версії логотипів.
 * 2 — кольорові ShipHawk і «Хвиля здоровʼя»; 3 — кольоровий RG.
 */
define( 'BIRES_CLIENT_LOGOS', 3 );

function bires_client_logos_refresh_once() {
    if ( BIRES_CLIENT_LOGOS <= (int) get_option( 'bires_client_logos' ) || ! current_user_can( 'manage_options' ) ) {
        return;
    }
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $front = (int) get_option( 'page_on_front' );
    $count = $front ? (int) get_post_meta( $front, 'home_logos', true ) : 0;
    $ids   = [];
    for ( $i = 0; $i < $count; $i++ ) {
        $ids[] = (int) get_post_meta( $front, "home_logos_{$i}_image", true );
    }
    foreach ( get_posts( [ 'post_type' => 'case', 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids', 'suppress_filters' => false ] ) as $case_id ) {
        $ids[] = (int) get_post_meta( $case_id, 'case_logo', true );
        $ids[] = (int) get_post_meta( $case_id, 'case_logo_dark', true );
    }
    $sources = array_merge( (array) glob( get_template_directory() . '/assets/demo/client-*.png' ), (array) glob( get_template_directory() . '/assets/demo/logo-*.png' ) );
    foreach ( array_filter( array_unique( $ids ) ) as $id ) {
        $slug   = (string) get_post_field( 'post_name', $id );
        $file   = get_attached_file( $id, true );
        $source = '';
        foreach ( $sources as $candidate ) {
            if ( function_exists( 'bires_demo_slug_is' ) && bires_demo_slug_is( $slug, $candidate ) ) {
                $source = $candidate;
            }
        }
        if ( ! $source || ! $file || md5_file( $source ) === get_post_meta( $id, '_bires_demo_hash', true ) ) {
            continue;
        }
        $att  = get_post( $id );
        $meta = wp_get_attachment_metadata( $att->ID );
        foreach ( isset( $meta['sizes'] ) ? (array) $meta['sizes'] : [] as $size ) {
            if ( ! empty( $size['file'] ) ) {
                wp_delete_file( path_join( dirname( $file ), $size['file'] ) );
            }
        }
        wp_mkdir_p( dirname( $file ) );
        if ( copy( $source, $file ) ) {
            wp_update_attachment_metadata( $att->ID, wp_generate_attachment_metadata( $att->ID, $file ) );
            update_post_meta( $att->ID, '_bires_demo_hash', md5_file( $source ) );
        }
    }
    update_option( 'bires_client_logos', BIRES_CLIENT_LOGOS, false );
}
add_action( 'admin_init', 'bires_client_logos_refresh_once', 30 );

/**
 * Тег сфери діяльності у відгуках на головній — лише там, де сферу прямо названо в самому відгуку
 * (у тексті, імені чи назві компанії). Решту заповнюють у «Головна → Відгуки». Лише доповнюємо порожні поля. Разово.
 */
function bires_review_badges() {
    return [
        'кентербері'       => __( 'Будівництво', 'bires-theme' ),          // «…забудови житлового комплексу… в галузі будівництва»
        'фітнес-клуб'      => __( 'Фітнес', 'bires-theme' ),               // «мережа фітнес-клубів «Малібу»»
        'завод бруківки'   => __( 'Виробництво', 'bires-theme' ),          // ТОВ «Бучанський завод бруківки»
        'genius marketing' => __( 'Маркетинг', 'bires-theme' ),            // Genius Marketing
        'еко-грінко'       => __( 'Управління відходами', 'bires-theme' ), // «Європейський досвід управління відходами» — на логотипі компанії
    ];
}

function bires_review_badges_once() {
    if ( 1 <= (int) get_option( 'bires_review_badges' ) || ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $front = (int) get_option( 'page_on_front' );
    $count = $front ? (int) get_post_meta( $front, 'home_reviews', true ) : 0;
    for ( $i = 0; $i < $count; $i++ ) {
        if ( '' !== trim( (string) get_post_meta( $front, "home_reviews_{$i}_badge", true ) ) ) {
            continue;
        }
        $who = mb_strtolower( get_post_meta( $front, "home_reviews_{$i}_name", true ) . ' ' . get_post_meta( $front, "home_reviews_{$i}_role", true ) );
        foreach ( bires_review_badges() as $needle => $badge ) {
            if ( false !== mb_strpos( $who, $needle ) ) {
                update_post_meta( $front, "home_reviews_{$i}_badge", $badge );
                update_post_meta( $front, "_home_reviews_{$i}_badge", 'field_bires_home_review_badge' );
                break;
            }
        }
    }
    update_option( 'bires_review_badges', 1, false );
}
add_action( 'admin_init', 'bires_review_badges_once', 30 );

/**
 * Логотипи компаній у картках відгуків — справжні файли зі старого сайту (стрічка клієнтів, uploads/2023/10),
 * якщо вони є в папці завантажень. Файл додається в медіатеку без копіювання. Лише відгуки без логотипа. Разово.
 */
function bires_review_old_logos() {
    return [
        'сафарі'    => '2023/10/safary.png',          // ТОВ «Сафарі Трейд»
        'luckylook' => '2023/10/laky-luk.gif',        // LuckyLOOK
        'restoria'  => '2023/10/restoriya-grup.jpg',  // мережа «Малібу» та Restoria Group
    ];
}

function bires_review_old_logos_once() {
    if ( 1 <= (int) get_option( 'bires_review_old_logos' ) || ! current_user_can( 'manage_options' ) ) {
        return;
    }
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $uploads = wp_get_upload_dir();
    $front   = (int) get_option( 'page_on_front' );
    $count   = $front ? (int) get_post_meta( $front, 'home_reviews', true ) : 0;
    for ( $i = 0; $i < $count; $i++ ) {
        if ( (int) get_post_meta( $front, "home_reviews_{$i}_logo", true ) ) {
            continue;
        }
        $who = mb_strtolower( get_post_meta( $front, "home_reviews_{$i}_name", true ) . ' ' . get_post_meta( $front, "home_reviews_{$i}_role", true ) );
        foreach ( bires_review_old_logos() as $needle => $rel ) {
            $path = trailingslashit( $uploads['basedir'] ) . $rel;
            if ( false === mb_strpos( $who, $needle ) || ! file_exists( $path ) ) {
                continue;
            }
            $id = attachment_url_to_postid( trailingslashit( $uploads['baseurl'] ) . $rel );
            if ( ! $id ) {
                $type = wp_check_filetype( $path );
                $id   = wp_insert_attachment( [ 'post_mime_type' => $type['type'], 'post_title' => pathinfo( $path, PATHINFO_FILENAME ), 'post_status' => 'inherit' ], $path );
            }
            // Запис зі старої бази буває без розмірів — рахуємо їх за файлом
            if ( $id && ! is_wp_error( $id ) ) {
                $meta = wp_get_attachment_metadata( $id );
                if ( empty( $meta['width'] ) ) {
                    wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $path ) );
                }
            }
            if ( $id && ! is_wp_error( $id ) ) {
                update_post_meta( $front, "home_reviews_{$i}_logo", (int) $id );
                update_post_meta( $front, "_home_reviews_{$i}_logo", 'field_bires_home_review_logo' );
            }
            break;
        }
    }
    update_option( 'bires_review_old_logos', 1, false );
}
add_action( 'admin_init', 'bires_review_old_logos_once', 30 );

/** Тексти першого екрана сторінки «Послуги» з макета. */
function bires_listing_hero() {
    return [
        'title' => 'Сучасний підхід до юридичної практики',
        'text'  => 'Представляємо інтереси бізнесу і фізичних осіб незалежно від складності ситуації.',
    ];
}

/**
 * «Послуги»: перший екран як у макеті. Після перенесення зі старого сайту там стояли назва сторінки й довгий
 * перелік галузей — замінюємо лише їх (порожній заголовок і цей старий текст); інші, вписані вручну, не чіпаємо. Разово.
 */
function bires_listing_hero_once() {
    if ( 1 <= (int) get_option( 'bires_listing_hero' ) || ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $id = function_exists( 'bires_services_listing_id' ) ? (int) bires_services_listing_id() : 0;
    if ( $id ) {
        $hero = bires_listing_hero();
        if ( '' === trim( (string) get_post_meta( $id, 'hero_title', true ) ) ) {
            update_post_meta( $id, 'hero_title', $hero['title'] );
            update_post_meta( $id, '_hero_title', 'field_bires_hero_title' );
        }
        $text = trim( (string) get_post_meta( $id, 'hero_text', true ) );
        if ( '' === $text || 0 === mb_strpos( $text, 'Правова допомога в сферах' ) ) {
            update_post_meta( $id, 'hero_text', $hero['text'] );
            update_post_meta( $id, '_hero_text', 'field_bires_hero_text' );
        }
    }
    update_option( 'bires_listing_hero', 1, false );
}
add_action( 'admin_init', 'bires_listing_hero_once', 30 );

/** Категорії фільтра «Послуги для бізнесу» (як у макеті й демо): slug => назва. */
function bires_service_filter_cats() {
    return [
        'launch'     => 'Запуск бізнесу',
        'support'    => 'Юридичний супровід',
        'tax'        => 'Податки та фінанси',
        'litigation' => 'Судові та кримінальні справи',
        'assets'     => 'Активи та нерухомість',
    ];
}

/**
 * Фільтр «Послуги для бізнесу»: після перенесення зі старого сайту справжні послуги не мали категорій фільтра,
 * тож смужки фільтра не було. Розставляємо категорії за змістом практик (за адресою сторінки або назвою групи).
 * Лише послугам без категорій фільтра — змінені вручну не чіпаємо. Разово.
 */
function bires_service_filters_once() {
    if ( 1 <= (int) get_option( 'bires_service_filters' ) || ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $cats = bires_service_filter_cats();
    foreach ( $cats as $slug => $name ) {
        if ( ! term_exists( $slug, 'service_category' ) ) {
            wp_insert_term( $name, 'service_category', [ 'slug' => $slug ] );
        }
    }
    $pages  = [
        'bankrutstvo-yurydychnyh-osib'       => [ 'tax', 'litigation' ],
        'kryminalne-pravo'                    => [ 'litigation' ],
        'intelektualne-pravo'                 => [ 'assets' ],
        'ctyagnennya-zaborgovanosti-2'        => [ 'litigation', 'tax' ],
        'ctyagnennya-zaborgovanosti'          => [ 'litigation', 'tax' ],
        'ekspres-likvidacziya-pidpryyemstva'  => [ 'support' ],
        'yurydychnyj-suprovid-biznesu'        => [ 'support' ],
        'mytni-spory'                         => [ 'tax', 'litigation' ],
        'zmina-mitniczeyu-kodu-ukt-zed-tovaru' => [ 'tax' ],
        'suprovid-tendernyh-zakupivel'        => [ 'support' ],
        'reyestracziya-pidpryyemstv'          => [ 'launch' ],
        'cudovi-spory'                        => [ 'litigation' ],
        'liczenziyi-dozvoly-deklaracziyi'     => [ 'launch' ],
        'rozrobka-dogovoriv'                  => [ 'support' ],
        'budivnycztvo-i-majno'                => [ 'assets' ],
    ];
    $groups = [
        'Податкова практика'                => [ 'tax' ],
        'Кадрові рішення та охорона праці' => [ 'support' ],
    ];
    foreach ( function_exists( 'bires_top_services' ) ? bires_top_services() : [] as $service ) {
        if ( 'personal' === bires_field( 'service_audience', $service->ID ) || ! isset( $pages[ $service->post_name ] ) ) {
            continue;
        }
        $has = wp_get_object_terms( $service->ID, 'service_category', [ 'fields' => 'slugs' ] );
        if ( is_wp_error( $has ) || array_intersect( (array) $has, array_keys( $cats ) ) ) {
            continue;
        }
        wp_set_object_terms( $service->ID, $pages[ $service->post_name ], 'service_category', true );
    }
    foreach ( $groups as $name => $slugs ) {
        $term = get_term_by( 'name', $name, 'service_category' );
        if ( $term && ! get_term_meta( $term->term_id, 'bires_filter_cats', true ) ) {
            update_term_meta( $term->term_id, 'bires_filter_cats', $slugs );
        }
    }
    update_option( 'bires_service_filters', 1, false );
}
add_action( 'admin_init', 'bires_service_filters_once', 30 );

/** Латиницею для адрес сторінок (українська транслітерація). */
function bires_translit( $text ) {
    $map = [ 'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'h', 'ґ' => 'g', 'д' => 'd', 'е' => 'e', 'є' => 'ye', 'ж' => 'zh', 'з' => 'z', 'и' => 'y', 'і' => 'i', 'ї' => 'yi', 'й' => 'y', 'к' => 'k', 'л' => 'l', 'м' => 'm', 'н' => 'n', 'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't', 'у' => 'u', 'ф' => 'f', 'х' => 'kh', 'ц' => 'ts', 'ч' => 'ch', 'ш' => 'sh', 'щ' => 'shch', 'ь' => '', 'ю' => 'yu', 'я' => 'ya', '’' => '', "'" => '', 'ʼ' => '' ];
    return sanitize_title( strtr( mb_strtolower( (string) $text ), $map ) );
}

/**
 * Сторінки напрямів для груп старого сайту (податкова практика, кадри, міграційне право): у каталозі кожна плитка
 * веде на сторінку напряму, а в груп її не було. Нова сторінка — шаблон послуги, на ній перелік усіх послуг групи;
 * в каталозі окремою плиткою не показується (плитка групи веде на неї). Адреси самих послуг не змінюються. Разово.
 */
function bires_group_pages_once() {
    if ( 1 <= (int) get_option( 'bires_group_pages' ) || ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $terms = get_terms( [ 'taxonomy' => 'service_category', 'hide_empty' => false ] );
    foreach ( is_wp_error( $terms ) ? [] : $terms as $term ) {
        if ( ! get_term_meta( $term->term_id, 'bires_group', true ) || bires_group_page_id( $term ) ) {
            continue;
        }
        $items = get_posts( [
            'post_type'      => 'page',
            'posts_per_page' => -1,
            'orderby'        => [ 'menu_order' => 'ASC' ],
            'tax_query'      => [ [ 'taxonomy' => 'service_category', 'terms' => $term->term_id ] ],
        ] );
        if ( ! $items ) {
            continue;
        }
        $id = wp_insert_post( [
            'post_type'   => 'page',
            'post_status' => 'publish',
            'post_title'  => $term->name,
            'post_name'   => bires_translit( $term->name ),
            'menu_order'  => (int) $items[0]->menu_order,
        ], true );
        if ( is_wp_error( $id ) || ! $id ) {
            continue;
        }
        update_post_meta( $id, '_wp_page_template', BIRES_SERVICE_TEMPLATE );
        update_post_meta( $id, 'bires_group_term', (int) $term->term_id );
        update_post_meta( $id, 'bires_hide_in_catalog', 1 );
        update_post_meta( $id, 'service_audience', 'personal' === get_post_meta( $items[0]->ID, 'service_audience', true ) ? 'personal' : 'business' );
        update_post_meta( $id, '_service_audience', 'field_bires_service_audience' );
        update_term_meta( $term->term_id, 'bires_group_page', $id );
    }
    update_option( 'bires_group_pages', 1, false );
}
add_action( 'admin_init', 'bires_group_pages_once', 30 );

/**
 * Короткі заголовки карток для статей, що стоять на головній (поле «Короткий заголовок для карток»).
 * Заголовок і текст самих статей не змінюються. Лише порожні поля. Разово.
 */
function bires_card_titles_once() {
    if ( 1 <= (int) get_option( 'bires_card_titles' ) || ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $titles = [
        'derzhpraczi-ta-mobing-novi-pravyla-perevirok-z-zhovtnya-2025-roku'          => 'Держпраці та мобінг: нові перевірки',
        'pomylky-pry-rozblokuvanni-podatkovykh-nakladnykh'                           => 'Помилки в розблокуванні податкових накладних',
        'zakonoproekt-13507-9-oznak-trudovykh-vidnosyn-ta-shtrafy-dlia-robotodavtsiv' => 'Законопроект № 13507: ознаки трудових відносин',
    ];
    foreach ( $titles as $slug => $title ) {
        $post = get_page_by_path( $slug, OBJECT, 'post' );
        if ( $post && '' === trim( (string) get_post_meta( $post->ID, 'post_card_title', true ) ) ) {
            update_post_meta( $post->ID, 'post_card_title', $title );
            update_post_meta( $post->ID, '_post_card_title', 'field_bires_post_card_title' );
        }
    }
    update_option( 'bires_card_titles', 1, false );
}
add_action( 'admin_init', 'bires_card_titles_once', 30 );

/** Разово, на будь-якому сайті (і зі старою базою, і після імпорту), коли адмінку відкрив адміністратор. */
function bires_migrated_hide_stubs_once() {
    if ( 2 <= (int) get_option( 'bires_stubs_hidden' ) || ! current_user_can( 'manage_options' ) ) {
        return;
    }
    bires_migrated_hide_stubs();
    update_option( 'bires_stubs_hidden', 2, false );
}
add_action( 'admin_init', 'bires_migrated_hide_stubs_once', 30 );

function bires_migrated_fixes() {
    if ( ! get_option( 'bires_old_media' ) || ! function_exists( 'update_field' ) ) {
        return;
    }
    $done = (array) get_option( 'bires_migrated_fixes', [] );
    foreach ( bires_migrated_homes() as $lang => $page_id ) {
        if ( ( $done[ $lang ] ?? '' ) === BIRES_MIGRATED_FIXES ) {
            continue;
        }
        bires_migrated_home_design( $page_id, $lang, false );
        $done[ $lang ] = BIRES_MIGRATED_FIXES;
    }
    // Блок «Офіс» на «Контактах» і «Правові інсайти» на головній (з'явилися у версіях правок 2–3) — разово
    if ( ( $done['office'] ?? '' ) !== BIRES_MIGRATED_FIXES ) {
        bires_migrated_contacts_office();
        $homes = bires_migrated_homes();
        if ( isset( $homes['uk'] ) ) {
            bires_migrated_home_insights( $homes['uk'] );
        }
        $done['office'] = BIRES_MIGRATED_FIXES;
    }
    update_option( 'bires_migrated_fixes', $done, false );
}
add_action( 'admin_init', 'bires_migrated_fixes', 30 );
