<?php
/**
 * Перенесення контенту зі старого сайту (сторінки Elementor) у блоки теми.
 * Інструменти → «Перенесення зі старого сайту».
 *
 * Адреси, мови WPML і SEO-поля Yoast не змінюються. Старий вміст сторінки зберігається
 * в прихованих полях (_bires_old_*), тож перенесення можна безпечно повторити.
 */

define( 'BIRES_MIGRATION_VERSION', '1' );

/* ---------- Розбір дерева Elementor ---------- */

function bires_mig_data( $post_id ) {
    $raw = get_post_meta( $post_id, '_bires_old_elementor_data', true );
    if ( ! $raw ) {
        $raw = get_post_meta( $post_id, '_elementor_data', true );
    }
    $data = is_array( $raw ) ? $raw : json_decode( (string) $raw, true );
    return is_array( $data ) ? $data : [];
}

function bires_mig_settings( $el ) {
    return isset( $el['settings'] ) && is_array( $el['settings'] ) ? $el['settings'] : [];
}

function bires_mig_classes( $el ) {
    $s   = bires_mig_settings( $el );
    $css = trim( ( isset( $s['_css_classes'] ) ? $s['_css_classes'] : '' ) . ' ' . ( isset( $s['css_classes'] ) ? $s['css_classes'] : '' ) );
    return '' === $css ? [] : preg_split( '/\s+/', $css );
}

function bires_mig_has( $el, $class ) {
    return in_array( $class, bires_mig_classes( $el ), true );
}

function bires_mig_children( $el ) {
    return isset( $el['elements'] ) && is_array( $el['elements'] ) ? $el['elements'] : [];
}

function bires_mig_widget( $el ) {
    return isset( $el['widgetType'] ) ? $el['widgetType'] : '';
}

/**
 * Усі елементи, що відповідають умові, у порядку документа. $stop — не заходити всередину знайдених.
 */
function bires_mig_find( $els, $pred, $stop = false ) {
    $out = [];
    foreach ( $els as $el ) {
        if ( ! is_array( $el ) ) {
            continue;
        }
        $hit = $pred( $el );
        if ( $hit ) {
            $out[] = $el;
        }
        if ( ! ( $hit && $stop ) ) {
            $out = array_merge( $out, bires_mig_find( bires_mig_children( $el ), $pred, $stop ) );
        }
    }
    return $out;
}

function bires_mig_widgets( $els, $type = null ) {
    return bires_mig_find( $els, function ( $el ) use ( $type ) {
        $w = bires_mig_widget( $el );
        return $w && ( null === $type || $w === $type );
    } );
}

function bires_mig_contains( $els, $pred ) {
    return (bool) bires_mig_find( $els, $pred, true );
}

/** Текст без тегів в один рядок. */
function bires_mig_inline( $html ) {
    $text = html_entity_decode( wp_strip_all_tags( (string) $html ), ENT_QUOTES, 'UTF-8' );
    return trim( preg_replace( '/[\s\x{00A0}\x{200B}]+/u', ' ', $text ) );
}

/** Текст без тегів, абзаци й пункти списків — окремими рядками. */
function bires_mig_lines( $html ) {
    $html  = preg_replace( '#<(br|/p|/li|/h[1-6]|/div|/tr)[^>]*>#i', "\n", (string) $html );
    $text  = html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES, 'UTF-8' );
    $lines = array_filter( array_map( function ( $line ) {
        return trim( preg_replace( '/[ \t\x{00A0}\x{200B}]+/u', ' ', $line ) );
    }, explode( "\n", $text ) ), 'strlen' );
    return implode( "\n", $lines );
}

/** HTML з редактора Elementor без вбудованих стилів і порожніх абзаців. */
function bires_mig_clean_html( $html ) {
    $html = (string) $html;
    $html = preg_replace( '/\s(style|class|id|data-[\w-]+|dir|lang)="[^"]*"/i', '', $html );
    $html = preg_replace( '#<span>(.*?)</span>#is', '$1', $html );
    $html = preg_replace( '#<span>(.*?)</span>#is', '$1', $html );
    $html = preg_replace( '#<p>(\s|&nbsp;|\x{00A0}|<br\s*/?>)*</p>#iu', '', $html );
    $html = preg_replace( '#<(strong|b|em|i)>(\s|&nbsp;)*</\1>#i', '', $html );
    return trim( wp_kses_post( $html ) );
}

function bires_mig_heading_text( $el ) {
    $s = bires_mig_settings( $el );
    return bires_mig_inline( isset( $s['title'] ) ? $s['title'] : '' );
}

function bires_mig_editor( $el ) {
    $s = bires_mig_settings( $el );
    return isset( $s['editor'] ) ? (string) $s['editor'] : '';
}

function bires_mig_link( $el ) {
    $s = bires_mig_settings( $el );
    return isset( $s['link']['url'] ) ? (string) $s['link']['url'] : '';
}

/** Перший заголовок (віджет heading) у гілці, крім тих, що всередині елементів із класом $skip_class. */
function bires_mig_first_heading( $els, $skip_class = '' ) {
    foreach ( $els as $el ) {
        if ( $skip_class && bires_mig_has( $el, $skip_class ) ) {
            continue;
        }
        if ( 'heading' === bires_mig_widget( $el ) ) {
            $text = bires_mig_heading_text( $el );
            if ( '' !== $text ) {
                return $text;
            }
        }
        $found = bires_mig_first_heading( bires_mig_children( $el ), $skip_class );
        if ( '' !== $found ) {
            return $found;
        }
    }
    return '';
}

/** Пункти вкладеного акордеона: [ [ title, html ], ... ] */
function bires_mig_accordion_items( $acc ) {
    $s     = bires_mig_settings( $acc );
    $items = isset( $s['items'] ) && is_array( $s['items'] ) ? $s['items'] : [];
    $kids  = bires_mig_children( $acc );
    $out   = [];
    foreach ( $items as $i => $item ) {
        $html = '';
        if ( isset( $kids[ $i ] ) ) {
            foreach ( bires_mig_widgets( [ $kids[ $i ] ] ) as $w ) {
                if ( 'text-editor' === bires_mig_widget( $w ) ) {
                    $html .= bires_mig_editor( $w );
                } elseif ( 'heading' === bires_mig_widget( $w ) ) {
                    $html .= '<p>' . esc_html( bires_mig_heading_text( $w ) ) . '</p>';
                }
            }
        }
        $out[] = [ bires_mig_inline( isset( $item['item_title'] ) ? $item['item_title'] : '' ), $html ];
    }
    return $out;
}

/** Довільна секція у HTML (щоб нічого не загубити): заголовки, тексти, списки, зображення. */
function bires_mig_section_html( $section ) {
    $html = '';
    foreach ( bires_mig_widgets( [ $section ] ) as $w ) {
        $type = bires_mig_widget( $w );
        $s    = bires_mig_settings( $w );
        if ( 'heading' === $type ) {
            $text = bires_mig_heading_text( $w );
            if ( '' === $text ) {
                continue;
            }
            $tag  = isset( $s['header_size'] ) && preg_match( '/^h[2-6]$/', $s['header_size'] ) ? $s['header_size'] : 'h3';
            $link = bires_mig_link( $w );
            $html .= $link ? sprintf( '<%1$s><a href="%2$s">%3$s</a></%1$s>', $tag, esc_url( $link ), esc_html( $text ) ) : sprintf( '<%1$s>%2$s</%1$s>', $tag, esc_html( $text ) );
        } elseif ( 'text-editor' === $type ) {
            $html .= bires_mig_clean_html( bires_mig_editor( $w ) );
        } elseif ( 'image' === $type && ! empty( $s['image']['url'] ) && ! preg_match( '/\.svg$/i', $s['image']['url'] ) ) {
            $html .= sprintf( '<p><img src="%s" alt="%s"></p>', esc_url( $s['image']['url'] ), esc_attr( isset( $s['image']['alt'] ) ? $s['image']['alt'] : '' ) );
        } elseif ( 'icon-list' === $type && ! empty( $s['icon_list'] ) && is_array( $s['icon_list'] ) ) {
            $html .= '<ul>';
            foreach ( $s['icon_list'] as $row ) {
                $text = bires_mig_inline( isset( $row['text'] ) ? $row['text'] : '' );
                $url  = isset( $row['link']['url'] ) ? $row['link']['url'] : '';
                $html .= '<li>' . ( $url ? '<a href="' . esc_url( $url ) . '">' . esc_html( $text ) . '</a>' : esc_html( $text ) ) . '</li>';
            }
            $html .= '</ul>';
        } elseif ( 'nested-accordion' === $type ) {
            foreach ( bires_mig_accordion_items( $w ) as list( $title, $body ) ) {
                $html .= '<h3>' . esc_html( $title ) . '</h3>' . bires_mig_clean_html( $body );
            }
        } elseif ( 'html' === $type && ! empty( $s['html'] ) && false === stripos( $s['html'], '<script' ) ) {
            $html .= $s['html'];
        }
    }
    return $html;
}

/* ---------- Сторінка послуги ---------- */

function bires_mig_is_service( $data ) {
    return bires_mig_contains( $data, function ( $el ) {
        return bires_mig_has( $el, 'how_we_work' ) || bires_mig_has( $el, 'in_poslugi_accordeon' ) || bires_mig_has( $el, 'what_you_get' );
    } );
}

function bires_mig_counter_number( $counter ) {
    $s      = bires_mig_settings( $counter );
    $number = isset( $s['ending_number'] ) ? (string) $s['ending_number'] : '';
    if ( '' === $number ) {
        return '';
    }
    return ( isset( $s['prefix'] ) ? $s['prefix'] : '' ) . $number . ( isset( $s['suffix'] ) ? $s['suffix'] : '' );
}

/**
 * Розкладає сторінку послуги на поля теми.
 * $generic_hero — тексти першого екрана, однакові на багатьох сторінках (їх не переносимо як підзаголовок).
 */
function bires_mig_service_fields( $data, $generic_hero = [] ) {
    $f = [
        'hero_text'        => '',
        'intro_text'       => '',
        'steps_title'      => '',
        'steps'            => [],
        'intro_card_title' => '',
        'intro_card_text'  => '',
        'results_title'    => '',
        'results_numbers'  => [],
        'benefits_title'   => '',
        'benefits'         => [],
        'faq_title'        => '',
        'faq'              => [],
        'seo'              => '',
        'extra'            => '',
        'log'              => [],
    ];

    foreach ( $data as $section ) {
        $in = [ $section ];

        if ( bires_mig_has( $section, 'my_bread' ) || bires_mig_has( $section, 'home_10' ) ) {
            continue; // хлібні крихти й форма — у новому шаблоні свої
        }

        if ( bires_mig_has( $section, 'home_1' ) ) {
            $text = '';
            foreach ( bires_mig_widgets( $in, 'text-editor' ) as $w ) {
                $text .= ' ' . bires_mig_inline( bires_mig_editor( $w ) );
            }
            $text = trim( $text );
            if ( $text && ! in_array( md5( $text ), $generic_hero, true ) ) {
                $f['hero_text'] = $text;
                $f['log'][]     = 'hero';
            }
            continue;
        }

        if ( bires_mig_widgets( $in, 'theme-post-title' ) ) {
            $html = '';
            foreach ( bires_mig_widgets( $in, 'text-editor' ) as $w ) {
                $html .= bires_mig_clean_html( bires_mig_editor( $w ) );
            }
            $f['intro_text'] = $html;
            $f['log'][]      = 'intro';
            continue;
        }

        if ( bires_mig_contains( $in, function ( $el ) {
            return bires_mig_has( $el, 'how_we_work' );
        } ) ) {
            // Послідовність: заголовок «Як ми працюємо», етапи, заголовок «Вартість та строки», блок ціни
            $events = [];
            $walk   = function ( $els ) use ( &$walk, &$events ) {
                foreach ( $els as $el ) {
                    if ( bires_mig_has( $el, 'how_we_work' ) ) {
                        $events[] = [ 'box', $el ];
                    } elseif ( 'heading' === bires_mig_widget( $el ) ) {
                        $events[] = [ 'heading', bires_mig_heading_text( $el ) ];
                    } else {
                        $walk( bires_mig_children( $el ) );
                    }
                }
            };
            $walk( bires_mig_children( $section ) );
            $seen_step = false;
            $pending   = '';
            foreach ( $events as list( $kind, $value ) ) {
                if ( 'heading' === $kind ) {
                    if ( ! $seen_step && ! $f['steps_title'] ) {
                        $f['steps_title'] = $value;
                    } else {
                        $pending = $value;
                    }
                    continue;
                }
                $title_box = bires_mig_find( [ $value ], function ( $el ) {
                    return bires_mig_has( $el, 'title' );
                }, true );
                if ( $title_box ) {
                    $text_html = '';
                    foreach ( bires_mig_find( [ $value ], function ( $el ) {
                        return bires_mig_has( $el, 'text' );
                    }, true ) as $box ) {
                        foreach ( bires_mig_widgets( [ $box ], 'text-editor' ) as $w ) {
                            $text_html .= bires_mig_editor( $w );
                        }
                    }
                    $f['steps'][] = [
                        'icon'  => '',
                        'title' => bires_mig_first_heading( $title_box ),
                        'text'  => bires_mig_lines( $text_html ),
                    ];
                    $seen_step = true;
                } else {
                    $price = '';
                    foreach ( bires_mig_widgets( [ $value ], 'text-editor' ) as $w ) {
                        $price .= ' ' . bires_mig_inline( bires_mig_editor( $w ) );
                    }
                    if ( '' !== trim( $price ) ) {
                        $f['intro_card_title'] = $pending;
                        $f['intro_card_text']  = trim( $price );
                    }
                }
            }
            $f['log'][] = 'steps:' . count( $f['steps'] );
            continue;
        }

        $counters = bires_mig_widgets( $in, 'counter' );
        if ( $counters ) {
            $f['results_title'] = bires_mig_first_heading( $in );
            // Кожна цифра лежить у своєму контейнері разом із підписом
            foreach ( bires_mig_find( $in, function ( $el ) {
                foreach ( bires_mig_children( $el ) as $kid ) {
                    if ( 'counter' === bires_mig_widget( $kid ) ) {
                        return true;
                    }
                }
                return false;
            } ) as $box ) {
                $label  = '';
                $number = '';
                foreach ( bires_mig_children( $box ) as $kid ) {
                    if ( 'heading' === bires_mig_widget( $kid ) && '' === $label ) {
                        $label = bires_mig_heading_text( $kid );
                    } elseif ( 'counter' === bires_mig_widget( $kid ) && '' === $number ) {
                        $number = bires_mig_counter_number( $kid );
                    }
                }
                if ( '' !== $number ) {
                    $f['results_numbers'][] = [ 'number' => $number, 'label' => $label ];
                }
            }
            $f['log'][] = 'results:' . count( $f['results_numbers'] );
            continue;
        }

        $what = bires_mig_find( $in, function ( $el ) {
            return 'nested-accordion' === bires_mig_widget( $el ) && bires_mig_has( $el, 'what_you_get' );
        }, true );
        if ( $what ) {
            $f['benefits_title'] = bires_mig_first_heading( $in, 'what_you_get' );
            foreach ( bires_mig_accordion_items( $what[0] ) as list( $title, $body ) ) {
                if ( '' !== $title ) {
                    $f['benefits'][] = [ 'icon' => '', 'title' => $title, 'text' => bires_mig_inline( $body ) ];
                }
            }
            $f['log'][] = 'benefits:' . count( $f['benefits'] );
            continue;
        }

        $faq = bires_mig_find( $in, function ( $el ) {
            return 'nested-accordion' === bires_mig_widget( $el ) && bires_mig_has( $el, 'in_poslugi_accordeon' );
        }, true );
        $seo = bires_mig_find( $in, function ( $el ) {
            return 'text-editor' === bires_mig_widget( $el ) && bires_mig_has( $el, 'hidden_text' );
        }, true );
        if ( $faq || $seo ) {
            if ( $faq ) {
                $f['faq_title'] = bires_mig_first_heading( $in, 'poslugi_accordion' );
                foreach ( $faq as $acc ) {
                    foreach ( bires_mig_accordion_items( $acc ) as list( $question, $answer ) ) {
                        $answer = bires_mig_clean_html( $answer );
                        if ( '' !== $question && '' !== $answer ) {
                            $f['faq'][] = [ 'question' => $question, 'answer' => $answer ];
                        }
                    }
                }
            }
            foreach ( $seo as $w ) {
                $f['seo'] .= bires_mig_clean_html( bires_mig_editor( $w ) );
            }
            $f['log'][] = 'faq:' . count( $f['faq'] ) . ( $f['seo'] ? ' seo' : '' );
            continue;
        }

        // Стрічка новин — у новому шаблоні статті підтягуються самі
        if ( bires_mig_widgets( $in, 'dce-dynamicposts-v2' ) ) {
            continue;
        }

        $html = bires_mig_section_html( $section );
        if ( '' !== trim( wp_strip_all_tags( $html ) ) ) {
            $f['extra'] .= $html;
            $f['log'][]  = 'extra:' . mb_substr( bires_mig_first_heading( $in ), 0, 30 );
        }
    }

    return $f;
}

/* ---------- Запис у сторінку ---------- */

function bires_mig_set( $post_id, $name, $value ) {
    if ( function_exists( 'update_field' ) ) {
        update_field( $name, $value, $post_id );
    } else {
        update_post_meta( $post_id, $name, $value );
    }
}

/** Зберігає старий стан сторінки один раз (до першого перенесення). */
function bires_mig_backup( $post ) {
    if ( get_post_meta( $post->ID, '_bires_old_backup', true ) ) {
        return;
    }
    update_post_meta( $post->ID, '_bires_old_content', wp_slash( $post->post_content ) );
    update_post_meta( $post->ID, '_bires_old_template', get_post_meta( $post->ID, '_wp_page_template', true ) );
    update_post_meta( $post->ID, '_bires_old_elementor_edit_mode', get_post_meta( $post->ID, '_elementor_edit_mode', true ) );
    update_post_meta( $post->ID, '_bires_old_elementor_data', wp_slash( (string) get_post_meta( $post->ID, '_elementor_data', true ) ) );
    update_post_meta( $post->ID, '_bires_old_backup', 1 );
}

function bires_mig_finish( $post, $template, $content ) {
    update_post_meta( $post->ID, '_wp_page_template', $template );
    // Elementor більше не малює цю сторінку (інакше підмінить вміст своїм)
    delete_post_meta( $post->ID, '_elementor_edit_mode' );
    wp_update_post( wp_slash( [ 'ID' => $post->ID, 'post_content' => $content ] ) );
    update_post_meta( $post->ID, '_bires_migrated', BIRES_MIGRATION_VERSION );
}

function bires_mig_convert_service( $post, $generic_hero ) {
    $f = bires_mig_service_fields( bires_mig_data( $post->ID ), $generic_hero );
    bires_mig_backup( $post );

    bires_mig_set( $post->ID, 'hero_text', $f['hero_text'] );
    bires_mig_set( $post->ID, 'intro_title', '' );
    bires_mig_set( $post->ID, 'intro_text', $f['intro_text'] );
    bires_mig_set( $post->ID, 'intro_card_title', $f['intro_card_title'] );
    bires_mig_set( $post->ID, 'intro_card_text', $f['intro_card_text'] );
    bires_mig_set( $post->ID, 'steps_title', $f['steps_title'] );
    bires_mig_set( $post->ID, 'steps', $f['steps'] );
    bires_mig_set( $post->ID, 'results_title', $f['results_title'] );
    bires_mig_set( $post->ID, 'results_numbers', $f['results_numbers'] );
    bires_mig_set( $post->ID, 'benefits_title', $f['benefits_title'] );
    bires_mig_set( $post->ID, 'benefits', $f['benefits'] );
    bires_mig_set( $post->ID, 'faq_title', $f['faq_title'] );
    bires_mig_set( $post->ID, 'faq', $f['faq'] );

    // Додаткові секції (якщо є) — перед SEO-текстом, щоб нічого не загубилось
    bires_mig_finish( $post, BIRES_SERVICE_TEMPLATE, $f['extra'] . $f['seo'] );
    return implode( ', ', $f['log'] );
}

/* ---------- Особливі сторінки ---------- */

/** FAQ і SEO-текст із секції «Поширені питання» (є на головній, у каталозі послуг). */
function bires_mig_faq_and_seo( $data ) {
    $out = [ 'faq_title' => '', 'faq' => [], 'seo' => '' ];
    foreach ( $data as $section ) {
        $faq = bires_mig_find( [ $section ], function ( $el ) {
            return 'nested-accordion' === bires_mig_widget( $el ) && bires_mig_has( $el, 'in_poslugi_accordeon' );
        }, true );
        $box = bires_mig_find( [ $section ], function ( $el ) {
            return bires_mig_has( $el, 'poslugi_accordion' );
        }, true );
        if ( ! $faq && $box ) {
            $faq = bires_mig_find( $box, function ( $el ) {
                return 'nested-accordion' === bires_mig_widget( $el );
            }, true );
        }
        if ( ! $faq ) {
            continue;
        }
        $out['faq_title'] = bires_mig_first_heading( [ $section ], 'poslugi_accordion' );
        foreach ( $faq as $acc ) {
            foreach ( bires_mig_accordion_items( $acc ) as list( $question, $answer ) ) {
                $answer = bires_mig_clean_html( $answer );
                if ( '' !== $question && '' !== $answer ) {
                    $out['faq'][] = [ 'question' => $question, 'answer' => $answer ];
                }
            }
        }
        // SEO-текст — тексти секції поза акордеоном
        foreach ( bires_mig_find( [ $section ], function ( $el ) {
            return 'nested-accordion' === bires_mig_widget( $el ) || 'text-editor' === bires_mig_widget( $el );
        }, true ) as $w ) {
            if ( 'text-editor' === bires_mig_widget( $w ) ) {
                $out['seo'] .= bires_mig_clean_html( bires_mig_editor( $w ) );
            }
        }
    }
    return $out;
}

/** Головна: відгуки, логотипи клієнтів, FAQ і SEO-текст. Решта текстів — з нового дизайну. */
function bires_mig_convert_home( $post, $data ) {
    bires_mig_backup( $post );
    $log = [];

    $reviews = [];
    foreach ( bires_mig_widgets( $data, 'bdt-static-carousel' ) as $w ) {
        $s = bires_mig_settings( $w );
        foreach ( isset( $s['carousel_items'] ) && is_array( $s['carousel_items'] ) ? $s['carousel_items'] : [] as $item ) {
            $text = bires_mig_lines( isset( $item['text'] ) ? $item['text'] : '' );
            if ( '' === $text ) {
                continue;
            }
            $reviews[] = [
                'name'   => bires_mig_inline( isset( $item['title'] ) ? $item['title'] : '' ),
                'role'   => bires_mig_inline( isset( $item['sub_title'] ) ? $item['sub_title'] : '' ),
                'logo'   => ! empty( $item['image']['id'] ) ? bires_mig_att( $item['image']['id'] ) : '',
                'badge'  => '',
                'rating' => 5,
                'text'   => $text,
            ];
        }
    }
    if ( $reviews ) {
        bires_mig_set( $post->ID, 'home_reviews', $reviews );
        $log[] = 'reviews:' . count( $reviews );
    }

    $logos = [];
    foreach ( bires_mig_find( $data, function ( $el ) {
        return bires_mig_has( $el, 'home_8' );
    }, true ) as $section ) {
        foreach ( bires_mig_widgets( [ $section ], 'image' ) as $w ) {
            $s  = bires_mig_settings( $w );
            $id = ! empty( $s['image']['id'] ) ? bires_mig_att( $s['image']['id'] ) : 0;
            if ( $id && count( $logos ) < 16 ) {
                $logos[] = [ 'image' => $id, 'name' => get_the_title( $id ) ];
            }
        }
    }
    if ( $logos ) {
        bires_mig_set( $post->ID, 'home_logos', $logos );
        $log[] = 'logos:' . count( $logos );
    }

    $faq = bires_mig_faq_and_seo( $data );
    bires_mig_set( $post->ID, 'faq_title', $faq['faq_title'] );
    bires_mig_set( $post->ID, 'faq', $faq['faq'] );
    $log[] = 'faq:' . count( $faq['faq'] ) . ( $faq['seo'] ? ' seo' : '' );

    bires_mig_finish( $post, 'default', $faq['seo'] );
    return implode( ', ', $log );
}

/** ID картинки зі старого сайту → запис медіатеки тут (при імпорті ID інші — їх підставляє імпорт). */
function bires_mig_att( $old_id ) {
    $id = (int) apply_filters( 'bires_mig_attachment', (int) $old_id );
    return $id && 'attachment' === get_post_type( $id ) ? $id : 0;
}

/** Посилання зі старого сайту → ID сторінки на цьому сайті. */
function bires_mig_url_to_id( $url ) {
    $path = wp_parse_url( $url, PHP_URL_PATH );
    if ( ! $path ) {
        return 0;
    }
    $id = url_to_postid( home_url( $path ) );
    if ( ! $id ) {
        $page = get_page_by_path( trim( preg_replace( '#^/ru(/|$)#', '/', $path ), '/' ) );
        $id   = $page ? $page->ID : 0;
    }
    return (int) $id;
}

/**
 * Каталог послуг: для кого послуга, група (податкова практика, кадри…) і порядок — як на старій сторінці «Послуги».
 */
function bires_mig_services_structure( $data ) {
    $order    = 0;
    $audience = [];
    $groups   = [];
    $orders   = [];
    $sections = bires_mig_find( $data, function ( $el ) {
        return bires_mig_has( $el, 'home_4' );
    }, true );
    foreach ( $sections as $section ) {
        // Блок «Для фізичних осіб» / «Для физических лиц»; решта (зокрема мобільна копія блоку «Для бізнесу») — бізнес
        $is_business = ! preg_match( '/фіз|физ/iu', bires_mig_first_heading( [ $section ] ) );
        $walk        = function ( $els, $group ) use ( &$walk, &$order, &$audience, &$groups, &$orders, $is_business ) {
            foreach ( $els as $el ) {
                if ( 'nested-accordion' === bires_mig_widget( $el ) ) {
                    $s     = bires_mig_settings( $el );
                    $items = isset( $s['items'] ) ? $s['items'] : [];
                    foreach ( bires_mig_children( $el ) as $i => $kid ) {
                        $name = isset( $items[ $i ]['item_title'] ) ? bires_mig_inline( $items[ $i ]['item_title'] ) : '';
                        $walk( [ $kid ], $name );
                    }
                    continue;
                }
                if ( 'heading' === bires_mig_widget( $el ) && bires_mig_link( $el ) ) {
                    $id = bires_mig_url_to_id( bires_mig_link( $el ) );
                    if ( $id ) {
                        if ( ! isset( $orders[ $id ] ) ) {
                            $orders[ $id ] = ++$order;
                        }
                        // Послуга, що є в обох списках, лишається «для бізнесу»
                        if ( $is_business || ! isset( $audience[ $id ] ) ) {
                            $audience[ $id ] = $is_business ? 'business' : 'personal';
                        }
                        if ( $group ) {
                            $groups[ $id ] = $group;
                        }
                    }
                    continue;
                }
                $walk( bires_mig_children( $el ), $group );
            }
        };
        $walk( bires_mig_children( $section ), '' );
    }

    foreach ( $orders as $id => $position ) {
        wp_update_post( [ 'ID' => $id, 'menu_order' => $position * 10 ] );
        update_post_meta( $id, '_bires_mig_listed', 1 );
        bires_mig_set( $id, 'service_audience', $audience[ $id ] );
        if ( isset( $groups[ $id ] ) ) {
            $term = term_exists( $groups[ $id ], 'service_category' );
            if ( ! $term ) {
                $term = wp_insert_term( $groups[ $id ], 'service_category' );
            }
            if ( ! is_wp_error( $term ) ) {
                wp_set_object_terms( $id, [ (int) $term['term_id'] ], 'service_category' );
                // Група без власної сторінки: у каталозі й на головній — одна плитка зі списком послуг
                update_term_meta( (int) $term['term_id'], 'bires_group', 1 );
            }
        }
    }
    return count( $orders );
}

function bires_mig_convert_listing( $post, $data ) {
    bires_mig_backup( $post );
    $count = bires_mig_services_structure( $data );

    $hero = '';
    foreach ( bires_mig_find( $data, function ( $el ) {
        return bires_mig_has( $el, 'home_1' );
    }, true ) as $section ) {
        foreach ( bires_mig_widgets( [ $section ], 'text-editor' ) as $w ) {
            $hero .= ' ' . bires_mig_inline( bires_mig_editor( $w ) );
        }
    }
    bires_mig_set( $post->ID, 'hero_text', trim( $hero ) );

    $faq = bires_mig_faq_and_seo( $data );
    bires_mig_set( $post->ID, 'faq_title', $faq['faq_title'] );
    bires_mig_set( $post->ID, 'faq', $faq['faq'] );
    bires_mig_finish( $post, BIRES_SERVICES_TEMPLATE, $faq['seo'] );
    return 'services:' . $count . ', faq:' . count( $faq['faq'] ) . ( $faq['seo'] ? ' seo' : '' );
}

function bires_mig_convert_contacts( $post, $data ) {
    bires_mig_backup( $post );
    $address = '';
    foreach ( $data as $section ) {
        $widgets = bires_mig_widgets( [ $section ] );
        foreach ( $widgets as $i => $w ) {
            // Текст одразу після заголовка «Адреса»
            if ( 'heading' === bires_mig_widget( $w ) && preg_match( '/^адрес/iu', bires_mig_heading_text( $w ) ) && isset( $widgets[ $i + 1 ] ) ) {
                $next    = $widgets[ $i + 1 ];
                $address = 'text-editor' === bires_mig_widget( $next ) ? bires_mig_inline( bires_mig_editor( $next ) ) : bires_mig_heading_text( $next );
            }
        }
    }
    $map = '';
    foreach ( bires_mig_widgets( $data, 'google_maps' ) as $w ) {
        $s   = bires_mig_settings( $w );
        $map = isset( $s['address'] ) ? (string) $s['address'] : '';
    }
    if ( $address ) {
        bires_mig_set( $post->ID, 'office_title', 'Bires Law Firm' );
        bires_mig_set( $post->ID, 'office_address', $address );
    }
    if ( $map ) {
        bires_mig_set( $post->ID, 'map_query', $map );
    }
    bires_mig_finish( $post, 'page-templates/contact.php', '' );
    return 'address' . ( $map ? ', map' : '' );
}

/** Звичайна текстова сторінка (політики, «Дякуємо»): усі тексти в редактор WordPress. */
function bires_mig_convert_text( $post, $data, $template = 'default' ) {
    bires_mig_backup( $post );
    $html = '';
    foreach ( $data as $section ) {
        if ( bires_mig_has( $section, 'my_bread' ) || bires_mig_has( $section, 'home_10' ) || bires_mig_widgets( [ $section ], 'bdt-wp-forms' ) || bires_mig_widgets( [ $section ], 'theme-post-title' ) && ! bires_mig_widgets( [ $section ], 'text-editor' ) ) {
            continue;
        }
        $html .= bires_mig_section_html( $section );
    }
    bires_mig_finish( $post, $template, $html );
    return 'text:' . mb_strlen( wp_strip_all_tags( $html ) );
}

function bires_mig_page_kind( $post, $data ) {
    $has_class = function ( $class ) use ( $data ) {
        return bires_mig_contains( $data, function ( $el ) use ( $class ) {
            return bires_mig_has( $el, $class );
        } );
    };
    if ( $has_class( 'home_5' ) || $has_class( 'home_9' ) ) {
        return 'home';
    }
    if ( $has_class( 'home_4' ) ) {
        return 'listing';
    }
    if ( bires_mig_is_service( $data ) ) {
        return 'service';
    }
    if ( bires_mig_widgets( $data, 'google_maps' ) ) {
        return 'contacts';
    }
    if ( bires_mig_widgets( $data, 'search-filter-form' ) ) {
        return 'blog';
    }
    if ( preg_match( '/^karta-sajt/', $post->post_name ) ) {
        return 'sitemap';
    }
    return 'text';
}

/**
 * Послуги, яких не було в каталозі старого сайту: розкладаємо по групах за змістом,
 * дублікати старого сайту ховаємо з каталогу й меню (сторінки лишаються доступні за адресою).
 * Ключ — адреса української сторінки; значення — адреса послуги з потрібної групи або 'hide'.
 */
function bires_mig_catalog_rules() {
    return [
        'bronyuvannya-praczivnikiv'                   => 'autsorsyng-kadrovogo-obliku',
        'postanovka-kadrovogo-obliku'                 => 'autsorsyng-kadrovogo-obliku',
        'rozrobka-posadovikh-instrukczij'             => 'autsorsyng-kadrovogo-obliku',
        'znyattya-zaboroni-na-vyizd-do-ukrayini'      => 'otrymannya-posvidky-na-tymchasove-prozhyvannya',
        'deportacziya-inozemczya-z-ukrayini'          => 'otrymannya-posvidky-na-tymchasove-prozhyvannya',
        'zmina-mitniczeyu-kodu-ukt-zed-tovaru'        => 'mytni-spory',
        'obzhalovanie-blokirovki-nalogovyh-nakladnyh' => 'hide',
        'ctyagnennya-zaborgovanosti'                  => 'hide',
    ];
}

/** Українська адреса сторінки (для перекладу — адреса оригіналу у WPML). */
function bires_mig_original_slug( $page_id ) {
    $default  = apply_filters( 'wpml_default_language', null );
    $original = $default ? (int) apply_filters( 'wpml_object_id', $page_id, 'page', false, $default ) : 0;
    return get_post_field( 'post_name', $original ? $original : $page_id );
}

/** Сторінка-переклад іншої сторінки мовою $lang_of (без WPML — сама сторінка). */
function bires_mig_same_lang( $page_id, $lang_of ) {
    $lang = apply_filters( 'wpml_post_language_details', null, $lang_of );
    if ( is_array( $lang ) && ! empty( $lang['language_code'] ) ) {
        $id = (int) apply_filters( 'wpml_object_id', $page_id, 'page', false, $lang['language_code'] );
        return $id ? $id : 0;
    }
    return $page_id;
}

function bires_mig_apply_catalog_rules() {
    $rules = bires_mig_catalog_rules();
    $pages = get_posts( [ 'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => -1, 'suppress_filters' => true, 'meta_key' => '_wp_page_template', 'meta_value' => BIRES_SERVICE_TEMPLATE ] );
    $by_slug = [];
    foreach ( $pages as $page ) {
        if ( ! bires_mig_lang_is_default( $page->ID ) ) {
            continue;
        }
        $by_slug[ $page->post_name ] = $page->ID;
    }
    $done = 0;
    foreach ( $pages as $page ) {
        $slug = bires_mig_original_slug( $page->ID );
        if ( ! isset( $rules[ $slug ] ) || get_post_meta( $page->ID, '_bires_mig_listed', true ) ) {
            continue;
        }
        if ( 'hide' === $rules[ $slug ] ) {
            update_post_meta( $page->ID, 'bires_hide_in_catalog', 1 );
            $done++;
            continue;
        }
        $anchor = isset( $by_slug[ $rules[ $slug ] ] ) ? bires_mig_same_lang( $by_slug[ $rules[ $slug ] ], $page->ID ) : 0;
        if ( ! $anchor ) {
            continue;
        }
        // У групу сусідньої послуги; якщо вона без групи — просто поруч із нею в каталозі
        $group = bires_service_group( $anchor );
        if ( $group ) {
            wp_set_object_terms( $page->ID, [ $group->term_id ], 'service_category' );
        }
        bires_mig_set( $page->ID, 'service_audience', bires_field( 'service_audience', $anchor ) );
        // Після послуг групи з каталогу
        wp_update_post( [ 'ID' => $page->ID, 'menu_order' => (int) get_post_field( 'menu_order', $anchor ) + 5 ] );
        update_post_meta( $page->ID, '_bires_mig_listed', 1 );
        $done++;
    }
    return $done;
}

function bires_mig_lang_is_default( $page_id ) {
    $default = apply_filters( 'wpml_default_language', null );
    return ! $default || bires_mig_lang( $page_id ) === $default;
}

/** Сайти, де перенесення вже було (до версії 1.6.4): рубрики-групи старого каталогу позначаємо один раз. */
function bires_mig_mark_groups() {
    if ( get_option( 'bires_groups_marked' ) === '2' ) {
        return;
    }
    update_option( 'bires_groups_marked', '2' );
    $ids = get_posts( [ 'post_type' => 'page', 'post_status' => 'any', 'posts_per_page' => -1, 'suppress_filters' => true, 'fields' => 'ids', 'meta_key' => '_bires_mig_listed' ] );
    foreach ( $ids as $id ) {
        $terms = get_the_terms( $id, 'service_category' );
        foreach ( $terms && ! is_wp_error( $terms ) ? $terms : [] as $term ) {
            update_term_meta( $term->term_id, 'bires_group', 1 );
        }
    }
    if ( $ids ) {
        bires_mig_apply_catalog_rules();
        // Меню послуг будувалось до цих правил — перебудовуємо (групи, без дублікатів)
        $langs = [];
        foreach ( bires_mig_pages() as $page ) {
            $langs[ bires_mig_lang( $page->ID ) ] = true;
        }
        update_option( 'bires_mig_force_menus', 1, false );
        bires_mig_build_menus( array_keys( $langs ) );
        delete_option( 'bires_mig_force_menus' );
    }
}
add_action( 'admin_init', 'bires_mig_mark_groups', 20 );

/* ---------- Запуск ---------- */

/** Сторінки зі старим вмістом Elementor. */
function bires_mig_pages() {
    return get_posts( [
        'post_type'        => 'page',
        'post_status'      => [ 'publish', 'draft', 'private' ],
        'posts_per_page'   => -1,
        'orderby'          => 'ID',
        'order'            => 'ASC',
        'suppress_filters' => true,
        'meta_query'       => [
            'relation' => 'OR',
            [ 'key' => '_elementor_data', 'compare' => 'EXISTS' ],
            [ 'key' => '_bires_old_elementor_data', 'compare' => 'EXISTS' ],
        ],
    ] );
}

/** Тексти першого екрана, що повторюються на багатьох сторінках (загальний опис компанії). */
function bires_mig_generic_hero( $pages ) {
    $counts = [];
    foreach ( $pages as $page ) {
        foreach ( bires_mig_data( $page->ID ) as $section ) {
            if ( ! bires_mig_has( $section, 'home_1' ) ) {
                continue;
            }
            $text = '';
            foreach ( bires_mig_widgets( [ $section ], 'text-editor' ) as $w ) {
                $text .= ' ' . bires_mig_inline( bires_mig_editor( $w ) );
            }
            $hash            = md5( trim( $text ) );
            $counts[ $hash ] = ( isset( $counts[ $hash ] ) ? $counts[ $hash ] : 0 ) + 1;
        }
    }
    return array_keys( array_filter( $counts, function ( $n ) {
        return $n >= 5;
    } ) );
}

function bires_mig_convert( $page, $generic ) {
    $data = bires_mig_data( $page->ID );
    if ( ! $data ) {
        return [ 'empty', '' ];
    }
    $kind = bires_mig_page_kind( $page, $data );
    switch ( $kind ) {
        case 'service':
            return [ $kind, bires_mig_convert_service( $page, $generic ) ];
        case 'home':
            return [ $kind, bires_mig_convert_home( $page, $data ) ];
        case 'listing':
            return [ $kind, bires_mig_convert_listing( $page, $data ) ];
        case 'contacts':
            return [ $kind, bires_mig_convert_contacts( $page, $data ) ];
        case 'blog':
            bires_mig_backup( $page );
            bires_mig_finish( $page, 'default', '' );
            // Сторінка блогу — «Сторінка записів» (для основної мови; переклад WPML підхопить сам)
            $current = (int) get_option( 'page_for_posts' );
            $is_old  = $current && 'blog' === get_post_meta( $current, '_bires_mig_kind', true ) && 'publish' === get_post_status( $current );
            if ( ! $is_old && (int) get_option( 'page_on_front' ) !== $page->ID && 'ru' !== bires_mig_lang( $page->ID ) ) {
                update_option( 'page_for_posts', $page->ID );
            }
            return [ $kind, __( 'сторінка записів', 'bires-theme' ) ];
        case 'sitemap':
            bires_mig_backup( $page );
            bires_mig_finish( $page, BIRES_SITEMAP_TEMPLATE, '' );
            return [ $kind, '' ];
        default:
            return [ $kind, bires_mig_convert_text( $page, $data ) ];
    }
}

/** Мова сторінки (WPML), без WPML — за позначкою з імпорту. */
function bires_mig_lang( $post_id ) {
    $details = apply_filters( 'wpml_post_language_details', null, $post_id );
    if ( is_array( $details ) && ! empty( $details['language_code'] ) ) {
        return $details['language_code'];
    }
    $lang = get_post_meta( $post_id, '_bires_old_lang', true );
    return $lang ? $lang : 'uk';
}

/**
 * Переносить сторінки порціями (щоб не впертися в ліміт часу хостингу).
 * $run — мітка запуску: у межах одного запуску сторінка обробляється один раз.
 * Повертає [ журнал, скільки лишилось ].
 */
function bires_migration_run( $force = false, $limit = 0, $run = '' ) {
    if ( function_exists( 'set_time_limit' ) ) {
        set_time_limit( 300 );
    }
    $run   = $run ? $run : (string) time();
    $pages = bires_mig_pages();
    $todo  = array_values( array_filter( $pages, function ( $page ) use ( $force, $run ) {
        if ( $run === get_post_meta( $page->ID, '_bires_mig_run', true ) ) {
            return false;
        }
        return $force || ! get_post_meta( $page->ID, '_bires_migrated', true );
    } ) );

    $generic = get_transient( 'bires_mig_generic_' . $run );
    if ( ! is_array( $generic ) ) {
        $generic = bires_mig_generic_hero( $pages );
        set_transient( 'bires_mig_generic_' . $run, $generic, HOUR_IN_SECONDS );
    }

    // Головна й каталог — першими: від каталогу залежить порядок і групи послуг
    usort( $todo, function ( $a, $b ) {
        $rank = function ( $p ) {
            return 'poslugy' === $p->post_name || 'uslugi' === $p->post_name ? 0 : 1;
        };
        return $rank( $a ) <=> $rank( $b ) ?: $a->ID <=> $b->ID;
    } );

    $log  = [];
    $done = 0;
    wp_defer_term_counting( true );
    foreach ( $todo as $page ) {
        if ( $limit && $done >= $limit ) {
            break;
        }
        list( $kind, $details ) = bires_mig_convert( $page, $generic );
        update_post_meta( $page->ID, '_bires_mig_run', $run );
        update_post_meta( $page->ID, '_bires_mig_kind', $kind );
        $log[] = [ $page->ID, $page->post_title, $kind, $details ];
        $done++;
    }
    wp_defer_term_counting( false );
    $remaining = count( $todo ) - $done;
    // Завершення (порядок послуг і меню) — окремим кроком після всіх сторінок
    if ( 0 === $remaining && get_option( 'bires_mig_finalized' ) !== $run ) {
        if ( $done ) {
            $remaining = 1;
        } else {
            $log = array_merge( $log, bires_mig_finalize() );
            update_option( 'bires_mig_finalized', $run, false );
        }
    }
    if ( function_exists( 'bires_sitemap_flush' ) ) {
        bires_sitemap_flush();
    }
    return [ $log, $remaining ];
}

/* ---------- Завершення: порядок послуг і меню ---------- */

/** Сторінки-послуги верхнього рівня однієї мови в порядку каталогу. */
function bires_mig_top_services( $lang ) {
    $pages = get_posts( [
        'post_type'        => 'page',
        'post_status'      => 'publish',
        'posts_per_page'   => -1,
        'suppress_filters' => true,
        'meta_key'         => '_wp_page_template',
        'meta_value'       => BIRES_SERVICE_TEMPLATE,
        'orderby'          => [ 'menu_order' => 'ASC', 'title' => 'ASC' ],
    ] );
    return array_values( array_filter( $pages, function ( $page ) use ( $lang ) {
        return bires_mig_lang( $page->ID ) === $lang && ! get_post_meta( $page->ID, 'bires_hide_in_catalog', true ) && ! ( $page->post_parent && BIRES_SERVICE_TEMPLATE === get_page_template_slug( $page->post_parent ) );
    } ) );
}

function bires_mig_page_of_kind( $kind, $lang ) {
    foreach ( get_posts( [ 'post_type' => 'page', 'posts_per_page' => -1, 'suppress_filters' => true, 'meta_key' => '_bires_mig_kind', 'meta_value' => $kind ] ) as $page ) {
        if ( bires_mig_lang( $page->ID ) === $lang ) {
            return $page;
        }
    }
    return null;
}

function bires_mig_finalize() {
    bires_mig_apply_catalog_rules();
    $log   = [];
    $langs = [];
    foreach ( bires_mig_pages() as $page ) {
        $langs[ bires_mig_lang( $page->ID ) ] = true;
    }
    foreach ( array_keys( $langs ) as $lang ) {
        foreach ( bires_mig_top_services( $lang ) as $page ) {
            // Послуги, яких не було в каталозі старого сайту, — у кінець списку
            if ( ! get_post_meta( $page->ID, '_bires_mig_listed', true ) && ! get_post_meta( $page->ID, 'bires_hide_in_catalog', true ) ) {
                wp_update_post( [ 'ID' => $page->ID, 'menu_order' => 1000 + (int) $page->menu_order ] );
                $log[] = [ $page->ID, $page->post_title, 'note', __( 'цієї послуги не було в каталозі старого сайту — перевірте «Для кого» й групу (праворуч у редакторі сторінки)', 'bires-theme' ) ];
            }
        }
    }
    return array_merge( $log, bires_mig_build_menus( array_keys( $langs ) ) );
}

function bires_mig_menu_item( $menu_id, $parent, $args ) {
    $defaults = [ 'menu-item-status' => 'publish', 'menu-item-parent-id' => $parent ];
    if ( isset( $args['page'] ) ) {
        $defaults['menu-item-type']      = 'post_type';
        $defaults['menu-item-object']    = 'page';
        $defaults['menu-item-object-id'] = $args['page'];
        unset( $args['page'] );
    } else {
        $defaults['menu-item-type'] = 'custom';
    }
    $id = wp_update_nav_menu_item( $menu_id, 0, array_merge( $defaults, $args ) );
    return is_wp_error( $id ) ? 0 : $id;
}

/** Меню (головне з мегаменю послуг і два в футері) — лише якщо в темі їх ще немає. */
function bires_mig_build_menus( $langs ) {
    $locations = get_nav_menu_locations();
    if ( ! empty( $locations['primary'] ) && ! get_option( 'bires_mig_force_menus' ) ) {
        return [ [ 0, __( 'Меню', 'bires-theme' ), 'menu', __( 'головне меню вже призначене — не змінювала', 'bires-theme' ) ] ];
    }
    $labels = [
        'uk' => [ 'biz' => 'Для бізнесу', 'personal' => 'Для фізичних осіб', 'name' => '', 'sitemap' => 'Карта сайту' ],
        'ru' => [ 'biz' => 'Для бизнеса', 'personal' => 'Для физических лиц', 'name' => ' (RU)', 'sitemap' => 'Карта сайта' ],
    ];
    usort( $langs, function ( $a, $b ) {
        return ( 'uk' === $a ? 0 : 1 ) <=> ( 'uk' === $b ? 0 : 1 );
    } );
    $log   = [];
    $menus = [];
    foreach ( $langs as $lang ) {
        $l       = isset( $labels[ $lang ] ) ? $labels[ $lang ] : $labels['uk'];
        $listing = bires_mig_page_of_kind( 'listing', $lang );
        if ( ! $listing ) {
            continue;
        }
        foreach ( [ 'primary' => 'Головне меню', 'footer_services' => 'Футер: послуги', 'footer_company' => 'Футер: компанія' ] as $location => $name ) {
            $existing = wp_get_nav_menu_object( $name . $l['name'] );
            if ( $existing ) {
                wp_delete_nav_menu( $existing->term_id );
            }
            $menus[ $lang ][ $location ] = wp_create_nav_menu( $name . $l['name'] );
        }
        $primary = $menus[ $lang ]['primary'];
        $root    = bires_mig_menu_item( $primary, 0, [ 'page' => $listing->ID ] );
        $count   = 0;
        $tops    = bires_mig_top_services( $lang );
        foreach ( [ 'business' => $l['biz'], 'personal' => $l['personal'] ] as $audience => $label ) {
            $group  = bires_mig_menu_item( $primary, $root, [ 'menu-item-title' => $label, 'menu-item-url' => '#' ] );
            $cards  = [];
            foreach ( $tops as $page ) {
                $value = bires_field( 'service_audience', $page->ID );
                if ( ( $value ? $value : 'business' ) !== $audience ) {
                    continue;
                }
                $term = bires_service_group( $page->ID );
                if ( $term ) {
                    // Група без власної сторінки (податкова практика, кадри…) — картка з переліком послуг
                    if ( ! isset( $cards[ 'term' . $term->term_id ] ) ) {
                        $cards[ 'term' . $term->term_id ] = bires_mig_menu_item( $primary, $group, [ 'menu-item-title' => $term->name, 'menu-item-url' => get_permalink( $listing ) . '#' . $term->slug ] );
                    }
                    bires_mig_menu_item( $primary, $cards[ 'term' . $term->term_id ], [ 'page' => $page->ID ] );
                    $count++;
                    continue;
                }
                $card = bires_mig_menu_item( $primary, $group, [ 'page' => $page->ID ] );
                $count++;
                foreach ( get_pages( [ 'parent' => $page->ID, 'sort_column' => 'menu_order,post_title' ] ) as $sub ) {
                    if ( BIRES_SERVICE_TEMPLATE === get_page_template_slug( $sub->ID ) ) {
                        bires_mig_menu_item( $primary, $card, [ 'page' => $sub->ID ] );
                        $count++;
                    }
                }
            }
        }
        $blog     = bires_mig_page_of_kind( 'blog', $lang );
        $contacts = bires_mig_page_of_kind( 'contacts', $lang );
        $sitemap  = bires_mig_page_of_kind( 'sitemap', $lang );
        // Нові сторінки з макета («Кейси», «Про нас»), якщо вони вже є
        $extra = [];
        if ( 'uk' === $lang ) {
            foreach ( [ 'page-templates/cases.php', 'page-templates/about.php' ] as $template ) {
                $found = get_pages( [ 'meta_key' => '_wp_page_template', 'meta_value' => $template, 'number' => 1 ] );
                if ( $found ) {
                    $extra[] = $found[0];
                }
            }
        }
        foreach ( array_merge( $extra, [ $blog, $contacts ] ) as $page ) {
            if ( $page ) {
                bires_mig_menu_item( $primary, 0, [ 'page' => $page->ID ] );
            }
        }

        $top5 = array_slice( array_values( array_filter( $tops, function ( $page ) {
            return ! bires_service_group( $page->ID );
        } ) ), 0, 5 );
        foreach ( $top5 as $page ) {
            bires_mig_menu_item( $menus[ $lang ]['footer_services'], 0, [ 'page' => $page->ID ] );
        }
        foreach ( [ $blog, $contacts, $sitemap ] as $page ) {
            if ( $page ) {
                bires_mig_menu_item( $menus[ $lang ]['footer_company'], 0, [ 'page' => $page->ID ] );
            }
        }
        /* translators: 1: language code, 2: number of services */
        $log[] = [ 0, sprintf( __( 'Меню (%1$s)', 'bires-theme' ), $lang ), 'menu', sprintf( __( 'створено: послуг у мегаменю — %2$d', 'bires-theme' ), $lang, $count ) ];
    }

    if ( isset( $menus['uk'] ) ) {
        set_theme_mod( 'nav_menu_locations', array_merge( (array) get_theme_mod( 'nav_menu_locations', [] ), $menus['uk'] ) );
        // WPML: російські меню — переклади українських
        if ( isset( $menus['ru'] ) && has_action( 'wpml_set_element_language_details' ) ) {
            foreach ( $menus['uk'] as $location => $uk_menu ) {
                $uk_term = get_term( $uk_menu, 'nav_menu' );
                $ru_term = get_term( $menus['ru'][ $location ], 'nav_menu' );
                if ( ! $uk_term || ! $ru_term || is_wp_error( $uk_term ) || is_wp_error( $ru_term ) ) {
                    continue;
                }
                $trid = apply_filters( 'wpml_element_trid', null, $uk_term->term_taxonomy_id, 'tax_nav_menu' );
                do_action( 'wpml_set_element_language_details', [
                    'element_id'           => $ru_term->term_taxonomy_id,
                    'element_type'         => 'tax_nav_menu',
                    'trid'                 => $trid,
                    'language_code'        => 'ru',
                    'source_language_code' => 'uk',
                ] );
            }
        }
    }
    return $log;
}

/* ---------- Сторінка в адмінці ---------- */

function bires_migration_menu() {
    add_management_page( __( 'Перенесення зі старого сайту', 'bires-theme' ), __( 'Перенесення зі старого сайту', 'bires-theme' ), 'manage_options', 'bires-migration', 'bires_migration_screen' );
}
add_action( 'admin_menu', 'bires_migration_menu' );

function bires_migration_screen() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    $log       = null;
    $remaining = 0;
    $force     = false;
    $run       = '';
    if ( isset( $_POST['bires_migration_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['bires_migration_nonce'] ), 'bires_migration' ) ) {
        $force = ! empty( $_POST['force'] );
        $run   = isset( $_POST['run'] ) ? sanitize_key( $_POST['run'] ) : '';
        $run   = $run ? $run : (string) time();
        list( $log, $remaining ) = bires_migration_run( $force, 20, $run );
        $prev = isset( $_POST['log'] ) ? json_decode( wp_unslash( $_POST['log'] ), true ) : [];
        $log  = array_merge( is_array( $prev ) ? $prev : [], $log );
    }
    $pages    = bires_mig_pages();
    $migrated = count( array_filter( $pages, function ( $p ) {
        return (bool) get_post_meta( $p->ID, '_bires_migrated', true );
    } ) );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Перенесення зі старого сайту', 'bires-theme' ); ?></h1>
        <p><?php esc_html_e( 'Переносить вміст сторінок, зроблених в Elementor, у блоки нової теми: вступ, етапи, вартість, цифри, «Що ви отримаєте», FAQ і SEO-текст; на головній — відгуки, логотипи клієнтів, FAQ і SEO-текст; каталог послуг, контакти, політики. Адреси сторінок, мовні версії WPML і SEO-поля Yoast не змінюються. Старий вміст зберігається, тож перенесення можна повторити.', 'bires-theme' ); ?></p>
        <p>
            <?php
            /* translators: 1: pages with Elementor content, 2: already migrated */
            echo esc_html( sprintf( __( 'Сторінок зі старим вмістом: %1$d, уже перенесено: %2$d.', 'bires-theme' ), count( $pages ), $migrated ) );
            ?>
        </p>
        <?php if ( $remaining > 0 ) : ?>
            <p><strong>
                <?php
                /* translators: %d: pages left */
                echo esc_html( sprintf( __( 'Переношу… Залишилось сторінок: %d. Не закривайте вкладку.', 'bires-theme' ), $remaining ) );
                ?>
            </strong></p>
            <form method="post" id="bires-mig-next">
                <?php wp_nonce_field( 'bires_migration', 'bires_migration_nonce' ); ?>
                <input type="hidden" name="run" value="<?php echo esc_attr( $run ); ?>">
                <input type="hidden" name="force" value="<?php echo $force ? '1' : ''; ?>">
                <input type="hidden" name="log" value="<?php echo esc_attr( wp_json_encode( $log ) ); ?>">
                <noscript><button type="submit" class="button button-primary"><?php esc_html_e( 'Продовжити', 'bires-theme' ); ?></button></noscript>
            </form>
            <script>document.getElementById('bires-mig-next').submit();</script>
        <?php else : ?>
            <form method="post">
                <?php wp_nonce_field( 'bires_migration', 'bires_migration_nonce' ); ?>
                <p><label><input type="checkbox" name="force" value="1"> <?php esc_html_e( 'Перенести заново й уже перенесені сторінки (ручні правки в їхніх блоках буде перезаписано)', 'bires-theme' ); ?></label></p>
                <p><button type="submit" class="button button-primary"><?php esc_html_e( 'Перенести контент', 'bires-theme' ); ?></button></p>
            </form>
        <?php endif; ?>
        <?php if ( is_array( $log ) && $log ) : ?>
            <h2><?php echo $remaining > 0 ? esc_html__( 'Перенесено поки що', 'bires-theme' ) : esc_html__( 'Готово', 'bires-theme' ); ?></h2>
            <table class="widefat striped">
                <thead><tr><th>ID</th><th><?php esc_html_e( 'Сторінка', 'bires-theme' ); ?></th><th><?php esc_html_e( 'Тип', 'bires-theme' ); ?></th><th><?php esc_html_e( 'Що перенесено', 'bires-theme' ); ?></th></tr></thead>
                <tbody>
                    <?php foreach ( $log as $row ) : ?>
                        <tr>
                            <td><?php echo (int) $row[0]; ?></td>
                            <td><a href="<?php echo esc_url( get_permalink( $row[0] ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $row[1] ); ?></a></td>
                            <td><?php echo esc_html( $row[2] ); ?></td>
                            <td><?php echo esc_html( $row[3] ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
}
