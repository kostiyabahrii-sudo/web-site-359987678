<?php
/**
 * Сайт перенесено зі старого (bires.com.ua) без файлів медіатеки: картинку, файлу якої ще немає
 * в wp-content/uploads цього сайту, показуємо зі старого сайту. Щойно файли скопійовано — береться свій файл.
 * Вмикається позначкою bires_old_media (ставиться при перенесенні).
 */

define( 'BIRES_OLD_UPLOADS', 'https://bires.com.ua/wp-content/uploads' );

function bires_old_media_on() {
    static $on = null;
    if ( null === $on ) {
        $on = get_option( 'bires_old_media' ) && false === strpos( (string) get_option( 'home' ), '//bires.com.ua' );
    }
    return $on;
}

function bires_old_media_url( $url ) {
    static $exists = [];
    if ( ! is_string( $url ) || ! bires_old_media_on() ) {
        return $url;
    }
    $uploads = wp_get_upload_dir();
    $base    = set_url_scheme( $uploads['baseurl'] );
    $url_s   = set_url_scheme( $url );
    if ( 0 !== strpos( $url_s, $base . '/' ) ) {
        return $url;
    }
    $relative = substr( $url_s, strlen( $base ) );
    $file     = $uploads['basedir'] . rawurldecode( strtok( $relative, '?#' ) );
    if ( ! isset( $exists[ $file ] ) ) {
        $exists[ $file ] = file_exists( $file );
    }
    return $exists[ $file ] ? $url : BIRES_OLD_UPLOADS . $relative;
}
add_filter( 'wp_get_attachment_url', 'bires_old_media_url' );

function bires_old_media_srcset( $sources ) {
    foreach ( (array) $sources as $width => $source ) {
        $sources[ $width ]['url'] = bires_old_media_url( $source['url'] );
    }
    return $sources;
}
add_filter( 'wp_calculate_image_srcset', 'bires_old_media_srcset' );

/** Картинки й файли, вставлені в текст статей і сторінок. */
function bires_old_media_content( $html ) {
    if ( ! is_string( $html ) || ! bires_old_media_on() ) {
        return $html;
    }
    $base = preg_quote( preg_replace( '#^https?:#', '', wp_get_upload_dir()['baseurl'] ), '#' );
    return preg_replace_callback( '#(?:https?:)?' . $base . '/[^"\'\s<>)]+#', function ( $m ) {
        return bires_old_media_url( set_url_scheme( $m[0] ) );
    }, $html );
}
add_filter( 'the_content', 'bires_old_media_content', 30 );
add_filter( 'acf/format_value/type=wysiwyg', 'bires_old_media_content', 30 );

/**
 * Картинки в тексті з повною адресою старого сайту (https://bires.com.ua/wp-content/uploads/…):
 * коли файл уже є в папці uploads цього сайту — показуємо свій, а не тягнемо зі старого.
 */
function bires_old_domain_content( $html ) {
    static $exists = [];
    if ( ! is_string( $html ) || false === strpos( $html, 'bires.com.ua/wp-content/uploads/' ) || false !== strpos( (string) get_option( 'home' ), '//bires.com.ua' ) ) {
        return $html;
    }
    $uploads = wp_get_upload_dir();
    return preg_replace_callback( '#https?://(?:www\.)?bires\.com\.ua/wp-content/uploads(/[^"\'\s<>(),]+)#', function ( $m ) use ( $uploads, &$exists ) {
        $file = $uploads['basedir'] . rawurldecode( strtok( $m[1], '?#' ) );
        if ( ! isset( $exists[ $file ] ) ) {
            $exists[ $file ] = file_exists( $file );
        }
        return $exists[ $file ] ? set_url_scheme( $uploads['baseurl'] ) . $m[1] : $m[0];
    }, $html );
}
add_filter( 'the_content', 'bires_old_domain_content', 31 );
add_filter( 'acf/format_value/type=wysiwyg', 'bires_old_domain_content', 31 );
