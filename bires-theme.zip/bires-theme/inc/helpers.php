<?php

function bires_field( $name, $post_id = null ) {
    if ( function_exists( 'get_field' ) ) {
        return get_field( $name, $post_id );
    }
    $post_id = $post_id ? $post_id : get_the_ID();
    return is_numeric( $post_id ) ? get_post_meta( (int) $post_id, $name, true ) : '';
}

function bires_option( $name, $default = '' ) {
    $value = bires_field( $name, 'option' );
    return ( null === $value || '' === $value || false === $value ) ? $default : $value;
}

function bires_rows( $name, $post_id = null ) {
    $rows = function_exists( 'get_field' ) ? get_field( $name, $post_id ) : [];
    return is_array( $rows ) ? $rows : [];
}

function bires_services_root_id( $post_id = null ) {
    $post_id = $post_id ? $post_id : get_queried_object_id();
    foreach ( get_post_ancestors( $post_id ) as $ancestor_id ) {
        if ( BIRES_SERVICES_TEMPLATE === get_page_template_slug( $ancestor_id ) ) {
            return $ancestor_id;
        }
    }
    return 0;
}

function bires_services_listing_id() {
    $pages = get_pages( [ 'meta_key' => '_wp_page_template', 'meta_value' => BIRES_SERVICES_TEMPLATE, 'number' => 1 ] );
    return $pages ? (int) apply_filters( 'wpml_object_id', $pages[0]->ID, 'page', true ) : 0;
}

function bires_is_service_page( $post_id = null ) {
    if ( ! $post_id && ! is_page() ) {
        return false;
    }
    return (bool) bires_services_root_id( $post_id );
}

function bires_icon_choices() {
    return [
        'tie'       => __( 'Краватка (корпоративне)', 'bires-theme' ),
        'scroll'    => __( 'Сувій (державні процедури)', 'bires-theme' ),
        'wallet'    => __( 'Гаманець (фінанси)', 'bires-theme' ),
        'document'  => __( 'Документ (реєстрація)', 'bires-theme' ),
        'scales'    => __( 'Терези (кримінальне)', 'bires-theme' ),
        'banknotes' => __( 'Банкноти (банкрутство)', 'bires-theme' ),
        'building'  => __( 'Будівля (нерухомість)', 'bires-theme' ),
        'folder'    => __( 'Папка (договори)', 'bires-theme' ),
        'briefcase' => __( 'Портфель (кадри)', 'bires-theme' ),
        'bulb'      => __( 'Лампочка (інтелектуальне)', 'bires-theme' ),
        'home'      => __( 'Дім (сімейне)', 'bires-theme' ),
        'globe'     => __( 'Глобус (міграційне)', 'bires-theme' ),
        'money-bag' => __( 'Мішок (стягнення боргів)', 'bires-theme' ),
    ];
}

function bires_icon( $name, $size = 32 ) {
    $paths = [
        'arrow-up-right' => '<path d="M9 23 23 9M11 9h12v12"/>',
        'chevron-down'   => '<path d="m10 13 6 6 6-6"/>',
        'plus'           => '<path d="M16 7v18M7 16h18"/>',
        'tie'            => '<path d="M13 4h6l-1.5 4h-3L13 4Z"/><path d="m14.5 8-2.5 13 4 5 4-5-2.5-13"/>',
        'scroll'         => '<path d="M9 5h14v18a3 3 0 0 1-3 3H8a3 3 0 0 1-3-3v-2h12v2a3 3 0 0 0 3 3"/><path d="M9 5a3 3 0 0 0-3 3v1h3M13 11h6M13 15h6"/>',
        'wallet'         => '<rect x="5" y="9" width="22" height="16" rx="3"/><path d="M8 9V8a3 3 0 0 1 3-3h10M21 17h2"/>',
        'document'       => '<path d="M8 4h11l6 6v18H8V4Z"/><path d="M19 4v6h6M12 16h9M12 20h9M12 24h5"/>',
        'scales'         => '<path d="M16 5v22M10 27h12M7 9h18"/><path d="m7 9-3.5 8a3.5 3.5 0 0 0 7 0L7 9ZM25 9l-3.5 8a3.5 3.5 0 0 0 7 0L25 9Z"/>',
        'banknotes'      => '<rect x="4" y="10" width="20" height="13" rx="2"/><path d="M8 6h20v13"/><circle cx="14" cy="16.5" r="2.5"/>',
        'building'       => '<path d="M5 27h22M7 27V12l9-6 9 6v15"/><path d="M12 27v-8h8v8M12 14h1M19 14h1"/>',
        'folder'         => '<path d="M4 9a2 2 0 0 1 2-2h6l3 3h11a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9Z"/><path d="M4 14h24"/>',
        'briefcase'      => '<rect x="4" y="10" width="24" height="16" rx="2"/><path d="M12 10V7a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v3M4 17h24"/>',
        'bulb'           => '<path d="M12 22h8M13 26h6"/><path d="M16 4a8 8 0 0 0-5 14.2c.7.6 1 1.3 1 2.1V22h8v-1.7c0-.8.3-1.5 1-2.1A8 8 0 0 0 16 4Z"/>',
        'home'           => '<path d="M5 14 16 5l11 9"/><path d="M8 12v15h16V12M13 27v-7h6v7"/>',
        'globe'          => '<circle cx="16" cy="16" r="11"/><path d="M5 16h22M16 5c3 3 4.5 6.7 4.5 11S19 24 16 27c-3-3-4.5-6.7-4.5-11S13 8 16 5Z"/>',
        'arrow-left'     => '<path d="M25 16H7M14 9l-7 7 7 7"/>',
        'arrow-right'    => '<path d="M7 16h18M18 9l7 7-7 7"/>',
        'chat'           => '<path d="M16 5C9.9 5 5 9.3 5 14.7c0 2.7 1.2 5.1 3.2 6.9L7 27l5.6-2.6c1.1.3 2.2.4 3.4.4 6.1 0 11-4.3 11-9.6S22.1 5 16 5Z"/>',
        'shield'         => '<path d="M16 4 6 8v7c0 6.3 4.2 11.6 10 13 5.8-1.4 10-6.7 10-13V8L16 4Z"/><path d="m12 16 3 3 5-6"/>',
        'file'           => '<path d="M9 4h10l6 6v18H9V4Z"/><path d="M19 4v6h6"/>',
        'graduation'     => '<path d="M3 12 16 6l13 6-13 6L3 12Z"/><path d="M9 15v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6M29 12v7"/>',
        'city'           => '<path d="M5 27h22M8 27V8l8-3v22M16 11h8v16M11 11h2M11 15h2M11 19h2M19 15h2M19 19h2M19 23h2"/>',
        'route'          => '<circle cx="8" cy="8" r="3"/><circle cx="24" cy="24" r="3"/><path d="M11 8h11a4 4 0 0 1 0 8H10a4 4 0 0 0 0 8h11"/>',
        'lock'           => '<rect x="7" y="14" width="18" height="13" rx="3"/><path d="M11 14v-3a5 5 0 0 1 10 0v3M16 19v3"/>',
        'check-circle'   => '<circle cx="16" cy="16" r="11"/><path d="m11 16 3.5 3.5L21 13"/>',
        'money-bag'      =>'<path d="M12 9h8l2-4H10l2 4Z"/><path d="M12 9c-4 3-7 7-7 11a6 6 0 0 0 6 6h10a6 6 0 0 0 6-6c0-4-3-8-7-11"/><path d="M16 14v8M18.5 15.5h-3.5a1.5 1.5 0 0 0 0 3h2a1.5 1.5 0 0 1 0 3H13.5"/>',
    ];

    if ( ! isset( $paths[ $name ] ) ) {
        return '';
    }

    return sprintf(
        '<svg width="%1$d" height="%1$d" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">%2$s</svg>',
        (int) $size,
        $paths[ $name ]
    );
}

function bires_feature_icon_choices() {
    return [
        'chat'         => __( 'Повідомлення', 'bires-theme' ),
        'shield'       => __( 'Щит', 'bires-theme' ),
        'file'         => __( 'Документ', 'bires-theme' ),
        'graduation'   => __( 'Академічна шапка', 'bires-theme' ),
        'city'         => __( 'Будівлі', 'bires-theme' ),
        'route'        => __( 'Маршрут', 'bires-theme' ),
        'lock'         => __( 'Замок', 'bires-theme' ),
        'check-circle' => __( 'Галочка', 'bires-theme' ),
        'scales'       => __( 'Терези', 'bires-theme' ),
        'briefcase'    => __( 'Портфель', 'bires-theme' ),
    ];
}

function bires_posts_for_service( $service_id, $count = 2 ) {
    $posts = get_posts( [
        'suppress_filters' => false,
        'post_type'      => 'post',
        'posts_per_page' => $count,
        'meta_query'     => [ [
            'key'     => 'post_related_services',
            'value'   => '"' . (int) $service_id . '"',
            'compare' => 'LIKE',
        ] ],
    ] );

    if ( count( $posts ) < $count ) {
        $posts = array_merge( $posts, get_posts( [
            'suppress_filters' => false,
            'post_type'      => 'post',
            'posts_per_page' => $count - count( $posts ),
            'post__not_in'   => wp_list_pluck( $posts, 'ID' ),
        ] ) );
    }

    return $posts;
}

function bires_contact_url() {
    $contact_page = bires_field( 'contact_page', 'option' );
    if ( ! $contact_page ) {
        $pages        = get_pages( [ 'meta_key' => '_wp_page_template', 'meta_value' => 'page-templates/contact.php', 'number' => 1 ] );
        $contact_page = $pages ? $pages[0]->ID : 0;
    }
    return $contact_page ? get_permalink( apply_filters( 'wpml_object_id', $contact_page, 'page', true ) ) : '#contact';
}
