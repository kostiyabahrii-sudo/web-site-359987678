<?php get_header(); ?>

<main class="site-main" id="main">
    <section class="page-hero page-hero--404">
        <div class="container container--wide">
            <p class="page-404__code" aria-hidden="true">404</p>
            <h1 class="page-hero__title"><?php esc_html_e( 'Сторінку не знайдено', 'bires-theme' ); ?></h1>
            <p class="page-404__text"><?php esc_html_e( 'Можливо, її перемістили або видалили, або в адресі помилка. Почніть з головної чи оберіть потрібний розділ.', 'bires-theme' ); ?></p>
            <div class="page-404__actions">
                <a class="services-btn services-btn--white" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'На головну', 'bires-theme' ); ?></a>
                <?php $services_listing = bires_services_listing_id(); ?>
                <?php if ( $services_listing ) : ?>
                    <a class="services-btn services-btn--outline-light" href="<?php echo esc_url( get_permalink( $services_listing ) ); ?>"><?php esc_html_e( 'Послуги', 'bires-theme' ); ?></a>
                <?php endif; ?>
                <a class="services-btn services-btn--outline-light" href="<?php echo esc_url( bires_contact_url() ); ?>"><?php esc_html_e( 'Контакти', 'bires-theme' ); ?></a>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
