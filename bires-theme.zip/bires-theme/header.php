<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#main"><?php esc_html_e( 'Перейти до змісту', 'bires-theme' ); ?></a>

<?php $phone = bires_option( 'contact_phone_1', '(+380) 44 334 75 04' ); ?>
<header class="site-header">
    <div class="container container--wide">
        <div class="site-header__inner">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">BIRES</a>

            <nav class="site-nav" id="site-nav" aria-label="<?php esc_attr_e( 'Головне меню', 'bires-theme' ); ?>">
                <?php bires_render_primary_menu(); ?>
                <ul class="site-nav__contacts">
                    <?php
                    $nav_email   = bires_option( 'contact_email', 'info@bires.com.ua' );
                    $nav_contact = [ 'mailto:' . antispambot( $nav_email ) => antispambot( $nav_email ) ];
                    foreach ( array_filter( [ $phone, bires_option( 'contact_phone_2', '(+380) 96 106 20 56' ) ] ) as $nav_phone ) {
                        $nav_contact[ 'tel:' . preg_replace( '/[^\d+]/', '', $nav_phone ) ] = $nav_phone;
                    }
                    foreach ( $nav_contact as $nav_href => $nav_label ) :
                        ?>
                        <li><a href="<?php echo esc_attr( $nav_href ); ?>"><?php echo bires_icon( 'arrow-right', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG ?><?php echo esc_html( $nav_label ); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </nav>

            <div class="site-header__right">
                <?php bires_language_switcher(); ?>
                <a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $phone ) ); ?>" class="btn-call">
                    <?php esc_html_e( 'Зателефонувати', 'bires-theme' ); ?>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20.5 16.1v2.7a1.8 1.8 0 0 1-2 1.8 17.8 17.8 0 0 1-7.8-2.8 17.5 17.5 0 0 1-5.4-5.4 17.8 17.8 0 0 1-2.8-7.8 1.8 1.8 0 0 1 1.8-2H7a1.8 1.8 0 0 1 1.8 1.6c.1.9.3 1.7.6 2.5a1.8 1.8 0 0 1-.4 1.9L7.8 9.8a14.4 14.4 0 0 0 5.4 5.4l1.2-1.2a1.8 1.8 0 0 1 1.9-.4c.8.3 1.6.5 2.5.6a1.8 1.8 0 0 1 1.7 1.9Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </a>
                <button type="button" class="mobile-menu-toggle" aria-expanded="false" aria-controls="site-nav">
                    <span class="screen-reader-text"><?php esc_html_e( 'Меню', 'bires-theme' ); ?></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </button>
            </div>
        </div>
    </div>
</header>
<div class="site-overlay" hidden></div>
